#python quick_core.py host port 
import sys   #importing a module 
#another style 
from sys import argv  #for commandline handling 
#another style - alias 
import sys as SYS 
#or 
#from sys import *   #all imports 

#first arg is always file name 
if len(sys.argv) == 2:
    first_arg = argv[1]  #index starts from 0 
elif len(sys.argv) == 3:
    second_arg = sys.argv[2]
else:
    print("give only 1 or 2 arg")

#int 
a = 1
#float 
f = 1.2 
#bool 
b = True #False 
#comparison 
print( "and", a == 1 and f == 1.2)
print( "or", a != 1 or f >= 1.2)
print( "not" , not a <= 1)

#string - immutable 
s = "OK"    #or 'OK' or """Multiline string""" , r"raw string"
#list - mutable, indexing and duplicates - possible 
lst = [1,2]
#tuple - immutable, indexing and duplicates - possible 
t = (1,2)
#set , unique , nut duplicates not allowed 
st = {1,2}
#dict - keys are like set 
d = {'OK': 2}

#length 
print(len(s), len(lst), len(t), len(st), len(d))

#contains checking 
print('O' in s, 1 in lst, 1 not in t, 2 in st, 'OK' in d  )

#equality 
print(s == 'OK', t != (1,2,3)  ) #and others 

#each element - iteration 
for e in lst:  #or s, t, st 
    print(e) 
    
for k, v in d.items():
    print(k, v, "again value", d[k])
    
#indexing - only string, list, tuple 
print(lst[0], s[-1], t[1:], t[1:3:2])  #slice - start:end:step 

#concatenation or add 
s2 = s + " NOK"   
lst2 = lst + [3,4]
lst2.append(30)

t2 = t + (3,4)

st.add(20)

d['nok'] = 20 #creation of new key 
d['ok'] = 20 # update 
#-------------------------------------------
lst = [1,2]
lst3 = [ e*e for e in lst ]  #converting each element - comprehension 
st3 = { e*e for e in lst  if e % 2 == 0} #set comprehension , guard also can be given 
d3 = {e: e*e for e in lst }

#conversion 
a2 = int(f)    #type name as method 
st4 = set(t) 

#zip 
print( list(zip(['a', 'b'],['d', 'f'])))
#enumerate 
print( list(enumerate(['a', 'b'])))

#nested data structure 
lst4 = [ ('a', 1), ('b',2)]
#get first element of each 
print([t[0] for t in lst4])

d4 = [{'ok':2}, {'ok': 3}]
#update 2nd dict by 2 
d4[1]['ok'] = d4[1]['ok'] + 2
#ok key of each 
print([dt['ok'] for dt in d4])



#basic function 
def add(x, y=30):
    return x+y 

#calling a function 
print(add(2), add(2,3), add(y=3, x=2))

#lambda function 
add2 = lambda x, y : x+y 
print(add2(3,4))

#map and filter 
print(list(map(lambda x: x*x, lst)))
print(list(filter(lambda x: x%2==0, lst)))


##Basic Class 
class MyInt:
    def __init__(self, v):
        self.val = v 
    def __add__(self, other):
        z = self.val + other.val 
        return MyInt(z) 
    def __str__(self):
        z = "MyInt("+str(self.val)+")"
        return z 
    def __eq__(self, other):
        return self.val == other.val 
    def square(self):
        return MyInt(self.val ** 2)


###################
#from pkg.MyInt import Complex 
#a = Complex(2,3)
#b = Complex(3,4)
#c = a + b 
#print(c)  # Complex(5, 7)

class Complex:
    def __init__(self, re, im):
        self.re = re 
        self.im = im 
    def __add__(self, other):
        return Complex(self.re + other.re,  self.im+other.im) 
    def __str__(self):
        z = "Complex(%d,%d)" % (self.re, self.im)
        return z 





#Final function- 
#Given a file name and how many parts, 
#break that file's content into that many parts 


##Break 
def breakFiles(file, n, ext_length = 3):
    import os.path
    def write(fileName, lst):
        with open(fileName, "wt") as f:
            f.writelines(lst) 
        #print(fileName, "written", len(lst))
    def sliding(lst, w, s):
        res = [] 
        n = ((len(lst)-w)/s)+1
        for i in range(0, int(n)):
            start = i*s 
            end = w + s*i 
            res.append(lst[start:end])
        #last segment 
        if  lst[end:]:
                res.append(lst[end:])
        return res     
    def grouped(lst, n):
        return sliding(lst, n, n)        
    onlyFileName, ext = file[0: len(file)-ext_length-1], 
            file[len(file)-ext_length:]
    with open(file, "rt") as f:
        lines = f.readlines()
    howmany = len(lines) // n 
    gr = grouped(lines, howmany)
    if len(gr) > n : #extra last part      
        gr[-2] += gr[-1]
        del gr[-1]         
    #now len(gr) == n 
    names = [ onlyFileName+str(i)+"."+ext     
        for i in range(1,len(gr)+1)]
    #print(names, n, len(gr))
    for lst, n in zip(gr, names):
        write(n,lst)

        
if __name__ == '__main__':
    #give first_arg as file name 
    if len(sys.argv) == 2:
        breakFiles(sys.argv[1],3)














