
###+++ TensorFlow - terminologies of Neural Network 
#A deep neural network (DNN) is an NN with multiple hidden layers between the input and output layers

Activation function 
    the activation function of a node defines the output of that node given an input or set of inputs
    https://en.wikipedia.org/wiki/Activation_function

    If the activation function is linear,if you stack  many hidden layers in the neural network 
    and the final output is still a linear combination of the original input data

    Note: step function is not used for activation as it has no useful derivative (its derivative is 0 everywhere or undefined at the 0 point on x-axis). 
    It doesn�t work for backpropagation and  Perceptron with step function isn�t very �stable�
    a small change in any weight in the input layer of  perceptron network 
    could possibly lead to one neuron to suddenly flip from 0 to 1, 
    which could again affect the hidden layer�s behavior, and then affect the final outcome

    The solution is to use sigmoid function 
        Zi = WiXi  where Wi is weights and Xi is input 
        z = SUM(Wi*Xi) + bias , i=1..m 
        sigmoid function , = 1/(1+exp(-z)), like S curve 
    #few others 
    tanh                                            f(z) = tanh(z) 
    Rectified linear unit (ReLU)                    f(z) = 0 for z <0, z for z>=0
    Leaky rectified linear unit (Leaky ReLU)        f(z) = 0.01z for z <0, z for z>=0
    softmax                                         Fi(z) = exp(Zi)/(SUM(Zi)), i=1..m, then max of Fi(z)
    maxout                                          f(z) = max of Zi 


A feedforward neural network 
    is an artificial neural network 
    wherein connections between the units do not form a cycle
    the information moves in only one direction, forward, from the input nodes, 
    through the hidden nodes (if any) and to the output nodes. 
    There are no cycles or loops in the network
 
Single-layer perceptron
    The simplest kind of neural network is a single-layer perceptron network, 
    which consists of a single layer of output nodes; 
    the inputs are fed directly to the outputs via a series of weights
    
    The sum of the products of the weights and the inputs is calculated in each node, 
    and if the value is above some threshold (typically 0) the neuron fires 
    and takes the activated value (typically 1); 
    otherwise it takes the deactivated value (typically -1). 
    
    Neurons with this kind of activation function are also called artificial neurons  or linear threshold units



Multi-layer perceptron
    Contains hidden layers between input and output nodes 
    Check perceptron_node.png,check https://deeplearning4j.org/neuralnet-overview    
    
    Multi-layer networks use a variety of learning techniques, the most popular being back-propagation
    (equivalent to numerical calculation of gradient) 
    To adjust weights properly, one applies a general method for non-linear optimization 
    that is called gradient descent. 
    For this, the network calculates the derivative of the error function 
    with respect to the network weights, 
    and changes the weights such that the error decreases 
    (thus going downhill on the surface of the error function). 
    For this reason, back-propagation can only be applied on networks with differentiable activation functions

    In practice, the output values are compared with the correct answer to compute the value of some predefined error-function.
    By various techniques, the error is then fed back through the network. 
    Using this information, the algorithm adjusts the weights of each connection 
    in order to reduce the value of the error function by some small amount. 
    After repeating this process for a sufficiently large number of training cycles, 
    the network will usually converge to some state  where the error of the calculations is small. 
    In this case, one would say that the network has learned a certain target function. 
    


Recurrent neural network
    A recurrent neural network (RNN) is a class of artificial neural network 
    where connections between units form a directed cycle. 
    This allows it to exhibit dynamic temporal behavior. 
    Unlike feedforward neural networks, 
    RNNs can use their internal memory to process arbitrary sequences of inputs. 
    This makes them applicable to tasks such as unsegmented, 
    connected handwriting recognition or speech recognition


Long short-term memory
    Long short-term memory (LSTM) block or network is a recurrent neural network 
    which can be used as a building component or block (of hidden layers) for  bigger recurrent neural network
    
    An LSTM block is composed of four main components: 
    a cell, an input gate, an output gate and a forget gate. 
    The cell is responsible for "remembering" values over arbitrary time intervals; 
    hence the word "memory" in LSTM. 
    Each of the three gates can be thought of as a "conventional" artificial neuron, 
    as in a multi-layer (or feedforward) neural network: 
    that is, they compute an activation (using an activation function) of a weighted sum. 
    
    The expression long short-term refers to the fact that LSTM is a model 
    for the short-term memory which can last for a long period of time. 
    
    An LSTM is well-suited to classify, process and predict time series 
    given time lags of unknown size and duration between important events.


Convolutional neural network
    A CNN consists of an input and an output layer, as well as multiple hidden layers. 
    The hidden layers of a CNN typically consist of convolutional(actually cross-correlation)
    layers, pooling layers, fully connected layers and normalization layers.    
    Convolutional
        Convolutional layers apply a convolution operation to the input, 
        passing the result to the next layer        
        Each convolutional neuron processes data only for its receptive field(small range of inputs). 
        Tiling allows CNNs to tolerate translation of the input image 
        (e.g. translation, rotation, perspective distortion)  
    Pooling
        Convolutional networks may include local or global pooling layers, 
        which combine the outputs of neuron clusters(receptive field) at one layer into a single neuron in the next layer.
        For example, max pooling uses the maximum value from each of a cluster of neurons at the prior layer.
        Another example is average pooling, which uses the average value from each of a cluster of neurons at the prior layer
    Fully connected
        Fully connected layers connect every neuron in one layer to every neuron in another layer.
        It is in principle the same as the traditional multi-layer perceptron neural network (MLP)

##Tensflow - Few Terminologies 
Steps 
    number of times the training loop(forward and backword) in learning algorithm 
    will run to update the parameters in the model. 
    In each loop(step), it will process only one chunk of data(batch)
    Usually, this loop is based on the Gradient Descent algorithm.
Batch size 
    the size of the chunk of data in each loop  of the learning algorithm. 
    You can feed the whole data set, in which case the batch size 
    is equal to the data set size.
    You can also feed one example/observations at a time. 
    Or you can feed some number N of examples. 
Epoch
    the number of times the full data set 
    is used to generate batches for training loops(steps)
Shuffle 
    if True shuffles the input data queue.
    
#There are n samples and the batch_size is b , num_epoch = steps*b/n
#Example - Training for 5 epochs on a 1000 samples 10 samples per batch will take 500 steps(num_epoch*n/b)

#Note no of inputs to input layer needs to equal to batch size
#In general,in TF model, batch_size is set to None, 
#that means, run a model with a variable number of inputs (one or more). 
#Batching is important to efficiently use computing resources.

#Recommended practice 
#           batch_size  num_epochs              shuffle     Steps   Output
TRAIN       b           None(=autocalculated)   True        1000    Update trainable parameters(variables) 
EVALUATE    b           Finite                  False       x       Dict containing evaluation metrics, eg 'loss', 'accuracy'(=float)
PREDICT     b           1                       False       NA      list of dict containing 'predictions'(=np.ndarray) for each input x 











###+++ Tensorflow - Installation only on 3.5.2 x64 bit 
$ pip3 install --upgrade tensorflow

#MSVCP140.DLL  must be in system32 
#https://www.microsoft.com/en-us/download/details.aspxid=53587

##https://www.tensorflow.org/get_started/get_started
##The lowest level API--TensorFlow Core-- fine levels of control over  models.
#The higher level APIs, tf.estimator, tf.layers are built on top of TensorFlow Core. 


###Tensflow -Introduction - Tensors
#A tensor consists of a set of primitive values shaped into an array of any number of dimensions. 
#A tensor's rank is its number of dimensions.

3               # a rank 0 tensor; this is a scalar with shape []
[1., 2., 3.]    # a rank 1 tensor; this is a vector with shape [3]
[[1., 2., 3.], [4., 5., 6.]]        # a rank 2 tensor; a matrix with shape [2, 3]
[[[1., 2., 3.]], [[7., 8., 9.]]]    # a rank 3 tensor with shape [2, 1, 3]


##Tensflow - Importing TensorFlow

import tensorflow as tf

##Tensflow - The Computational Graph
#A computational graph is a series of TensorFlow operations arranged into a graph of nodes.
#Each node takes zero or more tensors as inputs and produces a tensor as an output. 

#TensorFlow Core programs  consisting of two discrete sections:
1.Building the computational graph.
2.Running the computational graph.

##Tensflow - constant 
#it takes no inputs, and it outputs a value it stores internally. 
#Constants are initialized with tf.constant, 
#and their value can never change.

node1 = tf.constant(3.0, dtype=tf.float32)
node2 = tf.constant(4.0) # also tf.float32 implicitly
>>> print(node1, node2)
Tensor("Const:0", shape=(), dtype=float32) Tensor("Const_1:0", shape=(), dtype=float32)

#To evaluate the nodes, 
#we must run the computational graph within a session. 
#A session encapsulates the control and state of the TensorFlow runtime.

sess = tf.Session()
>>> print(sess.run([node1, node2])) # running multiple operation via list, returns multiple values 
[3.0, 4.0]
#OR 
#t.eval(feed_dict=None,session=None) is a shortcut for calling 
#tf.get_default_session().run(t).
sess = tf.Session()
with sess.as_default():
    print(tf.get_default_session().run([node1, node2])) #note get_default_session requires a session set as default 
    print(node1.eval())
#OR 
with tf.Session() as sess:
    node1.eval()

#Example - add two constant nodes and produce a new graph 
node3 = tf.add(node1, node2)
print("node3:", node3)
print("sess.run(node3):", sess.run(node3))
#output
node3: Tensor("Add:0", shape=(), dtype=float32)
sess.run(node3): 7.0


##Tensflow - placeholder
##A graph can be parameterized to accept external inputs, known as placeholders. 
#A placeholder is a promise to provide a value later.

a = tf.placeholder(tf.float32) #a can be array as well, dtype must be type of each element 
b = tf.placeholder(tf.float32)
adder_node = a + b  # + provides a shortcut for tf.add(a, b)

#evaluate this graph 
print(sess.run(adder_node, {a: 3, b: 4.5})) #note key is object ,a, not string 'a'
print(sess.run(adder_node, {a: [1, 3], b: [2, 4]}))
#output
7.5
[ 3.  7.]
#Or 
with sess.as_default():
    adder_node.eval(feed_dict={a: 3, b: 4.5})

#adding another operation
add_and_triple = adder_node * 3.
print(sess.run(add_and_triple, {a: 3, b: 4.5}))
#output
22.5

##Tensflow - variable 
#Variables allow to add trainable parameters to a graph. 
#They are constructed with a type and initial value:

#basically W, b are mutable and value can be changed in place 
#Note placeholders are meant for input from users 
W = tf.Variable([.3], dtype=tf.float32)
b = tf.Variable([-.3], dtype=tf.float32)
x = tf.placeholder(tf.float32)
linear_model = W * x + b


#To initialize all the variables in a TensorFlow program
init = tf.global_variables_initializer()
sess.run(init)
#or Note, tf.Operation has .run() whereas tf.Tensor as .eval() or .op.run()
#Note op.run() does not return anything, but .eval returns output 
with tf.Session() as sess:
    init.run()

#Since x is a placeholder,
# evaluate linear_model for several values of x simultaneously as follows:
print(sess.run(linear_model, {x: [1, 2, 3, 4]}))
#output
[ 0.          0.30000001  0.60000002  0.90000004]


##Tensflow - true y and Loss function  
#To evaluate the model on training data, 
#we need a y placeholder to provide the desired values, 
#and we need to write a loss function.

#A loss function measures how far apart the current model is from the provided data. 
#standard loss model for linear regression:
#which sums the squares of the deltas between the current model and the provided data. 


y = tf.placeholder(tf.float32)
squared_deltas = tf.square(linear_model - y)
loss = tf.reduce_sum(squared_deltas)
print(sess.run(loss, {x: [1, 2, 3, 4], y: [0, -1, -2, -3]}))
#output
23.66

##Tensflow - Training 
#Vary values of W and b to get best values where loss is zero
#machine learning is used to find the correct model parameters automatically(here W,b) 

#A variable is initialized to the value provided to tf.Variable 
#but can be changed using operations like tf.assign. 

#with -1, 1 values of W, b 
fixW = tf.assign(W, [-1.])
fixb = tf.assign(b, [1.])
sess.run([fixW, fixb])  #Execute assignments 
print(sess.run(loss, {x: [1, 2, 3, 4], y: [0, -1, -2, -3]}))
#output, perfectly minimised
0.0


###+++ Keras - Installation and configuration 
#high-level neural networks API, written in Python and capable of running on top of TensorFlow, CNTK

$ pip install keras

#By default uses Tensorflow backend 
#change it in $HOME(or %USERPROFILE%)/.keras/keras.json
#change the field backend to "theano", "tensorflow", or "cntk
{
    "image_data_format": "channels_last",
    "epsilon": 1e-07,
    "floatx": "float32",
    "backend": "tensorflow"
}

#details
�image_data_format: String, either "channels_last" or "channels_first". 
 It specifies which data format convention Keras will follow. (keras.backend.image_data_format() returns it.)
 For 2D data (e.g. image), "channels_last" assumes (rows, cols, channels) while "channels_first" assumes (channels, rows, cols). 
 For 3D data, "channels_last" assumes (conv_dim1, conv_dim2, conv_dim3, channels) while "channels_first" assumes (channels, conv_dim1, conv_dim2, conv_dim3).
�epsilon: Float, a numeric fuzzing constant used to avoid dividing by zero in some operations.
�floatx: String, "float16", "float32", or "float64". Default float precision.
�backend: String, "tensorflow", "theano", or "cntk".


#Keras can be configured with channels first or channels last, 
#besides allowing user to define it in every individual layer, so no need  to change  data. 
#However, use np.moveaxis(a, source, destination) to change 
x = np.zeros((12, 12, 3))
x.shape#yields: (12, 12, 3)
x = np.moveaxis(x, -1, 0)
x.shape#yields: (3, 12, 12)

#Also, image algorithms works with float64, not uint8
#To convert to and fro 
data = ...
info = np.iinfo(data.dtype) # Machine limits for integer types.
data = data.astype(np.float64) / info.max # normalize the data to 0 - 1
data = 255 * data # Now scale by 255
img = data.astype(np.uint8)
cv2.imshow("Window", img)



###+++ Keras - Models, optmizers, loss , metrics 
#There are two types of models available in Keras: 
#the Sequential model and the Model class used with functional API.

#These models have many common methods 
model.summary()
    prints a summary representation of model. Shortcut for utils.print_summary
model.get_config()
    returns a dictionary containing the configuration of the model. 
    The model can be reinstantiated from its config via
    #Example 
    config = model.get_config()
    model = Model.from_config(config)
    # or, for Sequential:
    model = Sequential.from_config(config)
model.get_weights()
    returns a list of all weight tensors in the model, as Numpy arrays.
model.set_weights(weights)
    sets the values of the weights of the model, from a list of Numpy arrays. 
    The arrays in the list should have the same shape as those returned by get_weights().
model.to_json()
    returns a representation of the model as a JSON string. 
    Note that the representation does not include the weights, only the architecture. 
    You can reinstantiate the same model (with reinitialized weights) from the JSON string via:
    #Example 
    from models import model_from_json
    json_string = model.to_json()
    model = model_from_json(json_string)
model.to_yaml()
    returns a representation of the model as a YAML string. 
    Note that the representation does not include the weights, only the architecture. 
    You can reinstantiate the same model (with reinitialized weights) from the YAML string via:
    #Example 
    from models import model_from_yaml
    yaml_string = model.to_yaml()
    model = model_from_yaml(yaml_string)
model.save_weights(filepath)
    saves the weights of the model as a HDF5 file.
    HDF5:A versatile data model that can represent very complex data objects and a wide variety of metadata.
    Pandas support reading from HDF5 
    df_tl = pd.DataFrame(dict(A=list(range(5)), B=list(range(5))))
    df_tl.to_hdf('store_tl.h5','table',append=True)
    pd.read_hdf('store_tl.h5', 'table', where = ['index>2'])
model.load_weights(filepath, by_name=False)
    loads the weights of the model from a HDF5 file (created by save_weights).
    By default, the architecture is expected to be unchanged. 
    To load weights into a different architecture (with some layers in common), 
    use by_name=True to load only those layers with the same name.         
model.layers 
    a list of the layers added to the model.
model.get_layer( name=None, index=None)
    Retrieve a layer that is part of the model.
    Returns a layer based on either its name (unique) or its index in the graph. 
    Indices are based on order of horizontal graph traversal (bottom-up).
    Arguments
        name: string, name of layer.
        index: integer, index of layer.
    Returns
        A layer instance.        
model.compile(optimizer, loss, metrics=None, sample_weight_mode=None, weighted_metrics=None, target_tensors=None)
    Configures the model for training.
    Arguments
        optimizer
            String (name of optimizer) or optimizer object. 
        loss
            String (name of objective function) or objective function.  
            If the model has multiple outputs, you can use a different loss on each output by passing a dictionary or a list of losses. 
            The loss value that will be minimized by the model will then be the sum of all individual losses.
        metrics
            List of metrics to be evaluated by the model during training 
            and testing. Typically you will use metrics=['accuracy']. 
            To specify different metrics for different outputs of a multi-output model, 
            you could also pass a dictionary, such as metrics={'output_a': 'accuracy'}.
        sample_weight_mode
            If you need to do timestep-wise sample weighting (2D weights), set this to "temporal". 
            None defaults to sample-wise weights (1D). 
            If the model has multiple outputs, you can use a different sample_weight_mode on each output by passing a dictionary or a list of modes.
        weighted_metrics
            List of metrics to be evaluated and weighted by sample_weight or class_weight during training and testing.
        target_tensors
            By default, Keras will create a placeholder for the model's target, 
            which will be fed with the target data during training. 
            If instead you would like to use your own target tensor (in turn, Keras will not expect external Numpy data for these targets at training time), 
            you can specify them via the target_tensors argument. 
            It should be a single tensor (for a single-output Sequential model).
        **kwargs
            When using the Theano/CNTK backends, these arguments are passed into K.function. 
            When using the TensorFlow backend, these arguments are passed into tf.Session.run.
model.fit(x=None, y=None, batch_size=None, epochs=1, verbose=1, callbacks=None, validation_split=0.0, validation_data=None, shuffle=True, class_weight=None, sample_weight=None, initial_epoch=0, steps_per_epoch=None, validation_steps=None)
    Trains the model for a fixed number of epochs (iterations on a dataset).
    Arguments
        x
            Numpy array of training data. 
            If the input layer in the model is named, you can also pass a dictionary mapping the input name to a Numpy array. 
            x can be None (default) if feeding from framework-native tensors (e.g. TensorFlow data tensors).
        y
           Numpy array of target (label) data. 
           If the output layer in the model is named, you can also pass a dictionary mapping the output name to a Numpy array. 
           y can be None (default) if feeding from framework-native tensors (e.g. TensorFlow data tensors).
        batch_size
            Integer or None. Number of samples per gradient update. 
            If unspecified, it will default to 32.
        epochs
            Integer. Number of epochs to train the model. 
            An epoch is an iteration over the entire x and y data provided. 
            Note that in conjunction with initial_epoch, 
            epochs is to be understood as "final epoch". 
            The model is not trained for a number of iterations given by epochs, 
            but merely until the epoch of index epochs is reached.
        verbose
            0, 1, or 2. Verbosity mode. 0 = silent, 1 = progress bar, 2 = one line per epoch.
        callbacks
            List of keras.callbacks.Callback instances. 
            List of callbacks to apply during training. See callbacks.
        validation_split
            Float between 0 and 1. 
            Fraction of the training data to be used as validation data. 
            The model will set apart this fraction of the training data, will not train on it, 
            and will evaluate the loss and any model metrics on this data at the end of each epoch. 
            The validation data is selected from the last samples in the x and y data provided, before shuffling.
        validation_data
            tuple (x_val, y_val) or tuple (x_val, y_val, val_sample_weights) 
            on which to evaluate the loss and any model metrics at the end of each epoch. 
            The model will not be trained on this data. 
            This will override validation_split.
        shuffle
            Boolean (whether to shuffle the training data before each epoch) or str (for 'batch'). 
            'batch' is a special option for dealing with the limitations of HDF5 data; 
            it shuffles in batch-sized chunks. Has no effect when steps_per_epoch is not None.
        class_weight
            Optional dictionary mapping class indices (integers) to a weight (float) value, 
            used for weighting the loss function (during training only). 
            This can be useful to tell the model to "pay more attention" to samples 
            from an under-represented class.
        sample_weight
            Optional Numpy array of weights for the training samples, 
            used for weighting the loss function (during training only). 
            You can either pass a flat (1D) Numpy array with the same length 
            as the input samples (1:1 mapping between weights and samples), 
            or in the case of temporal data, you can pass a 2D array with shape (samples, sequence_length), 
            to apply a different weight to every timestep of every sample. 
            In this case you should make sure to specify sample_weight_mode="temporal" in compile().
        initial_epoch
            Epoch at which to start training (useful for resuming a previous training run).
        steps_per_epoch
            Total number of steps (batches of samples) before declaring one epoch finished and starting the next epoch. 
            When training with input tensors such as TensorFlow data tensors, 
            the default None is equal to the number of samples in your dataset divided by the batch size, 
            or 1 if that cannot be determined.
        validation_steps
            Only relevant if steps_per_epoch is specified. 
            Total number of steps (batches of samples) to validate before stopping.
    Returns:  A History object. 
    Its History.history attribute is a record of training loss values 
    and metrics values at successive epochs, 
    as well as validation loss values and validation metrics values (if applicable).
model.evaluate(x, y, batch_size=32, verbose=1, sample_weight=None)
    Computes the loss on some input data, batch by batch.
    Arguments
        x: input data, as a Numpy array 
            or list of Numpy arrays (if the model has multiple inputs).
        y: labels, as a Numpy array.
        batch_size: integer. Number of samples per gradient update.
        verbose: verbosity mode, 0 or 1.
        sample_weight: sample weights, as a Numpy array.
    Return: sScalar test loss (if the model has no metrics) 
        or list of scalars (if the model computes other metrics). 
        The attribute model.metrics_names will give you the display labels 
        for the scalar outputs.
model.predict(x, batch_size=32, verbose=0)
    Generates output predictions for the input samples.
    The input samples are processed batch by batch.
    Arguments
        x: the input data, as a Numpy array.
        batch_size: integer.
        verbose: verbosity mode, 0 or 1.
    Returns:  A Numpy array of predictions.
model.train_on_batch(x, y, class_weight=None, sample_weight=None)
    Single gradient update over one batch of samples.
    Arguments
        x: input data, as a Numpy array or list of Numpy arrays (if the model has multiple inputs).
        y: labels, as a Numpy array.
        class_weight: dictionary mapping classes to a weight value, used for scaling the loss function (during training only).
        sample_weight: sample weights, as a Numpy array.
    Returns : Scalar training loss (if the model has no metrics) or list of scalars (if the model computes other metrics). The attribute model.metrics_names will give you the display labels for the scalar outputs.
model.test_on_batch(x, y, sample_weight=None)
    Evaluates the model over a single batch of samples.
    Arguments
        x: input data, as a Numpy array or list of Numpy arrays (if the model has multiple inputs).
        y: labels, as a Numpy array.
        sample_weight: sample weights, as a Numpy array.
    Returns
    Scalar test loss (if the model has no metrics) or list of scalars (if the model computes other metrics). The attribute model.metrics_names will give you the display labels for the scalar outputs.
model.predict_on_batch(x)
    Returns predictions for a single batch of samples.
    Arguments
        x: input data, as a Numpy array or list of Numpy arrays (if the model has multiple inputs).
    Returns
    A Numpy array of predictions.
model.fit_generator(generator, steps_per_epoch=None, epochs=1, verbose=1, callbacks=None, validation_data=None, validation_steps=None, class_weight=None, max_queue_size=10, workers=1, use_multiprocessing=False, shuffle=True, initial_epoch=0)
    Fits the model on data generated batch-by-batch by a Python generator.
    The generator is run in parallel to the model, for efficiency. 
    For instance, this allows you to do real-time data augmentation 
    on images on CPU in parallel to training your model on GPU.
    Arguments
        generator: A generator. The output of the generator must be either
            a tuple (inputs, targets)
            a tuple (inputs, targets, sample_weights). 
            All arrays should contain the same number of samples. 
            The generator is expected to loop over its data indefinitely. 
            An epoch finishes when steps_per_epoch batches have been seen by the model.
        steps_per_epoch: Total number of steps (batches of samples) 
            to yield from generator before declaring one epoch finished and starting the next epoch. 
            It should typically be equal to the number of samples of your dataset divided by the batch size. 
            Optional for Sequence: if unspecified, will use the len(generator) 
            as a number of steps.
        epochs: Integer, total number of iterations on the data. 
            Note that in conjunction with initial_epoch, the parameter epochs is to be understood as "final epoch". 
            The model is not trained for n steps given by epochs, 
            but until the epoch epochs is reached.
        verbose: Verbosity mode, 0, 1, or 2.
        callbacks: List of callbacks to be called during training.
        validation_data: This can be either
            A generator for the validation data
            A tuple (inputs, targets)
            A tuple (inputs, targets, sample_weights).
        validation_steps: Only relevant if validation_data is a generator. Number of steps to yield from validation generator at the end of every epoch. It should typically be equal to the number of samples of your validation dataset divided by the batch size. Optional for Sequence: if unspecified, will use the len(validation_data) as a number of steps.
        class_weight: Dictionary mapping class indices to a weight for the class.
        max_queue_size: Maximum size for the generator queue
        workers: Maximum number of processes to spin up
        use_multiprocessing: if True, use process based threading. Note that because this implementation relies on multiprocessing, you should not pass non picklable arguments to the generator as they can't be passed easily to children processes.
        shuffle: Whether to shuffle the order of the batches at the beginning of each epoch. Only used with instances of Sequence (keras.utils.Sequence).
        initial_epoch: Epoch at which to start training (useful for resuming a previous training run).
    Returns:    A History object.
    Raises
        RuntimeError: if the model was never compiled.
    #Example
    def generate_arrays_from_file(path):
        while 1:
            f = open(path)
            for line in f:
                # create Numpy arrays of input data
                # and labels, from each line in the file
                x, y = process_line(line)
                yield (x, y)
            f.close()
    model.fit_generator(generate_arrays_from_file('/my_file.txt'),steps_per_epoch=1000, epochs=10)
model.evaluate_generator(generator, steps=None, max_queue_size=10, workers=1, use_multiprocessing=False)
    Evaluates the model on a data generator.
    The generator should return the same kind of data as accepted by test_on_batch.
    Arguments
        generator: Generator yielding tuples (inputs, targets) or (inputs, targets, sample_weights)
        steps: Total number of steps (batches of samples) to yield from generator before stopping. Optional for Sequence: if unspecified, will use the len(generator) as a number of steps.
        max_queue_size: maximum size for the generator queue
        workers: maximum number of processes to spin up
        use_multiprocessing: if True, use process based threading. Note that because this implementation relies on multiprocessing, you should not pass non picklable arguments to the generator as they can't be passed easily to children processes.
    Returns
        Scalar test loss (if the model has no metrics) or list of scalars (if the model computes other metrics). The attribute model.metrics_names will give you the display labels for the scalar outputs.
    Raises
        RuntimeError: if the model was never compiled.
model.predict_generator(generator, steps=None, max_queue_size=10, workers=1, use_multiprocessing=False, verbose=0)
    Generates predictions for the input samples from a data generator.
    The generator should return the same kind of data as accepted by predict_on_batch.
    Arguments
        generator: generator yielding batches of input samples.
        steps: Total number of steps (batches of samples) to yield from generator before stopping. Optional for Sequence: if unspecified, will use the len(generator) as a number of steps.
        max_queue_size: maximum size for the generator queue
        workers: maximum number of processes to spin up
        use_multiprocessing: if True, use process based threading. Note that because this implementation relies on multiprocessing, you should not pass non picklable arguments to the generator as they can't be passed easily to children processes.
        verbose: verbosity mode, 0 or 1.
    Returns
        A Numpy array of predictions.
        
        
        
#Methods at keras lavel       
keras.models.save_model(model, filepath, overwrite=True, include_optimizer=True):
    Save a model to a HDF5 file.
    The saved model contains:
        - the model's configuration (topology)
        - the model's weights
        - the model's optimizer's state (if any)        
keras.models.load_model(filepath, custom_objects=None, compile=True):
    Loads a model saved via `save_model`.    
    Returns
            A Keras model instance  
keras.models.model_from_json(json_string, custom_objects=None):
    Parses a JSON model configuration file and returns a model instance.
    
keras.models.model_from_yaml(yaml_string, custom_objects=None):
    Parses a yaml model configuration file and returns a model instance.
                 
        
            
##Keras - Utils
keras.utils.HDF5Matrix(datapath, dataset, start=0, end=None, normalizer=None)
    Representation of HDF5 dataset to be used instead of a Numpy array.
    #Example
        x_data = HDF5Matrix('input/file.hdf5', 'data')
        model.predict(x_data)
    Providing start and end allows use of a slice of the dataset.
    Optionally, a normalizer function (or lambda) can be given. 
    This will be called on every slice of data retrieved.
    Arguments
        datapath: string, path to a HDF5 file
        dataset: string, name of the HDF5 dataset in the file specified in datapath
        start: int, start of desired slice of the specified dataset
        end: int, end of desired slice of the specified dataset
        normalizer: function to be called on data when retrieved
    Returns
        An array-like HDF5 dataset.


keras.utils.Sequence()
    Base object for fitting to a sequence of data
    Every Sequence must implements the __getitem__ and the __len__ methods. 
    If you want to modify your dataset between epochs 
    you may implement on_epoch_end. 
    The method __getitem__ should return a complete batch.
    Sequence are a safer way to do multiprocessing. 
    This structure guarantees that the network will only train once on each sample per epoch 
    which is not the case with generators.
    #Examples
    from skimage.io import imread
    from skimage.transform import resize
    import numpy as np
    import math

    # Here, `x_set` is list of path to the images
    # and `y_set` are the associated classes.

    class CIFAR10Sequence(Sequence):

        def __init__(self, x_set, y_set, batch_size):
            self.x, self.y = x_set, y_set
            self.batch_size = batch_size

        def __len__(self):
            return math.ceil(len(self.x) / self.batch_size)

        def __getitem__(self, idx):
            batch_x = self.x[idx * self.batch_size:(idx + 1) * self.batch_size]
            batch_y = self.y[idx * self.batch_size:(idx + 1) * self.batch_size]

            return np.array([
                resize(imread(file_name), (200, 200))
                   for file_name in batch_x]), np.array(batch_y)



keras.utils.to_categorical(y, num_classes=None)
    Converts a class vector (integers) to binary class matrix(one hot encoding)
    E.g. for use with categorical_crossentropy.
    Arguments
        y: class vector to be converted into a matrix (integers from 0 to num_classes).
        num_classes: total number of classes.
    Returns
        A binary matrix representation of the input.


keras.utils.normalize(x, axis=-1, order=2)
    Normalizes a Numpy array.
    Arguments
        x: Numpy array to normalize.
        axis: axis along which to normalize.
        order: Normalization order (e.g. 2 for L2 norm).
    Returns
        A normalized copy of the array.


keras.utils.get_file(fname, origin, untar=False, md5_hash=None, file_hash=None, cache_subdir='datasets', hash_algorithm='auto', extract=False, archive_format='auto', cache_dir=None)
    Downloads a file from a URL if it not already in the cache.
    Default cache_dir ~/.keras, 
    For example: The final location of a file example.txt = ~/.keras/datasets/example.txt.
    Files in tar, tar.gz, tar.bz, and zip formats can also be extracted. 
    Passing a hash will verify the file after download. 
    The command line programs shasum and sha256sum can compute the hash.
    Arguments
        fname: Name of the file. If an absolute path /path/to/file.txt is specified the file will be saved at that location.
        origin: Original URL of the file.
        extract: True tries extracting the file as an Archive, like tar or zip.
    Returns
    Path to the downloaded file


keras.utils.print_summary(model, line_length=None, positions=None, print_fn=<built-in function print>)
    Prints a summary of a model.
    Arguments
        model: Keras model instance.
        line_length: Total length of printed lines (e.g. set this to adapt the display to different terminal window sizes).
        positions: Relative or absolute positions of log elements in each line. If not provided, defaults to [.33, .55, .67, 1.].
        print_fn: Print function to use. It will be called on each line of the summary. You can set it to a custom function in order to capture the string summary.


keras.utils.plot_model(model, to_file='model.png', show_shapes=False, show_layer_names=True, rankdir='TB')
    Converts a Keras model to dot format and save to a file.
    Arguments
        model: A Keras model instance
        to_file: File name of the plot image.
        show_shapes: whether to display shape information.
        show_layer_names: whether to display layer names.
        rankdir: rankdir argument passed to PyDot, a string specifying the format of the plot: 'TB' creates a vertical plot; 'LR' creates a horizontal plot.


        
        
##Keras - Optimizers
#An optimizer is one of the two arguments required for compiling a Keras model

from keras import optimizers

model = Sequential()
model.add(Dense(64, kernel_initializer='uniform', input_shape=(10,)))
model.add(Activation('tanh'))
model.add(Activation('softmax'))

sgd = optimizers.SGD(lr=0.01, decay=1e-6, momentum=0.9, nesterov=True)
model.compile(loss='mean_squared_error', optimizer=sgd)
#OR , sgd with default values 
model.compile(loss='mean_squared_error', optimizer='sgd')



##Keras - Optimizers - Parameters common to all Keras optimizers
#The parameters clipnorm and clipvalue can be used with all optimizers 
#to control gradient clipping:

from keras import optimizers

# All parameter gradients will be clipped to
# a maximum norm of 1.
sgd = optimizers.SGD(lr=0.01, clipnorm=1.)

from keras import optimizers

# All parameter gradients will be clipped to
# a maximum value of 0.5 and
# a minimum value of -0.5.
sgd = optimizers.SGD(lr=0.01, clipvalue=0.5)




##Keras - Optimizers - List of Optimizers
keras.optimizers.TFOptimizer(optimizer)
    Wrapper class for native TensorFlow optimizers.
    
    
keras.optimizers.SGD(lr=0.01, momentum=0.0, decay=0.0, nesterov=False)
    Stochastic gradient descent optimizer.
    Includes support for momentum, learning rate decay, and Nesterov momentum.
    Arguments
        lr: float >= 0. Learning rate.
        momentum: float >= 0. Parameter updates momentum.
        decay: float >= 0. Learning rate decay over each update.
        nesterov: boolean. Whether to apply Nesterov momentum.

keras.optimizers.RMSprop(lr=0.001, rho=0.9, epsilon=1e-08, decay=0.0)
    RMSProp optimizer.
    It is recommended to leave the parameters of this optimizer 
    at their default values (except the learning rate, which can be freely tuned).
    This optimizer is usually a good choice for recurrent neural networks.
    Arguments
        lr: float >= 0. Learning rate.
        rho: float >= 0.
        epsilon: float >= 0. Fuzz factor.
        decay: float >= 0. Learning rate decay over each update.

keras.optimizers.Adagrad(lr=0.01, epsilon=1e-08, decay=0.0)
    Adagrad optimizer.
    It is recommended to leave the parameters of this optimizer at their default values.
    Arguments
        lr: float >= 0. Learning rate.
        epsilon: float >= 0.
        decay: float >= 0. Learning rate decay over each update.


keras.optimizers.Adadelta(lr=1.0, rho=0.95, epsilon=1e-08, decay=0.0)
    Adadelta optimizer.
    It is recommended to leave the parameters of this optimizer  at their default values.
    Arguments
        lr: float >= 0. Learning rate. It is recommended to leave it at the default value.
        rho: float >= 0.
        epsilon: float >= 0. Fuzz factor.
        decay: float >= 0. Learning rate decay over each update.

keras.optimizers.Adam(lr=0.001, beta_1=0.9, beta_2=0.999, epsilon=1e-08, decay=0.0)
    Adam optimizer.
    Default parameters follow those provided in the original paper.
    Arguments
        lr: float >= 0. Learning rate.
        beta_1: float, 0 < beta < 1. Generally close to 1.
        beta_2: float, 0 < beta < 1. Generally close to 1.
        epsilon: float >= 0. Fuzz factor.
        decay: float >= 0. Learning rate decay over each update.


keras.optimizers.Adamax(lr=0.002, beta_1=0.9, beta_2=0.999, epsilon=1e-08, decay=0.0)
    Adamax optimizer from Adam paper's Section 7.
    It is a variant of Adam based on the infinity norm. 
    Default parameters follow those provided in the paper.
    Arguments
        lr: float >= 0. Learning rate.
        beta_1/beta_2: floats, 0 < beta < 1. Generally close to 1.
        epsilon: float >= 0. Fuzz factor.
        decay: float >= 0. Learning rate decay over each update.

keras.optimizers.Nadam(lr=0.002, beta_1=0.9, beta_2=0.999, epsilon=1e-08, schedule_decay=0.004)
    Nesterov Adam optimizer.
    Much like Adam is essentially RMSprop with momentum,
    Nadam is Adam RMSprop with Nesterov momentum.
    Default parameters follow those provided in the paper. 
    It is recommended to leave the parameters of this optimizer at their default values.
    Arguments
        lr: float >= 0. Learning rate.
        beta_1/beta_2: floats, 0 < beta < 1. Generally close to 1.
        epsilon: float >= 0. Fuzz factor.





    
        
##Keras - Losses

#A loss function (or objective function, or optimization score function) 
#is one of the two parameters required to compile a model:
model.compile(loss='mean_squared_error', optimizer='sgd')

from keras import losses
model.compile(loss=losses.mean_squared_error, optimizer='sgd')

#You can either pass the name of an existing loss function, 
#or pass a TensorFlow/Theano symbolic function 
#that returns a scalar for each data-point and takes the following two arguments:
y_true
    True labels. TensorFlow/Theano tensor.
y_pred
    Predictions. TensorFlow/Theano tensor of the same shape as y_true.


#Available loss functions
mean_squared_error(y_true, y_pred)
mean_absolute_error(y_true, y_pred)
mean_absolute_percentage_error(y_true, y_pred)
mean_squared_logarithmic_error(y_true, y_pred)
squared_hinge(y_true, y_pred)
hinge(y_true, y_pred)
categorical_hinge(y_true, y_pred)
logcosh(y_true, y_pred)
    Logarithm of the hyperbolic cosine of the prediction error.
categorical_crossentropy(y_true, y_pred)
sparse_categorical_crossentropy(y_true, y_pred)
binary_crossentropy(y_true, y_pred)
kullback_leibler_divergence(y_true, y_pred)
poisson(y_true, y_pred)
cosine_proximity(y_true, y_pred)


#when using the categorical_crossentropy loss, 
#your targets should be in categorical format 
#(e.g. if you have 10 classes, the target for each sample should be a 10-dimensional vector 
#that is all-zeros expect for a 1 at the index corresponding to the class of the sample). 

#In order to convert integer targets into categorical targets, 
#use the Keras utility to_categorical:

from keras.utils.np_utils import to_categorical
categorical_labels = to_categorical(int_labels, num_classes=None)



##Keras - Metrics
#A metric is a function that is used to judge the performance of model. 

from keras import metrics

model.compile(loss='mean_squared_error',
              optimizer='sgd',
              metrics=[metrics.mae, metrics.categorical_accuracy])

#A metric function is similar to an loss function, 
#except that the results from evaluating a metric are not used when training the model.

#You can either pass the name of an existing metric, 
#or pass a Theano/TensorFlow symbolic function 
#Arguments
y_true
    True labels. Theano/TensorFlow tensor.
y_pred
    Predictions. Theano/TensorFlow tensor of the same shape as y_true.

#Available metrics
binary_accuracy(y_true, y_pred)
categorical_accuracy(y_true, y_pred)
sparse_categorical_accuracy(y_true, y_pred)
top_k_categorical_accuracy(y_true, y_pred, k=5)
sparse_top_k_categorical_accuracy(y_true, y_pred, k=5)


##Custom metrics

import keras.backend as K

def mean_pred(y_true, y_pred):
    return K.mean(y_pred)

model.compile(optimizer='rmsprop',
              loss='binary_crossentropy',
              metrics=['accuracy', mean_pred])
              
              

              

    

###+++ Keras- Sequential model

#The Sequential model is a linear stack of layers.


##Keras- Sequential Model 
#use Numpy arrays of input data and labels. 
1. Create a model 
2. Compile 
3. fit 
4. evaluate 

##Keras- Sequential - Model creation 

from keras.models import Sequential
from keras.layers import Dense, Activation

model = Sequential([
    Dense(32, input_shape=(784,)),  #units: dimensionality of the output space ie input 784 to output 32 
    Activation('relu'),
    Dense(10),                      #output=10 
    Activation('softmax'),
])

#OR add layers via the .add() method:

model = Sequential()
model.add(Dense(32, input_dim=784))
model.add(Activation('relu'))

##Keras- Sequential - Specifying the input shape for first layer 
#only the first, because following layers can do automatic shape inference
Pass an input_shape argument to the first layer. 
    This is a shape tuple (a tuple of integers or None entries, 
    where None indicates that any positive integer may be expected). 
    In input_shape, the batch dimension is not included.
Some 2D layers, such as Dense, support the specification of their input shape 
    via the argument input_dim, 
    and some 3D temporal layers support the arguments input_dim and input_length.
If you ever need to specify a fixed batch size for your inputs 
    (this is useful for stateful recurrent networks), 
    you can pass a batch_size argument to a layer. 
    If you pass both batch_size=32 and input_shape=(6, 8) to a layer, 
    it will then expect every batch of inputs to have the batch shape (32, 6, 8).

#equivalent code
model = Sequential()
model.add(Dense(32, input_shape=(784,)))  #32 is output of this step 
#OR 
model = Sequential()
model.add(Dense(32, input_dim=784))

##Keras- Sequential - Compilation - before training 
#pass three arguments:
An optimizer. 
    This could be the string identifier of an existing optimizer (such as rmsprop or adagrad), 
    or an instance of the Optimizer class. 
A loss function. 
    This is the objective that the model will try to minimize. 
    It can be the string identifier of an existing loss function (such as categorical_crossentropy or mse), 
    or it can be an objective function.
A list of metrics. 
    For any classification problem you will want to set this to metrics=['accuracy']. 
    A metric could be the string identifier of an existing metric 
    or a custom metric function.

# For a multi-class classification problem
model.compile(optimizer='rmsprop',
              loss='categorical_crossentropy',
              metrics=['accuracy'])

# For a binary classification problem
model.compile(optimizer='rmsprop',
              loss='binary_crossentropy',
              metrics=['accuracy'])

# For a mean squared error regression problem
model.compile(optimizer='rmsprop',
              loss='mse')




##Keras- Sequential Model - For a single-input model with 2 classes (binary classification):

model = Sequential()
model.add(Dense(32, activation='relu', input_dim=100)) #input=100, output=32 
model.add(Dense(1, activation='sigmoid')) #output 1 
model.compile(optimizer='rmsprop',
              loss='binary_crossentropy',
              metrics=['accuracy'])

# Generate dummy data
import numpy as np
data = np.random.random((1000, 100)) #1000 obs with 100 features as input is 100 
labels = np.random.randint(2, size=(1000, 1)) #for each obs , generate 0,1 

#There are n samples and the batch_size is b(at a time b chunk from n samples is taken) , 
#num_epoch(no of times n samples is taken to generate b batch size)  = steps*b/n
#where steps = no of times training loop will run to update wights
 
# Train the model, iterating on the data in batches of 32 samples
model.fit(data, labels, epochs=10, batch_size=32)





##Keras- Sequential Model -  For a single-input model with 10 classes (categorical classification):
model = Sequential()
model.add(Dense(32, activation='relu', input_dim=100))
model.add(Dense(10, activation='softmax'))
model.compile(optimizer='rmsprop',
              loss='categorical_crossentropy',
              metrics=['accuracy'])

# Generate dummy data
import numpy as np
data = np.random.random((1000, 100))
labels = np.random.randint(10, size=(1000, 1))#for each obs , generate 0-9

# Convert labels to categorical one-hot encoding
one_hot_labels = keras.utils.to_categorical(labels, num_classes=10)

# Train the model, iterating on the data in batches of 32 samples
model.fit(data, one_hot_labels, epochs=10, batch_size=32)




##Keras- Sequential Model -  Multilayer Perceptron (MLP) for multi-class softmax classification:
import keras
from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation
from keras.optimizers import SGD

# Generate dummy data
import numpy as np
x_train = np.random.random((1000, 20)) # samples 1000, features=20 
y_train = keras.utils.to_categorical(np.random.randint(10, size=(1000, 1)), num_classes=10)
x_test = np.random.random((100, 20))
y_test = keras.utils.to_categorical(np.random.randint(10, size=(100, 1)), num_classes=10)

model = Sequential()
# Dense(64) is a fully-connected layer with 64 hidden units.
# in the first layer, you must specify the expected input data shape:
# here, 20-dimensional vectors.
model.add(Dense(64, activation='relu', input_dim=20)) #input=number of features, output=64 
model.add(Dropout(0.5))  #50% dropout, used for controlling overfitting 
model.add(Dense(64, activation='relu')) #output 64 
model.add(Dropout(0.5))
model.add(Dense(10, activation='softmax')) #output=10 

sgd = SGD(lr=0.01, decay=1e-6, momentum=0.9, nesterov=True)
model.compile(loss='categorical_crossentropy',
              optimizer=sgd,
              metrics=['accuracy'])
              
              
model.fit(x_train, y_train,
          epochs=20,
          batch_size=128)  #at a time 128 samples of 20(input_dims) features are fed to Input layer, #of epochs times full dataset is used 
score = model.evaluate(x_test, y_test, batch_size=128)

y_predict = model.predict(x_test, batch_size=32, verbose=0)




##Keras- Sequential Model -  MLP for binary classification:
import numpy as np
from keras.models import Sequential
from keras.layers import Dense, Dropout

# Generate dummy data
x_train = np.random.random((1000, 20))
y_train = np.random.randint(2, size=(1000, 1))
x_test = np.random.random((100, 20))
y_test = np.random.randint(2, size=(100, 1))

model = Sequential()
model.add(Dense(64, input_dim=20, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(64, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(1, activation='sigmoid'))

model.compile(loss='binary_crossentropy',
              optimizer='rmsprop',
              metrics=['accuracy'])

model.fit(x_train, y_train,
          epochs=20,
          batch_size=128)
score = model.evaluate(x_test, y_test, batch_size=128)



##Keras- Sequential Model -  VGG-like CNN - multiclass 
import numpy as np
import keras
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten
from keras.layers import Conv2D, MaxPooling2D
from keras.optimizers import SGD

# Generate dummy data
x_train = np.random.random((100, 100, 100, 3)) # 100 obs of 100x100x3 ie 100 htx 100 width with 3 channels 
y_train = keras.utils.to_categorical(np.random.randint(10, size=(100, 1)), num_classes=10)
x_test = np.random.random((20, 100, 100, 3))
y_test = keras.utils.to_categorical(np.random.randint(10, size=(20, 1)), num_classes=10)

model = Sequential()
# input: 100x100 images with 3 channels -> (100, 100, 3) tensors.
# this applies 32 convolution filters of size 3x3 each(out of 100x100). ie filtersize=32=output size 
model.add(Conv2D(32, (3, 3), activation='relu', input_shape=(100, 100, 3)))
model.add(Conv2D(32, (3, 3), activation='relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))  #maximum of 2x2 
model.add(Dropout(0.25)) #25% dropout 

model.add(Conv2D(64, (3, 3), activation='relu'))
model.add(Conv2D(64, (3, 3), activation='relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.25))

model.add(Flatten())     #flattening to 1D
model.add(Dense(256, activation='relu')) #output 256 
model.add(Dropout(0.5))
model.add(Dense(10, activation='softmax')) #output=10 

sgd = SGD(lr=0.01, decay=1e-6, momentum=0.9, nesterov=True)
model.compile(loss='categorical_crossentropy', optimizer=sgd)

model.fit(x_train, y_train, batch_size=32, epochs=10)  #10 times full data is used with chunk of 32 batch size from 100 samples 
score = model.evaluate(x_test, y_test, batch_size=32)



##Keras- Sequential Model -  Sequence classification with LSTM(Long short-term memory )
from keras.models import Sequential
from keras.layers import Dense, Dropout
from keras.layers import Embedding
from keras.layers import LSTM

model = Sequential()
#Embedding is used to convert a sparse data(eg data containing index integers upto input_dim max ) to dense vectors of fixed size of output_dim as required in NN  
model.add(Embedding(max_features, output_dim=256)) #input_dim, output_dim, 
model.add(LSTM(128))  #output=128 
model.add(Dropout(0.5))
model.add(Dense(1, activation='sigmoid'))

model.compile(loss='binary_crossentropy',
              optimizer='rmsprop',
              metrics=['accuracy'])

model.fit(x_train, y_train, batch_size=16, epochs=10)
score = model.evaluate(x_test, y_test, batch_size=16)

##Keras- Sequential Model -  Sequence classification with 1D convolutions
from keras.models import Sequential
from keras.layers import Dense, Dropout
from keras.layers import Embedding
from keras.layers import Conv1D, GlobalAveragePooling1D, MaxPooling1D

model = Sequential()
model.add(Conv1D(64, 3, activation='relu', input_shape=(seq_length, 100))) #64 conv filter of window size 3 , outputsize=64
model.add(Conv1D(64, 3, activation='relu'))
model.add(MaxPooling1D(3))
model.add(Conv1D(128, 3, activation='relu'))
model.add(Conv1D(128, 3, activation='relu'))
model.add(GlobalAveragePooling1D())
model.add(Dropout(0.5))
model.add(Dense(1, activation='sigmoid'))

model.compile(loss='binary_crossentropy',
              optimizer='rmsprop',
              metrics=['accuracy'])

model.fit(x_train, y_train, batch_size=16, epochs=10)
score = model.evaluate(x_test, y_test, batch_size=16)

##Keras- Sequential Model -  Stacked LSTM for sequence classification
#In this model, we stack 3 LSTM layers on top of each other, 
#making the model capable of learning higher-level temporal representations.

#The first two LSTMs return their full output sequences, 
#but the last one only returns the last step in its output sequence, 
#thus dropping the temporal dimension 
#(i.e. converting the input sequence into a single vector).

#stacked LSTM

from keras.models import Sequential
from keras.layers import LSTM, Dense
import numpy as np

data_dim = 16
timesteps = 8
num_classes = 10

# expected input data shape: (batch_size, timesteps, data_dim)
model = Sequential()
model.add(LSTM(32, return_sequences=True,
               input_shape=(timesteps, data_dim)))  # returns a sequence of vectors of dimension 32
model.add(LSTM(32, return_sequences=True))  # returns a sequence of vectors of dimension 32
model.add(LSTM(32))  # return a single vector of dimension 32
model.add(Dense(10, activation='softmax'))

model.compile(loss='categorical_crossentropy',
              optimizer='rmsprop',
              metrics=['accuracy'])

# Generate dummy training data
x_train = np.random.random((1000, timesteps, data_dim))
y_train = np.random.random((1000, num_classes))

# Generate dummy validation data
x_val = np.random.random((100, timesteps, data_dim))
y_val = np.random.random((100, num_classes))

model.fit(x_train, y_train,
          batch_size=64, epochs=5,
          validation_data=(x_val, y_val))

##Keras- Sequential Model -  above stacked LSTM model, rendered "stateful"
#A stateful recurrent model is one for which the internal states (memories) 
#obtained after processing a batch of samples are reused as initial states 
#for the samples of the next batch. 

#This allows to process longer sequences while keeping computational complexity manageable.


from keras.models import Sequential
from keras.layers import LSTM, Dense
import numpy as np

data_dim = 16
timesteps = 8
num_classes = 10
batch_size = 32

# Expected input batch shape: (batch_size, timesteps, data_dim)
# Note that we have to provide the full batch_input_shape since the network is stateful.
# the sample of index i in batch k is the follow-up for the sample i in batch k-1.
model = Sequential()
model.add(LSTM(32, return_sequences=True, stateful=True,
               batch_input_shape=(batch_size, timesteps, data_dim)))
model.add(LSTM(32, return_sequences=True, stateful=True))
model.add(LSTM(32, stateful=True))
model.add(Dense(10, activation='softmax'))

model.compile(loss='categorical_crossentropy',
              optimizer='rmsprop',
              metrics=['accuracy'])

# Generate dummy training data
x_train = np.random.random((batch_size * 10, timesteps, data_dim))
y_train = np.random.random((batch_size * 10, num_classes))

# Generate dummy validation data
x_val = np.random.random((batch_size * 3, timesteps, data_dim))
y_val = np.random.random((batch_size * 3, num_classes))

model.fit(x_train, y_train,
          batch_size=batch_size, epochs=5, shuffle=False,
          validation_data=(x_val, y_val))


          
##Keras Reference - The Sequential model API
Sequential(layers=None, name=None)
    The first layer passed to a Sequential model
    should have a defined input shape. ie it should have received an `input_shape`
    or `batch_input_shape` argument,
    or for some type of layers (recurrent, Dense...)  an `input_dim` argument.
    #Properties 
    layers = []  # Stack of layers.
    model = None  # Internal Model instance.
    inputs = []  # List of input tensors
    outputs = []  # List of length 1: the output tensor (unique).
    #Methods other than Model base methods 
    add(layer)
        Adds a layer instance on top of the layer stack.
    pop()
        Removes the last layer in the model.
    get_losses_for(inputs)
        returns loss for this inputs 
    predict_proba(self, x, batch_size=None, verbose=0, steps=None):
        Generates class probability predictions for the input samples.
        The input samples are processed batch by batch.
        # Arguments
            x: input data, as a Numpy array or list of Numpy arrays
                (if the model has multiple inputs).
            batch_size: Integer. If unspecified, it will default to 32.
            verbose: verbosity mode, 0 or 1.
            steps: Total number of steps (batches of samples)
                   before declaring the prediction round finished.
                   Ignored with the default value of `None`.
        # Returns
            A Numpy array of probability predictions.
    predict_classes(self, x, batch_size=None, verbose=0, steps=None):
        Generate class predictions for the input samples.
        The input samples are processed batch by batch.
        # Arguments
            x: input data, as a Numpy array or list of Numpy arrays
                (if the model has multiple inputs).
            batch_size: Integer. If unspecified, it will default to 32.
            verbose: verbosity mode, 0 or 1.
            steps: Total number of steps (batches of samples)
                before declaring the prediction round finished.
                Ignored with the default value of `None`.
        # Returns
            A numpy array of class predictions.
    #Common methods 
    summary()
    get_config()
    get_weights()
    set_weights(weights)
    to_json()
    to_yaml()
    save_weights(filepath)
    load_weights(filepath, by_name=False)     
    get_layer( name=None, index=None)   
    compile(optimizer, loss, metrics=None, sample_weight_mode=None, weighted_metrics=None, target_tensors=None)
    fit(x=None, y=None, batch_size=None, epochs=1, verbose=1, callbacks=None, validation_split=0.0, validation_data=None, shuffle=True, class_weight=None, sample_weight=None, initial_epoch=0, steps_per_epoch=None, validation_steps=None)
    evaluate(x, y, batch_size=32, verbose=1, sample_weight=None)
    predict(x, batch_size=32, verbose=0)
    train_on_batch(x, y, class_weight=None, sample_weight=None)
    test_on_batch(x, y, sample_weight=None)
    predict_on_batch(x)
    fit_generator(generator, steps_per_epoch=None, epochs=1, verbose=1, callbacks=None, validation_data=None, validation_steps=None, class_weight=None, max_queue_size=10, workers=1, use_multiprocessing=False, shuffle=True, initial_epoch=0)
    evaluate_generator(generator, steps=None, max_queue_size=10, workers=1, use_multiprocessing=False)
    predict_generator(generator, steps=None, max_queue_size=10, workers=1, use_multiprocessing=False, verbose=0)

    
keras.models.clone_model(model, input_tensors=None):
    Clone any `Model` instance.
    Model cloning is similar to calling a model on new inputs,
    except that it creates new layers (and thus new weights) instead
    of sharing the weights of the existing layers.
    # Arguments
        model: Instance of `Model`
            (could be a functional model or a Sequential model).
        input_tensors: optional list of input tensors
            to build the model upon. If not provided,
            placeholders will be created.
    # Returns
        An instance of `Model` reproducing the behavior
        of the original model, on top of new inputs tensors,
        using newly instantiated weights.
   
      
   
##Keras - Sequential - Word Embedding
#A word embedding is a class of approaches for representing words and documents using a dense vector representation.

#It is an improvement over more the traditional bag-of-word model encoding schemes where large sparse vectors were used to represent each word 
#Instead, in an embedding, words are represented by dense vectors where a vector represents the projection of the word into a continuous vector space.
#The position of a word within the vector space is learned from text and is based on the words that surround the word when it is used.

#Keras Embedding Layer
#It requires that the input data be integer encoded, so that each word is represented by a unique integer. 
#for example, indexes to word repositories 
#The Embedding layer has weights that are learned. 
#The output of the Embedding layer is a 2D vector with one embedding for each word in the input sequence of words (input document).
#To connect a Dense layer directly to an Embedding layer, flatten the 2D output matrix to a 1D vector using the Flatten layer.


e = Embedding(200, 32, input_length=50)

#arguments:
input_dim
    This is the size of the vocabulary in the text data. 
    For example, if your data is integer encoded to values between 0-10, 
    then the size of the vocabulary would be 11 words.
output_dim
    This is the size of the vector space in which words will be embedded. 
    It defines the size of the output vectors from this layer for each word. 
    For example, it could be 32 or 100 or even larger. 
input_length
    This is the length of input sequences, as you would define for any input layer of a Keras model. 
    For example, if all of your input documents are comprised of 1000 words, this would be 1000.

#Example 
 
from numpy import array
from keras.preprocessing.text import one_hot
from keras.preprocessing.sequence import pad_sequences
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Flatten
from keras.layers.embeddings import Embedding
# define documents, max length=4
docs = ['Well done!',
		'Good work',
		'Great effort',
		'nice work',
		'Excellent!',
		'Weak',
		'Poor effort!',
		'not good',
		'poor work',
		'Could have done better.']
# define class labels
labels = array([1,1,1,1,1,0,0,0,0,0])


#integer encode each document(element of docs)
keras.preprocessing.text.one_hot(text,n,
             filters='!"#$%&()*+,-./:;<=>@[\\]^_`{|}~\t\n', lower=True,  split=" ")
    One-hot encodes a text into a list of word indexes in a vocabulary of size n.
    Note to get real on hot encoding, use keras.utils.to_categorical(y, num_classes=None)


# integer encode the documents
vocab_size = 50
encoded_docs = [one_hot(d, vocab_size) for d in docs]
print(encoded_docs)

#Output : The sequences have different lengths and Keras prefers inputs to be vectorized and all inputs to have the same length. 
keras.preprocessing.sequence.pad_sequences(sequences, maxlen=None, dtype='int32',
            padding='pre', truncating='pre', value=0.)
    Transform a list of lists of scalars . 
    Each list is made to have same length, maxlen using padd value 0 


# pad documents to a max length of 4 words
max_length = 4
padded_docs = pad_sequences(encoded_docs, maxlen=max_length, padding='post')
print(padded_docs)

#Now, The Embedding has a vocabulary of 50 and an input length of 4.
#the output from the Embedding layer will be 4 vectors of 8 dimensions each, one for each word. 

# define the model
model = Sequential()
model.add(Embedding(vocab_size, 8, input_length=max_length))
model.add(Flatten())
model.add(Dense(1, activation='sigmoid'))
# compile the model
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['acc'])
# summarize the model
print(model.summary())


# fit the model
model.fit(padded_docs, labels, epochs=50, verbose=0)
# evaluate the model
loss, accuracy = model.evaluate(padded_docs, labels, verbose=0)
print('Accuracy: %f' % (accuracy*100))

#Output  
#Running the example first prints the integer encoded documents.
[[6, 16], [42, 24], [2, 17], [42, 24], [18], [17], [22, 17], [27, 42], [22, 24], [49, 46, 16, 34]]
#Then the padded versions of each document are printed, making them all uniform length.
 [[ 6 16  0  0]
 [42 24  0  0]
 [ 2 17  0  0]
 [42 24  0  0]
 [18  0  0  0]
 [17  0  0  0]
 [22 17  0  0]
 [27 42  0  0]
 [22 24  0  0]
 [49 46 16 34]]

#After the network is defined, a summary of the layers is printed. 
Layer (type)                 Output Shape              Param #
=================================================================
embedding_1 (Embedding)      (None, 4, 8)              400
_________________________________________________________________
flatten_1 (Flatten)          (None, 32)                0
_________________________________________________________________
dense_1 (Dense)              (None, 1)                 33
=================================================================
Total params: 433
Trainable params: 433
Non-trainable params: 0
_________________________________________________________________

#Finally, the accuracy of the trained model 
Accuracy: 100.000000


##Example of Using Pre-Trained GloVe Embedding
#GloVe: Global Vectors for Word Representation, https://nlp.stanford.edu/projects/glove/
#The smallest package of embeddings is 822Mb, called �glove.6B.zip�. 
#It was trained on a dataset of one billion tokens (words) with a vocabulary of 400 thousand words. 
#There are a few different embedding vector sizes, including 50, 100, 200 and 300 dimensions.

#Let's use  �glove.6B.100d.txt�, which contains a 100-dimensional version of the embedding.
#consisting of a token (word) followed by the weights (100 numbers) on each line
the -0.038194 -0.24487 0.72812 -0.39961 0.083172 0.043953 -0.39141 0.3344 -0.57545 0.087459 0.28787 -0.06731 0.30906 -0.26384 -0.13231 -0.20757 0.33395 -0.33848 -0.31743 -0.48336 0.1464 -0.37304 0.34577 0.052041 0.44946 -0.46971 0.02628 -0.54155 -0.15518 -0.14107 -0.039722 0.28277 0.14393 0.23464 -0.31021 0.086173 0.20397 0.52624 0.17164 -0.082378 -0.71787 -0.41531 0.20335 -0.12763 0.41367 0.55187 0.57908 -0.33477 -0.36559 -0.54857 -0.062892 0.26584 0.30205 0.99775 -0.80481 -3.0243 0.01254 -0.36942 2.2167 0.72201 -0.24978 0.92136 0.034514 0.46745 1.1079 -0.19358 -0.074575 0.23353 -0.052062 -0.22044 0.057162 -0.15806 -0.30798 -0.41625 0.37972 0.15006 -0.53212 -0.2055 -1.2526 0.071624 0.70565 0.49744 -0.42063 0.26148 -1.538 -0.30223 -0.073438 -0.28312 0.37104 -0.25217 0.016215 -0.017099 -0.38984 0.87424 -0.72569 -0.51058 -0.52028 -0.1459 0.8278 0.27062

 
#using Tokenizer class that can be fit on the training data, 
#can convert text to sequences consistently by calling the texts_to_sequences() method 
#provides access to the dictionary mapping of words to integers in a word_index attribute.
keras.preprocessing.text.Tokenizer(num_words=None,
           filters='!"#$%&()*+,-./:;<=>@[\\]^_`{|}~\t\n',
           lower=True,
           split=" ",
           char_level=False)
    Methods:
        fit_on_texts(texts):
        texts_to_sequences(texts)
        texts_to_sequences_generator(texts): generator version of the above.
        texts_to_matrix(texts):
        fit_on_sequences(sequences):
        sequences_to_matrix(sequences):
    Attributes:
        word_counts
            dictionary mapping words (str) to the number of times they appeared on during fit. 
            Only set after fit_on_texts was called.
        word_docs
            dictionary mapping words (str) to the number of documents/texts they appeared on during fit. 
            Only set after fit_on_texts was called.
        word_index
            dictionary mapping words (str) to their rank/index (int). 
            Only set after fit_on_texts was called.
        document_count
            int. Number of documents (texts/sequences) the tokenizer was trained on. 
            Only set after fit_on_texts or fit_on_sequences was called.



#Example 

from numpy import array
from numpy import asarray
from numpy import zeros
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Flatten
from keras.layers import Embedding

# define documents
docs = ['Well done!',
		'Good work',
		'Great effort',
		'nice work',
		'Excellent!',
		'Weak',
		'Poor effort!',
		'not good',
		'poor work',
		'Could have done better.']
# define class labels
labels = array([1,1,1,1,1,0,0,0,0,0])
# prepare tokenizer
t = Tokenizer()
t.fit_on_texts(docs)
vocab_size = len(t.word_index) + 1
# integer encode the documents
encoded_docs = t.texts_to_sequences(docs)
print(encoded_docs)
# pad documents to a max length of 4 words
max_length = 4
padded_docs = pad_sequences(encoded_docs, maxlen=max_length, padding='post')
print(padded_docs)



#Create embedding based on GloVe - slow 
# load the whole embedding into memory
embeddings_index = dict()
f = open('glove.6B.100d.txt')
for line in f:
	values = line.split()
	word = values[0]
	coefs = asarray(values[1:], dtype='float32')
	embeddings_index[word] = coefs
f.close()
print('Loaded %s word vectors.' % len(embeddings_index))

 
#create a matrix of one embedding for each word in the training dataset. 
#We can do that by enumerating all unique words in the Tokenizer.word_index and locating the embedding weight vector from the loaded GloVe embedding.
#The result is a matrix of weights only for words we will see during training.
 
# create a weight matrix for words in training docs
embedding_matrix = zeros((vocab_size, 100))
for word, i in t.word_index.items():
	embedding_vector = embeddings_index.get(word)
	if embedding_vector is not None:
		embedding_matrix[i] = embedding_vector



model = Sequential()
e = Embedding(vocab_size, 100, weights=[embedding_matrix], input_length=4, trainable=False)
model.add(e)
model.add(Flatten())
model.add(Dense(1, activation='sigmoid'))
# compile the model
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['acc'])
# summarize the model
print(model.summary())
# fit the model
model.fit(padded_docs, labels, epochs=50, verbose=0)
# evaluate the model
loss, accuracy = model.evaluate(padded_docs, labels, verbose=0)
print('Accuracy: %f' % (accuracy*100))

#Running the example 
[[6, 2], [3, 1], [7, 4], [8, 1], [9], [10], [5, 4], [11, 3], [5, 1], [12, 13, 2, 14]]
[[ 6  2  0  0]
 [ 3  1  0  0]
 [ 7  4  0  0]
 [ 8  1  0  0]
 [ 9  0  0  0]
 [10  0  0  0]
 [ 5  4  0  0]
 [11  3  0  0]
 [ 5  1  0  0]
 [12 13  2 14]]
Loaded 400000 word vectors.
_________________________________________________________________
Layer (type)                 Output Shape              Param #
=================================================================
embedding_1 (Embedding)      (None, 4, 100)            1500
_________________________________________________________________
flatten_1 (Flatten)          (None, 400)               0
_________________________________________________________________
dense_1 (Dense)              (None, 1)                 401
=================================================================
Total params: 1,901
Trainable params: 401
Non-trainable params: 1,500
_________________________________________________________________

Accuracy: 100.000000     




###+++ Keras - Functional API - All Keras model and layers are callable 
#Used for defining complex models, 
#such as multi-output models, directed acyclic graphs, or models with shared layers.
1.A layer instance is callable (on a tensor), and it returns a tensor
2.Input tensor(s) and output tensor(s) can then be used to define a Model
3.Such a model can be trained just like Keras Sequential models.



##Keras - Functional - a densely-connected network
#The Sequential model is a better choice to implement such a network, 

#Sequential model for comparison 
from keras.models import Sequential
from keras.layers import Dense, Activation

model = Sequential([
    Dense(64, input_shape=(784,)), #input=784, output=64 
    Activation('relu'),
    Dense(64, input_shape=(784,)),
    Activation('relu'),
    Dense(10),
    Activation('softmax'),
])
#OR 
model = Sequential()
model.add(Dense(64, input_dim=784))
model.add(Activation('relu'))
model.add(Dense(64, input_dim=784))
model.add(Activation('relu'))
model.add(Dense(10))
model.add(Activation('softmax'))

#OR Functional model 
from keras.layers import Input, Dense
from keras.models import Model

# This returns a tensor
inputs = Input(shape=(784,))

# a layer instance is callable on a tensor, and returns a tensor
x = Dense(64, activation='relu')(inputs)
x = Dense(64, activation='relu')(x)
predictions = Dense(10, activation='softmax')(x)

model = Model(inputs=inputs, outputs=predictions)
model.compile(optimizer='rmsprop',
              loss='categorical_crossentropy',
              metrics=['accuracy'])
model.fit(data, labels)  # starts training


##Keras - functional - Converting to video classification model
#Note that by calling a model you aren't just reusing the architecture of the model, 
#you are also reusing its weights.

x = Input(shape=(784,))
# This works, and returns the 10-way softmax we defined above.
y = model(x)

#Usecase: Conversion of model for other usage 
#For example - turn above model(an image classification model) into a video classification model, 
#by changing Input shape 

from keras.layers import TimeDistributed

# Input tensor for sequences of 20 timesteps,
# each containing a 784-dimensional vector
input_sequences = Input(shape=(20, 784))

# This applies our previous model to every timestep in the input sequences.
# the output of the previous model was a 10-way softmax,
# so the output of the layer below will be a sequence of 20 vectors of size 10.
processed_sequences = TimeDistributed(model)(input_sequences)




##Keras - Functional -  Multi-input and multi-output models
#Example - to predict how many retweets and likes a news headline will receive on Twitter. 
#The main input to the model will be the headline itself, as a sequence of words, 
#will also have an auxiliary input, receiving extra data such as the time of day when the headline was posted, etc. 

#The model will also be supervised via two loss functions. 
#Using the main loss function earlier in a model is a good regularization mechanism for deep models.


                    main input(InputLayer)
                            |
                            v
                    embedding_1(Embedding)  #convert a sparse data with each value integer(index) of max value  to Dense as required in NN 
                            |
                            v
aux_input(InputLayer)   lstm_1(LSTM)
              \             /                   \
               v           v                     v
                merge_(concatenate/Merge)      aux_output(Dense)
                     |
                     v
                 dense_1(Dense)
                     |
                     v
                 dense_2(Dense)
                     |
                     v
                 dense_3(Dense)
                     |
                     v
                 main_output(Dense)


#The main input will receive the headline, as a sequence of integers 
#(each integer encodes a word). 
#The integers will be between 1 and 10,000 (a vocabulary of 10,000 words) 
#and the sequences will be 100 words long.

from keras.layers import Input, Embedding, LSTM, Dense
from keras.models import Model

# Headline input: meant to receive sequences of 100 integers, between 1 and 10000.
# Note that we can name any layer by passing it a "name" argument.
main_input = Input(shape=(100,), dtype='int32', name='main_input')

# This embedding layer will encode the input sequence of integers till 10000 with input length=100 
# into a sequence of dense 512-dimensional vectors.
x = Embedding(output_dim=512, input_dim=10000, input_length=100)(main_input)

# A LSTM(Long short-term memory ) will transform the vector sequence into a single vector,
# containing information about the entire sequence
lstm_out = LSTM(32)(x)

#insert the auxiliary loss and get aux output 
auxiliary_output = Dense(1, activation='sigmoid', name='aux_output')(lstm_out)

#feed into the model our auxiliary input data by concatenating it with the LSTM output

auxiliary_input = Input(shape=(5,), name='aux_input')
x = keras.layers.concatenate([lstm_out, auxiliary_input])

# We stack a deep densely-connected network on top
x = Dense(64, activation='relu')(x)
x = Dense(64, activation='relu')(x)
x = Dense(64, activation='relu')(x)

# And finally we add the main logistic regression layer
main_output = Dense(1, activation='sigmoid', name='main_output')(x)

#This defines a model with two inputs and two outputs:
model = Model(inputs=[main_input, auxiliary_input], outputs=[main_output, auxiliary_output])

model.compile(optimizer='rmsprop', loss='binary_crossentropy',
              loss_weights=[1., 0.2])

#train the model by passing it lists of input arrays and target arrays:
model.fit([headline_data, additional_data], [labels, labels],
          epochs=50, batch_size=32)

#Since our inputs and outputs are named 
#We could also have compiled the model via:
model.compile(optimizer='rmsprop',
              loss={'main_output': 'binary_crossentropy', 'aux_output': 'binary_crossentropy'},
              loss_weights={'main_output': 1., 'aux_output': 0.2})

# And trained it via:
model.fit({'main_input': headline_data, 'aux_input': additional_data},
          {'main_output': labels, 'aux_output': labels},
          epochs=50, batch_size=32)

          
      



###+++ Keras - Layer 

##General methods 
#All Layer derived class take **kwargs to configure the layer 
#use default values as many would be autocalculated 

#All Keras layers have a number of methods in common:
layer.get_weights()
    returns the weights of the layer as a list of Numpy arrays.
layer.set_weights(weights)
    sets the weights of the layer from a list of Numpy arrays (with the same shapes as the output of get_weights).
layer.get_config()
    returns a dictionary containing the configuration of the layer. 
    The layer can be reinstantiated from its config via:
    #Example 
    layer = Dense(32)
    config = layer.get_config()
    reconstructed_layer = Dense.from_config(config)
    #Or:
    from keras import layers
    config = layer.get_config()
    layer = layers.deserialize({'class_name': layer.__class__.__name__,'config': config})


#If a layer has a single node(ie not shared or having one input, one output) 
#you can get its input tensor, output tensor, input shape and output shape via:
layer.input
layer.output
layer.input_shape
layer.output_shape

#If the layer has multiple nodes 
layer.get_input_at(node_index)
layer.get_output_at(node_index)
layer.get_input_shape_at(node_index)
layer.get_output_shape_at(node_index)

##Reference 
# These properties should be set by the user via keyword arguments.
# note that 'dtype', 'input_shape' and 'batch_input_shape'
# are only applicable to input layers: do not pass these keywords
# to non-input layers.
allowed_kwargs = {'input_shape',
                  'batch_input_shape',
                  'batch_size',
                  'dtype',
                  'name',
                  'trainable',
                  'weights',
                  'input_dtype',  # legacy
                  }
# Properties
    name: String, must be unique within a model.
    input_spec: List of InputSpec class instances
        each entry describes one required input:
            - ndim
            - dtype
        A layer with `n` input tensors must have
        an `input_spec` of length `n`.
    trainable: Boolean, whether the layer weights
        will be updated during training.
    uses_learning_phase: Whether any operation
        of the layer uses `K.in_training_phase()`
        or `K.in_test_phase()`.
    input_shape: Shape tuple. Provided for convenience,
        but note that there may be cases in which this
        attribute is ill-defined (e.g. a shared layer
        with multiple input shapes), in which case
        requesting `input_shape` will raise an Exception.
        Prefer using `layer.get_input_shape_for(input_shape)`,
        or `layer.get_input_shape_at(node_index)`.
    output_shape: Shape tuple. See above.
    inbound_nodes: List of nodes.
    outbound_nodes: List of nodes.
    input, output: Input/output tensor(s). Note that if the layer is used
        more than once (shared layer), this is ill-defined
        and will raise an exception. In such cases, use
        `layer.get_input_at(node_index)`.
    input_mask, output_mask: Same as above, for masks.
    trainable_weights: List of variables.
    non_trainable_weights: List of variables.
    weights: The concatenation of the lists trainable_weights and
        non_trainable_weights (in this order).

# Methods
    call(x, mask=None): Where the layer's logic lives.
    __call__(x, mask=None): Wrapper around the layer logic (`call`).
        If x is a Keras tensor:
            - Connect current layer with last layer from tensor:
                `self._add_inbound_node(last_layer)`
            - Add layer to tensor history
        If layer is not built:
            - Build from x._keras_shape
    get_weights()
    set_weights(weights)
    get_config()
    count_params()
    compute_output_shape(input_shape)
    compute_mask(x, mask)
    get_input_at(node_index)
    get_output_at(node_index)
    get_input_shape_at(node_index)
    get_output_shape_at(node_index)
    get_input_mask_at(node_index)
    get_output_mask_at(node_index)

# Class Methods
    from_config(config)


    
    
##Keras - Embedding Layers - Only first layer can be used for Embedding 
keras.layers.Embedding(input_dim, output_dim, embeddings_initializer='uniform', embeddings_regularizer=None, activity_regularizer=None, embeddings_constraint=None, mask_zero=False, input_length=None)
    Turns positive integers (indexes) into dense vectors of fixed size. 
    eg. [[4], [20]] -> [[0.25, 0.1], [0.6, -0.2]]
    This layer can only be used as the first layer in a model.
    #Example
    model = Sequential()
    model.add(Embedding(1000, 64, input_length=10))
    # the model will take as input an integer matrix of size (batch, input_length).
    # the largest integer (i.e. word index) in the input should be no larger than 999 (vocabulary size).
    # now model.output_shape == (None, 10, 64), where None is the batch dimension.
    input_array = np.random.randint(1000, size=(32, 10))
    model.compile('rmsprop', 'mse')
    output_array = model.predict(input_array)
    assert output_array.shape == (32, 10, 64)
    Arguments
        input_dim: int > 0. Size of the vocabulary, i.e. maximum integer index + 1.
        output_dim: int >= 0. Dimension of the dense embedding.
        embeddings_initializer: Initializer for the embeddings matrix (see initializers).
        embeddings_regularizer: Regularizer function applied to the embeddings matrix (see regularizer).
        embeddings_constraint: Constraint function applied to the embeddings matrix (see constraints).
        mask_zero: Whether or not the input value 0 is a special "padding" value that should be masked out. This is useful when using recurrent layers which may take variable length input. If this is True then all subsequent layers in the model need to support masking or an exception will be raised. If mask_zero is set to True, as a consequence, index 0 cannot be used in the vocabulary (input_dim should equal size of vocabulary + 1).
        input_length: Length of input sequences, when it is constant. This argument is required if you are going to connect Flatten then Dense layers upstream (without it, the shape of the dense outputs cannot be computed).
    Input shape
        2D tensor with shape: (batch_size, sequence_length).
    Output shape
        3D tensor with shape: (batch_size, sequence_length, output_dim).

        
        
##Keras - Layer wrappers - Converting Layer to handle Time slices and Bidirectional Wrapper 

keras.layers.TimeDistributed(layer)
    This wrapper applies a layer to every temporal slice of an input.
    The input should be at least 3D, 
    and the dimension of index one will be considered to be the temporal dimension.
    Consider a batch of 32 samples,
    where each sample is a sequence of 10 vectors of 16 dimensions. 
    The batch input shape of the layer is then (32, 10, 16), 
    and the input_shape, not including the samples dimension, is (10, 16).

    You can then use TimeDistributed to apply a Dense layer 
    to each of the 10 timesteps, independently:
    # as the first layer in a model
    model = Sequential()
    model.add(TimeDistributed(Dense(8), input_shape=(10, 16)))
    # now model.output_shape == (None, 10, 8)
    #The output will then have shape (32, 10, 8).
    #In subsequent layers, there is no need for the input_shape:
    model.add(TimeDistributed(Dense(32)))
    # now model.output_shape == (None, 10, 32)
    #The output will then have shape (32, 10, 32).

    #TimeDistributed can be used with arbitrary layers, 
    #not just Dense, for instance with a Conv2D layer:

    model = Sequential()
    model.add(TimeDistributed(Conv2D(64, (3, 3)),
                              input_shape=(10, 299, 299, 3)))



keras.layers.Bidirectional(layer, merge_mode='concat', weights=None)
    Bidirectional wrapper for RNNs.
    Arguments
        layer: Recurrent instance.
        merge_mode: Mode by which outputs of the forward and backward RNNs will be combined. One of {'sum', 'mul', 'concat', 'ave', None}. If None, the outputs will not be combined, they will be returned as a list.
    #Examples
    model = Sequential()
    model.add(Bidirectional(LSTM(10, return_sequences=True),
                            input_shape=(5, 10)))
    model.add(Bidirectional(LSTM(10)))
    model.add(Dense(5))
    model.add(Activation('softmax'))
    model.compile(loss='categorical_crossentropy', optimizer='rmsprop')

    
    
    
 

##Keras - Core Layers 

keras.layers.Dense(units, activation=None, use_bias=True, 
        kernel_initializer='glorot_uniform', bias_initializer='zeros', 
        kernel_regularizer=None, bias_regularizer=None, 
        activity_regularizer=None, kernel_constraint=None, bias_constraint=None)
    Densely-connected NN layer.
    Dense implements the operation
        output = activation(dot(input, kernel) + bias) 
    where activation is the element-wise activation function passed 
    as the activation argument, 
    kernel is a weights matrix created by the layer, 
    and bias is a bias vector created by the layer 
    (only applicable if use_bias is True).
    Note: if the input to the layer has a rank greater than 2, 
    then it is flattened prior to the initial dot product with kernel.    
    Arguments
        units: Positive integer, dimensionality of the output space.
        activation: Activation function to use . If you don't specify anything, no activation is applied (ie. "linear" activation: a(x) = x).
        use_bias: Boolean, whether the layer uses a bias vector.
        kernel_initializer: Initializer for the kernel weights matrix (see initializers).
        bias_initializer: Initializer for the bias vector (see initializers).
        kernel_regularizer: Regularizer function applied to the kernel weights matrix (see regularizer).
        bias_regularizer: Regularizer function applied to the bias vector (see regularizer).
        activity_regularizer: Regularizer function applied to the output of the layer (its "activation"). (see regularizer).
        kernel_constraint: Constraint function applied to the kernel weights matrix (see constraints).
        bias_constraint: Constraint function applied to the bias vector (see constraints).
    Input shape
        nD tensor with shape: (batch_size, ..., input_dim). 
        The most common situation would be a 2D input 
        with shape (batch_size, input_dim).
    Output shape
        nD tensor with shape: (batch_size, ..., units). 
        For instance, for a 2D input with shape (batch_size, input_dim), 
        the output would have shape (batch_size, units).
    #Example
    # as first layer in a sequential model:
    model = Sequential()
    model.add(Dense(32, input_shape=(16,)))
    # now the model will take as input arrays of shape (*, 16)
    # and output arrays of shape (*, 32)
    # after the first layer, you don't need to specify
    # the size of the input anymore:
    model.add(Dense(32))


keras.layers.Activation(activation)
    Applies an activation function to an output.
    Arguments
        activation: name of activation function to use 
        or alternatively, a Theano or TensorFlow operation.
    Available activations
        softmax(x, axis=-1)
            Softmax activation function.
        elu(x, alpha=1.0)
        selu(x)
            Scaled Exponential Linear Unit. (Klambauer et al., 2017)
        softplus(x)
        softsign(x)
        relu(x, alpha=0.0, max_value=None)
        tanh(x)
        sigmoid(x)
        hard_sigmoid(x)
        linear(x)
keras.layers.LeakyReLU(alpha=0.3)
    Leaky version of a Rectified Linear Unit.
keras.layers.PReLU(alpha_initializer='zeros', alpha_regularizer=None, alpha_constraint=None, shared_axes=None)
    Parametric Rectified Linear Unit.
keras.layers.ELU(alpha=1.0)
    Exponential Linear Unit.
keras.layers.ThresholdedReLU(theta=1.0)
    Thresholded Rectified Linear Unit.
    
keras.layers.Dropout(rate, noise_shape=None, seed=None)
    Applies Dropout to the input.
    Dropout consists in randomly setting a fraction rate of input units 
    to 0 at each update during training time, which helps prevent overfitting.
    Arguments
        rate: float between 0 and 1. Fraction of the input units to drop.
        noise_shape: 1D integer tensor representing the shape of the binary dropout mask that will be multiplied with the input. For instance, if your inputs have shape (batch_size, timesteps, features) and you want the dropout mask to be the same for all timesteps, you can use noise_shape=(batch_size, 1, features).
        seed: A Python integer to use as random seed.
        
keras.layers.Flatten()
    Flattens the input. Does not affect the batch size.
    #Example
    model = Sequential()
    model.add(Conv2D(64, 3, 3,
                     border_mode='same',
                     input_shape=(3, 32, 32)))
    # now: model.output_shape == (None, 64, 32, 32)
    model.add(Flatten())
    # now: model.output_shape == (None, 65536)
    
keras.layers.Reshape(target_shape)
    Reshapes an output to a certain shape.
    Arguments
        target_shape: target shape. Tuple of integers. 
        Does not include the batch axis.
    Input shape
        Arbitrary, although all dimensions in the input shaped must be fixed. 
        Use the keyword argument input_shape(tuple of integers, does not include the batch axis) 
        when using this layer as the first layer in a model.
    Output shape
        (batch_size,) + target_shape
    #Example
    # as first layer in a Sequential model
    model = Sequential()
    model.add(Reshape((3, 4), input_shape=(12,)))
    # now: model.output_shape == (None, 3, 4)
    # note: `None` is the batch dimension
    # as intermediate layer in a Sequential model
    model.add(Reshape((6, 2)))
    # now: model.output_shape == (None, 6, 2)
    # also supports shape inference using `-1` as dimension
    model.add(Reshape((-1, 2, 2)))
    # now: model.output_shape == (None, 3, 2, 2)
    
keras.layers.Permute(dims)
    Permutes the dimensions of the input according to a given pattern.
    Useful for e.g. connecting RNNs and convnets together.
    Arguments
    dims: Tuple of integers. 
        Permutation pattern, does not include the samples dimension. 
        Indexing starts at 1. 
        For instance, (2, 1) permutes the first and second dimension of the input.
    #Example
    model = Sequential()
    model.add(Permute((2, 1), input_shape=(10, 64)))
    # now: model.output_shape == (None, 64, 10)
    # note: `None` is the batch dimension
    
keras.layers.RepeatVector(n)
    Repeats the input n times.
    Arguments
        n: integer, repetition factor.
    Input shape
        2D tensor of shape (num_samples, features).
    Output shape
        3D tensor of shape (num_samples, n, features).
    #Example
    model = Sequential()
    model.add(Dense(32, input_dim=32))
    # now: model.output_shape == (None, 32)
    # note: `None` is the batch dimension
    model.add(RepeatVector(3))
    # now: model.output_shape == (None, 3, 32)
       

keras.layers.Lambda(function, output_shape=None, mask=None, arguments=None)
    Wraps arbitrary expression as a Layer object.
   Arguments
    function: The function to be evaluated. Takes input tensor as first argument.
    output_shape: Expected output shape from function. Only relevant when using Theano. Can be a tuple or function. If a tuple, it only specifies the first dimension onward; sample dimension is assumed either the same as the input: output_shape = (input_shape[0], ) + output_shape or, the input is None and the sample dimension is also None: output_shape = (None, ) + output_shape If a function, it specifies the entire shape as a function of the input shape: output_shape = f(input_shape)
    arguments: optional dictionary of keyword arguments to be passed to the function.
    #Examples
    # add a x -> x^2 layer
    model.add(Lambda(lambda x: x ** 2))
    # add a layer that returns the concatenation
    # of the positive part of the input and
    # the opposite of the negative part
    def antirectifier(x):
        x -= K.mean(x, axis=1, keepdims=True)
        x = K.l2_normalize(x, axis=1)
        pos = K.relu(x)
        neg = K.relu(-x)
        return K.concatenate([pos, neg], axis=1)
    def antirectifier_output_shape(input_shape):
        shape = list(input_shape)
        assert len(shape) == 2  # only valid for 2D tensors
        shape[-1] *= 2
        return tuple(shape)
    model.add(Lambda(antirectifier, output_shape=antirectifier_output_shape))
    
keras.layers.ActivityRegularization(l1=0.0, l2=0.0)
    Layer that applies an update to the cost function based input activity.
    Arguments
        l1: L1 regularization factor (positive float).
        l2: L2 regularization factor (positive float).
        
keras.layers.Masking(mask_value=0.0)
    Masks a sequence by using a mask value to skip timesteps.
    For each timestep in the input tensor (dimension 1 in the tensor), 
    if all values in the input tensor at that timestep are equal to mask_value, 
    then the timestep will be skipped in all downstream layers(as long as they support masking).
    If any downstream layer does not support masking 
    yet receives such an input mask, an exception will be raised.
    #Example - Consider a Numpy data array x of shape (samples, timesteps, features), to be fed to an LSTM layer. 
    #You want to mask timestep 3 and 5 because you lack data for these timesteps. 
    x[:, 3, :] = 0
    x[:, 5, :] = 0.
    #insert a Masking layer with mask_value=0. before the LSTM layer:
    model = Sequential()
    model.add(Masking(mask_value=0., input_shape=(timesteps, features)))
    model.add(LSTM(32))


        
        
##Keras - Merge Layers - for Functional 


##Difference between CapitalCaseClass and  smallCaseMethod 
#CapitalCaseClass and  smallCaseMethod take **kwargs: Standard layer keyword arguments.
#smallCaseMethod(inputs, **kwargs) returns CapitalCaseClass(**kwargs)(inputs)
#all elementwise operation of  inputs 


keras.layers.Add()
    Layer that adds a list of inputs.
    It takes as input a list of tensors, all of the same shape, 
    and returns a single tensor (also of the same shape).
    #Examples
    import keras
    input1 = keras.layers.Input(shape=(16,))
    x1 = keras.layers.Dense(8, activation='relu')(input1)
    input2 = keras.layers.Input(shape=(32,))
    x2 = keras.layers.Dense(8, activation='relu')(input2)
    added = keras.layers.Add()([x1, x2])  # equivalent to added = keras.layers.add([x1, x2])
    out = keras.layers.Dense(4)(added)
    model = keras.models.Model(inputs=[input1, input2], outputs=out)
    
keras.layers.add(inputs)
    Functional interface to the Add layer.
    Arguments
        inputs: A list of input tensors (at least 2).
    Returns
        A tensor, the sum of the inputs.
    #Examples
    import keras
    input1 = keras.layers.Input(shape=(16,))
    x1 = keras.layers.Dense(8, activation='relu')(input1)
    input2 = keras.layers.Input(shape=(32,))
    x2 = keras.layers.Dense(8, activation='relu')(input2)
    added = keras.layers.add([x1, x2])
    out = keras.layers.Dense(4)(added)
    model = keras.models.Model(inputs=[input1, input2], outputs=out)
    
keras.layers.Subtract()
    Layer that subtracts two inputs.
    It takes as input a list of tensors of size 2, 
    both of the same shape, and returns a single tensor, 
    (inputs[0] - inputs[1]), also of the same shape.
keras.layers.Multiply()
    Layer that multiplies (element-wise) a list of inputs.
    It takes as input a list of tensors, all of the same shape, 
    and returns a single tensor (also of the same shape).
keras.layers.Average()
    Layer that averages a list of inputs.
    It takes as input a list of tensors, all of the same shape, 
    and returns a single tensor (also of the same shape).
keras.layers.Maximum()
    Layer that computes the maximum (element-wise) a list of inputs.
    It takes as input a list of tensors, all of the same shape, 
    and returns a single tensor (also of the same shape).
keras.layers.Concatenate(axis=-1)
    Layer that concatenates a list of inputs.
    It takes as input a list of tensors, all of the same shape 
    except for the concatenation axis, and returns a single tensor, 
    the concatenation of all inputs.
    Arguments
        axis: Axis along which to concatenate.
keras.layers.Dot(axes, normalize=False)
    Layer that computes a dot product between samples in two tensors.
    E.g. if applied to two tensors a and b of shape (batch_size, n), 
    the output will be a tensor of shape (batch_size, 1) 
    where each entry i will be the dot product between a[i] and b[i].
    Arguments
        axes: Integer or tuple of integers, axis or axes along which to take the dot product.
        normalize: Whether to L2-normalize samples along the dot product axis before taking the dot product. If set to True, then the output of the dot product is the cosine proximity between the two samples.

keras.layers.subtract(inputs)
    Functional interface to the Subtract layer.
keras.layers.multiply(inputs)
    Functional interface to the Multiply layer.
keras.layers.average(inputs)
    Functional interface to the Average layer.
keras.layers.maximum(inputs)
    Functional interface to the Maximum layer.
keras.layers.concatenate(inputs, axis=-1)
    Functional interface to the Concatenate layer.
keras.layers.dot(inputs, axes, normalize=False)
    Functional interface to the Dot layer.
 


##Keras - Convolutional Layers
#Note Input Shape and Output Shape are autocalculated for all layers except first layer 
#For firstlayer, provide 'input_shape' argument (from base class Layer)
#'filters' is generally output dimension 

keras.layers.Conv1D(filters, kernel_size, strides=1, padding='valid', 
            dilation_rate=1, activation=None, use_bias=True, 
            kernel_initializer='glorot_uniform', bias_initializer='zeros', 
            kernel_regularizer=None, bias_regularizer=None, 
            activity_regularizer=None, kernel_constraint=None, 
            bias_constraint=None)
    When using this layer as the first layer in a model, 
    provide an 'input_shape' argument (tuple of integers or None) 
    e.g. (10, 128) for sequences of 10 vectors of 128-dimensional vectors, 
    or (None, 128) for variable-length sequences of 128-dimensional vectors.
    Arguments
        filters: Integer, the dimensionality of the output space (i.e. the number output of filters in the convolution).
        kernel_size: An integer or tuple/list of a single integer, specifying the length of the 1D convolution window.
        strides: An integer or tuple/list of a single integer, specifying the stride length of the convolution. Specifying any stride value != 1 is incompatible with specifying any dilation_rate value != 1.
        padding: One of "valid", "causal" or "same" (case-insensitive). "valid" means "no padding". "same" results in padding the input such that the output has the same length as the original input. "causal" results in causal (dilated) convolutions, e.g. output[t] does not depend on input[t+1:]. Useful when modeling temporal data where the model should not violate the temporal order. See WaveNet: A Generative Model for Raw Audio, section 2.1.
        dilation_rate: an integer or tuple/list of a single integer, specifying the dilation rate to use for dilated convolution. Currently, specifying any dilation_rate value != 1 is incompatible with specifying any strides value != 1.
        activation: Activation function to use (see activations). If you don't specify anything, no activation is applied (ie. "linear" activation: a(x) = x).
        use_bias: Boolean, whether the layer uses a bias vector.
        kernel_initializer: Initializer for the kernel weights matrix (see initializers).
        bias_initializer: Initializer for the bias vector (see initializers).
        kernel_regularizer: Regularizer function applied to the kernel weights matrix (see regularizer).
        bias_regularizer: Regularizer function applied to the bias vector (see regularizer).
        activity_regularizer: Regularizer function applied to the output of the layer (its "activation"). (see regularizer).
        kernel_constraint: Constraint function applied to the kernel matrix (see constraints).
        bias_constraint: Constraint function applied to the bias vector (see constraints).
    Input shape
        3D tensor with shape: (batch_size, steps, input_dim)
    Output shape
        3D tensor with shape: (batch_size, new_steps, filters) 
        steps value might have changed due to padding or strides.


keras.layers.Conv2D(filters, kernel_size, strides=(1, 1), 
            padding='valid', data_format=None, dilation_rate=(1, 1), 
            activation=None, use_bias=True, kernel_initializer='glorot_uniform', bias_initializer='zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)
    2D convolution layer (e.g. spatial convolution over images).
    When using this layer as the first layer in a model, 
    provide the keyword argument input_shape 
    (tuple of integers, does not include the sample axis), 
    e.g. input_shape=(128, 128, 3) for 128x128 RGB pictures in data_format="channels_last".
    Input shape
        4D tensor with shape: (samples, channels, rows, cols) 
        if data_format='channels_first' 
        or 4D tensor with shape: (samples, rows, cols, channels) if data_format='channels_last'.
    Output shape
        4D tensor with shape: (samples, filters, new_rows, new_cols) 
        if data_format='channels_first' 
        or 4D tensor with shape: (samples, new_rows, new_cols, filters) 
        if data_format='channels_last'. 
        rows and cols values might have changed due to padding.


keras.layers.SeparableConv2D(filters, kernel_size, strides=(1, 1), padding='valid', data_format=None, depth_multiplier=1, activation=None, use_bias=True, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)
    Depthwise separable 2D convolution.
    Separable convolutions consist in first performing a depthwise spatial convolution 
    (which acts on each input channel separately) followed by a pointwise convolution 
    which mixes together the resulting output channels. 
    The depth_multiplier argument controls how many output channels are generated per input channel 
    in the depthwise step.
    Intuitively, separable convolutions can be understood 
    as a way to factorize a convolution kernel into two smaller kernels, 
    or as an extreme version of an Inception block.
    Input shape
        4D tensor with shape: (batch, channels, rows, cols) if data_format='channels_first' or 4D tensor with shape: (batch, rows, cols, channels) if data_format='channels_last'.
    Output shape
        4D tensor with shape: (batch, filters, new_rows, new_cols) if data_format='channels_first' or 4D tensor with shape: (batch, new_rows, new_cols, filters) if data_format='channels_last'. rows and cols values might have changed due to padding.

keras.layers.Conv2DTranspose(filters, kernel_size, strides=(1, 1), padding='valid', data_format=None, activation=None, use_bias=True, kernel_initializer='glorot_uniform', bias_initializer='zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)
    Transposed convolution layer (sometimes called Deconvolution).
    When using this layer as the first layer in a model, 
    provide the keyword argument input_shape (
    tuple of integers, does not include the sample axis), 
    e.g. input_shape=(128, 128, 3) for 128x128 RGB pictures in data_format="channels_last".
    Input shape
        4D tensor with shape: (batch, channels, rows, cols) if data_format='channels_first' or 4D tensor with shape: (batch, rows, cols, channels) if data_format='channels_last'.
    Output shape
        4D tensor with shape: (batch, filters, new_rows, new_cols) if data_format='channels_first' or 4D tensor with shape: (batch, new_rows, new_cols, filters) if data_format='channels_last'. rows and cols values might have changed due to padding.

keras.layers.Conv3D(filters, kernel_size, strides=(1, 1, 1), 
            padding='valid', data_format=None, dilation_rate=(1, 1, 1), activation=None, use_bias=True, kernel_initializer='glorot_uniform', bias_initializer='zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)
    3D convolution layer (e.g. spatial convolution over volumes).
    When using this layer as the first layer in a model, 
    provide the keyword argument input_shape 
    (tuple of integers, does not include the sample axis), 
    e.g. input_shape=(128, 128, 128, 1) for 128x128x128 volumes with a single channel, 
    in data_format="channels_last".
    Input shape
        5D tensor with shape: (samples, channels, conv_dim1, conv_dim2, conv_dim3) if data_format='channels_first' or 5D tensor with shape: (samples, conv_dim1, conv_dim2, conv_dim3, channels) if data_format='channels_last'.
    Output shape
        5D tensor with shape: (samples, filters, new_conv_dim1, new_conv_dim2, new_conv_dim3) if data_format='channels_first' or 5D tensor with shape: (samples, new_conv_dim1, new_conv_dim2, new_conv_dim3, filters) if data_format='channels_last'. new_conv_dim1, new_conv_dim2 and new_conv_dim3 values might have changed due to padding.

keras.layers.Cropping1D(cropping=(1, 1))
    Cropping layer for 1D input (e.g. temporal sequence).
    It crops along the time dimension (axis 1).
    Arguments
        cropping: int or tuple of int (length 2) 
        How many units should be trimmed off at the beginning and end of the cropping dimension (axis 1). If a single int is provided, the same value will be used for both.
    Input shape
        3D tensor with shape (batch, axis_to_crop, features)
    Output shape
        3D tensor with shape (batch, cropped_axis, features)

keras.layers.Cropping2D(cropping=((0, 0), (0, 0)), data_format=None)
    Cropping layer for 2D input (e.g. picture).
    It crops along spatial dimensions, i.e. width and height.
    Arguments
    cropping: int, or tuple of 2 ints, or tuple of 2 tuples of 2 ints.
        If int: the same symmetric cropping is applied to width and height.
        If tuple of 2 ints: interpreted as two different symmetric cropping values for height and width: (symmetric_height_crop, symmetric_width_crop).
        If tuple of 2 tuples of 2 ints: interpreted as ((top_crop, bottom_crop), (left_crop, right_crop))
        data_format: A string, one of channels_last (default) or channels_first. The ordering of the dimensions in the inputs. channels_last corresponds to inputs with shape (batch, height, width, channels) while channels_first corresponds to inputs with shape (batch, channels, height, width). It defaults to the image_data_format value found in your Keras config file at ~/.keras/keras.json. If you never set it, then it will be "channels_last".
    Input shape
        4D tensor with shape: - If data_format is "channels_last": (batch, rows, cols, channels) - If data_format is "channels_first": (batch, channels, rows, cols)
    Output shape
        4D tensor with shape: - If data_format is "channels_last": (batch, cropped_rows, cropped_cols, channels) - If data_format is "channels_first": (batch, channels, cropped_rows, cropped_cols)
    Examples
    # Crop the input 2D images or feature maps
    model = Sequential()
    model.add(Cropping2D(cropping=((2, 2), (4, 4)),
                         input_shape=(28, 28, 3)))
    # now model.output_shape == (None, 24, 20, 3)
    model.add(Conv2D(64, (3, 3), padding='same'))
    model.add(Cropping2D(cropping=((2, 2), (2, 2))))
    # now model.output_shape == (None, 20, 16. 64)


keras.layers.Cropping3D(cropping=((1, 1), (1, 1), (1, 1)), data_format=None)
    Cropping layer for 3D data (e.g. spatial or spatio-temporal).
    Argument
    cropping: int, or tuple of 3 ints, or tuple of 3 tuples of 2 ints.
        If int: the same symmetric cropping is applied to depth, height, and width.
        If tuple of 3 ints: interpreted as two different symmetric cropping values for depth, height, and width: (symmetric_dim1_crop, symmetric_dim2_crop, symmetric_dim3_crop).
        If tuple of 3 tuples of 2 ints: interpreted as ((left_dim1_crop, right_dim1_crop), (left_dim2_crop, right_dim2_crop), (left_dim3_crop, right_dim3_crop))
    data_format: A string, one of channels_last (default) or channels_first. The ordering of the dimensions in the inputs. channels_last corresponds to inputs with shape (batch, spatial_dim1, spatial_dim2, spatial_dim3, channels) while channels_first corresponds to inputs with shape (batch, channels, spatial_dim1, spatial_dim2, spatial_dim3). It defaults to the image_data_format value found in your Keras config file at ~/.keras/keras.json. If you never set it, then it will be "channels_last".
    Input shape
        5D tensor with shape: - If data_format is "channels_last": (batch, first_axis_to_crop, second_axis_to_crop, third_axis_to_crop, depth) - If data_format is "channels_first": (batch, depth, first_axis_to_crop, second_axis_to_crop, third_axis_to_crop)
    Output shape
        5D tensor with shape: - If data_format is "channels_last": (batch, first_cropped_axis, second_cropped_axis, third_cropped_axis, depth) - If data_format is "channels_first": (batch, depth, first_cropped_axis, second_cropped_axis, third_cropped_axis)

keras.layers.UpSampling1D(size=2)
    Upsampling layer for 1D inputs.
    Repeats each temporal step size times along the time axis.
    Arguments
        size: integer. Upsampling factor.
    Input shape
        3D tensor with shape: (batch, steps, features).
    Output shape
        3D tensor with shape: (batch, upsampled_steps, features).

keras.layers.UpSampling2D(size=(2, 2), data_format=None)
    Upsampling layer for 2D inputs.
    Repeats the rows and columns of the data by size[0] and size[1] respectively.
    Arguments
    size: int, or tuple of 2 integers. The upsampling factors for rows and columns.
    data_format: A string, one of channels_last (default) or channels_first. The ordering of the dimensions in the inputs. channels_last corresponds to inputs with shape (batch, height, width, channels) while channels_first corresponds to inputs with shape (batch, channels, height, width). It defaults to the image_data_format value found in your Keras config file at ~/.keras/keras.json. If you never set it, then it will be "channels_last".
    Input shape
        4D tensor with shape: - If data_format is "channels_last": (batch, rows, cols, channels) - If data_format is "channels_first": (batch, channels, rows, cols)
    Output shape
        4D tensor with shape: - If data_format is "channels_last": (batch, upsampled_rows, upsampled_cols, channels) - If data_format is "channels_first": (batch, channels, upsampled_rows, upsampled_cols)

keras.layers.UpSampling3D(size=(2, 2, 2), data_format=None)
    Upsampling layer for 3D inputs.
    Repeats the 1st, 2nd and 3rd dimensions of the data 
    by size[0], size[1] and size[2] respectively.
    Arguments
    size: int, or tuple of 3 integers. The upsampling factors for dim1, dim2 and dim3.
    data_format: A string, one of channels_last (default) or channels_first. The ordering of the dimensions in the inputs. channels_last corresponds to inputs with shape (batch, spatial_dim1, spatial_dim2, spatial_dim3, channels) while channels_first corresponds to inputs with shape (batch, channels, spatial_dim1, spatial_dim2, spatial_dim3). It defaults to the image_data_format value found in your Keras config file at ~/.keras/keras.json. If you never set it, then it will be "channels_last".
    Input shape
        5D tensor with shape: - If data_format is "channels_last": (batch, dim1, dim2, dim3, channels) - If data_format is "channels_first": (batch, channels, dim1, dim2, dim3)
    Output shape
        5D tensor with shape: - If data_format is "channels_last": (batch, upsampled_dim1, upsampled_dim2, upsampled_dim3, channels) - If data_format is "channels_first": (batch, channels, upsampled_dim1, upsampled_dim2, upsampled_dim3)

keras.layers.ZeroPadding1D(padding=1)
    Zero-padding layer for 1D input (e.g. temporal sequence).
    Arguments
    padding: int, or tuple of int (length 2), or dictionary.
        If int: How many zeros to add at the beginning and end of the padding dimension (axis 1).
        If tuple of int (length 2): How many zeros to add at the beginning and at the end of the padding dimension ((left_pad, right_pad)).
    Input shape
        3D tensor with shape (batch, axis_to_pad, features)
    Output shape
        3D tensor with shape (batch, padded_axis, features)

keras.layers.ZeroPadding2D(padding=(1, 1), data_format=None)
    Zero-padding layer for 2D input (e.g. picture).
    This layer can add rows and columns of zeros 
    at the top, bottom, left and right side of an image tensor.
    Arguments
    padding: int, or tuple of 2 ints, or tuple of 2 tuples of 2 ints.
        If int: the same symmetric padding is applied to width and height.
        If tuple of 2 ints: interpreted as two different symmetric padding values for height and width: (symmetric_height_pad, symmetric_width_pad).
        If tuple of 2 tuples of 2 ints: interpreted as ((top_pad, bottom_pad), (left_pad, right_pad))
        data_format: A string, one of channels_last (default) or channels_first. The ordering of the dimensions in the inputs. channels_last corresponds to inputs with shape (batch, height, width, channels) while channels_first corresponds to inputs with shape (batch, channels, height, width). It defaults to the image_data_format value found in your Keras config file at ~/.keras/keras.json. If you never set it, then it will be "channels_last".
    Input shape
        4D tensor with shape: - If data_format is "channels_last": (batch, rows, cols, channels) - If data_format is "channels_first": (batch, channels, rows, cols)
    Output shape
        4D tensor with shape: - If data_format is "channels_last": (batch, padded_rows, padded_cols, channels) - If data_format is "channels_first": (batch, channels, padded_rows, padded_cols)

keras.layers.ZeroPadding3D(padding=(1, 1, 1), data_format=None)
    Zero-padding layer for 3D data (spatial or spatio-temporal).
    Arguments
    padding: int, or tuple of 2 ints, or tuple of 2 tuples of 2 ints.
        If int: the same symmetric padding is applied to width and height.
        If tuple of 2 ints: interpreted as two different symmetric padding values for height and width: (symmetric_dim1_pad, symmetric_dim2_pad, symmetric_dim3_pad).
        If tuple of 2 tuples of 2 ints: interpreted as ((left_dim1_pad, right_dim1_pad), (left_dim2_pad, right_dim2_pad), (left_dim3_pad, right_dim3_pad))
        data_format: A string, one of channels_last (default) or channels_first. The ordering of the dimensions in the inputs. channels_last corresponds to inputs with shape (batch, spatial_dim1, spatial_dim2, spatial_dim3, channels) while channels_first corresponds to inputs with shape (batch, channels, spatial_dim1, spatial_dim2, spatial_dim3). It defaults to the image_data_format value found in your Keras config file at ~/.keras/keras.json. If you never set it, then it will be "channels_last".
    Input shape
        5D tensor with shape: - If data_format is "channels_last": (batch, first_axis_to_pad, second_axis_to_pad, third_axis_to_pad, depth) - If data_format is "channels_first": (batch, depth, first_axis_to_pad, second_axis_to_pad, third_axis_to_pad)
    Output shape
        5D tensor with shape: - If data_format is "channels_last": (batch, first_padded_axis, second_padded_axis, third_axis_to_pad, depth) - If data_format is "channels_first": (batch, depth, first_padded_axis, second_padded_axis, third_axis_to_pad)

       
        
##Keras -Pooling Layers
#Pooling is to get a single value(downsample) by method eg max/avergae  from pool_size 
#Common argument 
data_format
    A string, one of channels_last (default) or channels_first. 
    The ordering of the dimensions in the inputs. 
    channels_last corresponds to inputs with shape (batch, height, width, channels) 
    while channels_first corresponds to inputs with shape (batch, channels, height, width). 
    It defaults to the image_data_format value found in Keras config file at ~/.keras/keras.json. 
    If you never set it, then it will be "channels_last".


keras.layers.GlobalMaxPooling1D()
    Global max pooling operation for temporal data.
keras.layers.AveragePooling1D(pool_size=2, strides=None, padding='valid')
    Average  pooling operation for temporal data
keras.layers.MaxPooling1D(pool_size=2, strides=None, padding='valid')
    Max pooling operation for temporal data.
    Arguments
        pool_size: Integer, size of the max pooling windows.
        strides: Integer, or None. Factor by which to downscale. 
            E.g. 2 will halve the input. If None, it will default to pool_size.
        padding: One of "valid" or "same" (case-insensitive).
    Input shape
        3D tensor with shape: (batch_size, steps, features).
    Output shape
        3D tensor with shape: (batch_size, downsampled_steps, features).
        
keras.layers.GlobalMaxPooling2D(data_format=None)
    Global max pooling operation for spatial data.
keras.layers.AveragePooling2D(pool_size=(2, 2), strides=None, padding='valid', data_format=None)
    Average pooling operation for spatial data.
keras.layers.MaxPooling2D(pool_size=(2, 2), strides=None, padding='valid', data_format=None)
    Max pooling operation for spatial data.
    Arguments
        pool_size: integer or tuple of 2 integers, factors by which to downscale (vertical, horizontal). 
            (2, 2) will halve the input in both spatial dimension. If only one integer is specified, the same window length will be used for both dimensions.
        strides: Integer, tuple of 2 integers, or None. Strides values. 
            If None, it will default to pool_size.
        padding: One of "valid" or "same" (case-insensitive).
        data_format: A string, one of channels_last (default) or channels_first. The ordering of the dimensions in the inputs. channels_last corresponds to inputs with shape (batch, height, width, channels) while channels_first corresponds to inputs with shape (batch, channels, height, width). It defaults to the image_data_format value found in your Keras config file at ~/.keras/keras.json. If you never set it, then it will be "channels_last".
    Input shape
        If data_format='channels_last': 4D tensor with shape: (batch_size, rows, cols, channels)
        If data_format='channels_first': 4D tensor with shape: (batch_size, channels, rows, cols)
    Output shape
        If data_format='channels_last': 4D tensor with shape: (batch_size, pooled_rows, pooled_cols, channels)
        If data_format='channels_first': 4D tensor with shape: (batch_size, channels, pooled_rows, pooled_cols)
   
keras.layers.GlobalAveragePooling2D(data_format=None)
    Global average pooling operation for spatial data.   
keras.layers.AveragePooling3D(pool_size=(2, 2, 2), strides=None, padding='valid', data_format=None)
    Average pooling operation for 3D data (spatial or spatio-temporal).
keras.layers.MaxPooling3D(pool_size=(2, 2, 2), strides=None, padding='valid', data_format=None)
    Max pooling operation for 3D data (spatial or spatio-temporal).
    Arguments
        pool_size: tuple of 3 integers, factors by which to downscale (dim1, dim2, dim3). 
                  (2, 2, 2) will halve the size of the 3D input in each dimension.
        strides: tuple of 3 integers, or None. Strides values.
        padding: One of "valid" or "same" (case-insensitive).
        data_format: A string, one of channels_last (default) or channels_first. The ordering of the dimensions in the inputs. channels_last corresponds to inputs with shape (batch, spatial_dim1, spatial_dim2, spatial_dim3, channels) while channels_first corresponds to inputs with shape (batch, channels, spatial_dim1, spatial_dim2, spatial_dim3). It defaults to the image_data_format value found in your Keras config file at ~/.keras/keras.json. If you never set it, then it will be "channels_last".
    Input shape
        If data_format='channels_last': 5D tensor with shape: (batch_size, spatial_dim1, spatial_dim2, spatial_dim3, channels)
        If data_format='channels_first': 5D tensor with shape: (batch_size, channels, spatial_dim1, spatial_dim2, spatial_dim3)
    Output shape
        If data_format='channels_last': 5D tensor with shape: (batch_size, pooled_dim1, pooled_dim2, pooled_dim3, channels)
        If data_format='channels_first': 5D tensor with shape: (batch_size, channels, pooled_dim1, pooled_dim2, pooled_dim3)





        
##Keras -Locally-connected Layers
#The LocallyConnectedND layer works similarly to the ConvND layer, 
#except that weights are unshared, 
#that is, a different set of filters is applied at each different patch of the input.

#Note Input Shape and Output Shape are autocalculated for all layers except first layer 
#For firstlayer, provide 'input_shape' argument (from base class Layer)
#'filters' is generally output dimension 

keras.layers.LocallyConnected1D(filters, kernel_size, strides=1, padding='valid', data_format=None, activation=None, use_bias=True, kernel_initializer='glorot_uniform', bias_initializer='zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)
    Locally-connected layer for 1D inputs.
    #Example
    # apply a unshared weight convolution 1d of length 3 to a sequence with
    # 10 timesteps, with 64 output filters
    model = Sequential()
    model.add(LocallyConnected1D(64, 3, input_shape=(10, 32)))
    # now model.output_shape == (None, 8, 64)
    # add a new conv1d on top
    model.add(LocallyConnected1D(32, 3))
    # now model.output_shape == (None, 6, 32)

keras.layers.LocallyConnected2D(filters, kernel_size, strides=(1, 1), padding='valid', data_format=None, activation=None, use_bias=True, kernel_initializer='glorot_uniform', bias_initializer='zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)
    Locally-connected layer for 2D inputs.
    #Examples
    # apply a 3x3 unshared weights convolution with 64 output filters on a 32x32 image
    # with `data_format="channels_last"`:
    model = Sequential()
    model.add(LocallyConnected2D(64, (3, 3), input_shape=(32, 32, 3)))
    # now model.output_shape == (None, 30, 30, 64)
    # notice that this layer will consume (30*30)*(3*3*3*64) + (30*30)*64 parameters
    # add a 3x3 unshared weights convolution on top, with 32 output filters:
    model.add(LocallyConnected2D(32, (3, 3)))
    # now model.output_shape == (None, 28, 28, 32)
 
    
    
    
##Keras -Recurrent Layers
#output is to be fed back to input
#Arg  units: Positive integer, dimensionality of the output space.
#Arg filters(for conv type) Integer, the dimensionality of the output space (i.e. the number output of filters in the convolution).
#If first layer, provide 'input_shape' argument 

keras.layers.SimpleRNN(units, activation='tanh', use_bias=True, kernel_initializer='glorot_uniform', recurrent_initializer='orthogonal', bias_initializer='zeros', kernel_regularizer=None, recurrent_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, recurrent_constraint=None, bias_constraint=None, dropout=0.0, recurrent_dropout=0.0, return_sequences=False, return_state=False, go_backwards=False, stateful=False, unroll=False)
    Fully-connected RNN where the output is to be fed back to input.
    Arguments
        units: Positive integer, dimensionality of the output space.
        activation: Activation function to use (see activations). If you pass None, no activation is applied (ie. "linear" activation: a(x) = x).
        use_bias: Boolean, whether the layer uses a bias vector.
        kernel_initializer: Initializer for the kernel weights matrix, used for the linear transformation of the inputs. (see initializers).
        recurrent_initializer: Initializer for the recurrent_kernel weights matrix, used for the linear transformation of the recurrent state. (see initializers).
        bias_initializer: Initializer for the bias vector (see initializers).
        kernel_regularizer: Regularizer function applied to the kernel weights matrix (see regularizer).
        recurrent_regularizer: Regularizer function applied to the recurrent_kernel weights matrix (see regularizer).
        bias_regularizer: Regularizer function applied to the bias vector (see regularizer).
        activity_regularizer: Regularizer function applied to the output of the layer (its "activation"). (see regularizer).
        kernel_constraint: Constraint function applied to the kernel weights matrix (see constraints).
        recurrent_constraint: Constraint function applied to the recurrent_kernel weights matrix (see constraints).
        bias_constraint: Constraint function applied to the bias vector (see constraints).
        dropout: Float between 0 and 1. Fraction of the units to drop for the linear transformation of the inputs.
        recurrent_dropout: Float between 0 and 1. Fraction of the units to drop for the linear transformation of the recurrent state.
        return_sequences: Boolean. Whether to return the last output. in the output sequence, or the full sequence.
        return_state: Boolean. Whether to return the last state in addition to the output.
        go_backwards: Boolean (default False). If True, process the input sequence backwards and return the reversed sequence.
        stateful: Boolean (default False). If True, the last state for each sample at index i in a batch will be used as initial state for the sample of index i in the following batch.
        unroll: Boolean (default False). If True, the network will be unrolled, else a symbolic loop will be used. Unrolling can speed-up a RNN, although it tends to be more memory-intensive. Unrolling is only suitable for short sequences.


keras.layers.GRU(units, activation='tanh', recurrent_activation='hard_sigmoid', use_bias=True, kernel_initializer='glorot_uniform', recurrent_initializer='orthogonal', bias_initializer='zeros', kernel_regularizer=None, recurrent_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, recurrent_constraint=None, bias_constraint=None, dropout=0.0, recurrent_dropout=0.0, implementation=1, return_sequences=False, return_state=False, go_backwards=False, stateful=False, unroll=False)
    Gated Recurrent Unit - Cho et al. 2014.
    
keras.layers.LSTM(units, activation='tanh', recurrent_activation='hard_sigmoid', use_bias=True, kernel_initializer='glorot_uniform', recurrent_initializer='orthogonal', bias_initializer='zeros', unit_forget_bias=True, kernel_regularizer=None, recurrent_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, recurrent_constraint=None, bias_constraint=None, dropout=0.0, recurrent_dropout=0.0, implementation=1, return_sequences=False, return_state=False, go_backwards=False, stateful=False, unroll=False)
    Long-Short Term Memory layer - Hochreiter 1997.
    
keras.layers.ConvLSTM2D(filters, kernel_size, strides=(1, 1), padding='valid', data_format=None, dilation_rate=(1, 1), activation='tanh', recurrent_activation='hard_sigmoid', use_bias=True, kernel_initializer='glorot_uniform', recurrent_initializer='orthogonal', bias_initializer='zeros', unit_forget_bias=True, kernel_regularizer=None, recurrent_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, recurrent_constraint=None, bias_constraint=None, return_sequences=False, go_backwards=False, stateful=False, dropout=0.0, recurrent_dropout=0.0)
    Convolutional LSTM.
    It is similar to an LSTM layer, 
    but the input transformations and recurrent transformations 
    are both convolutional.
    
#To build complex model of stacked cell, use *Cell version 
keras.layers.StackedRNNCells(cells)
    Wrapper allowing a stack of RNN cells to behave as a single cell.
    Used to implement efficient stacked RNNs.
    Arguments
        cells: List of RNN cell instances.
    #Examples
    cells = [
        keras.layers.LSTMCell(output_dim),
        keras.layers.LSTMCell(output_dim),
        keras.layers.LSTMCell(output_dim),
    ]
    inputs = keras.Input((timesteps, input_dim))
    x = keras.layers.RNN(cells)(inputs)
keras.layers.SimpleRNNCell(units, activation='tanh', use_bias=True, kernel_initializer='glorot_uniform', recurrent_initializer='orthogonal', bias_initializer='zeros', kernel_regularizer=None, recurrent_regularizer=None, bias_regularizer=None, kernel_constraint=None, recurrent_constraint=None, bias_constraint=None, dropout=0.0, recurrent_dropout=0.0)
    Cell class for SimpleRNN.
keras.layers.GRUCell(units, activation='tanh', recurrent_activation='hard_sigmoid', use_bias=True, kernel_initializer='glorot_uniform', recurrent_initializer='orthogonal', bias_initializer='zeros', kernel_regularizer=None, recurrent_regularizer=None, bias_regularizer=None, kernel_constraint=None, recurrent_constraint=None, bias_constraint=None, dropout=0.0, recurrent_dropout=0.0, implementation=1)
    Cell class for the GRU layer.
keras.layers.LSTMCell(units, activation='tanh', recurrent_activation='hard_sigmoid', use_bias=True, kernel_initializer='glorot_uniform', recurrent_initializer='orthogonal', bias_initializer='zeros', unit_forget_bias=True, kernel_regularizer=None, recurrent_regularizer=None, bias_regularizer=None, kernel_constraint=None, recurrent_constraint=None, bias_constraint=None, dropout=0.0, recurrent_dropout=0.0, implementation=1)
    Cell class for the LSTM layer.


#GPU version - Can only be run on GPU, with the TensorFlow backend.
keras.layers.CuDNNGRU(units, kernel_initializer='glorot_uniform', recurrent_initializer='orthogonal', bias_initializer='zeros', kernel_regularizer=None, recurrent_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, recurrent_constraint=None, bias_constraint=None, return_sequences=False, return_state=False, stateful=False)
    Fast GRU implementation backed by CuDNN.
keras.layers.CuDNNLSTM(units, kernel_initializer='glorot_uniform', recurrent_initializer='orthogonal', bias_initializer='zeros', unit_forget_bias=True, kernel_regularizer=None, recurrent_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, recurrent_constraint=None, bias_constraint=None, return_sequences=False, return_state=False, stateful=False)
    Fast LSTM implementation backed by CuDNN.
 
 

     
 
##Keras - Normalization Layers

keras.layers.BatchNormalization(axis=-1, momentum=0.99, epsilon=0.001, center=True, scale=True, beta_initializer='zeros', gamma_initializer='ones', moving_mean_initializer='zeros', moving_variance_initializer='ones', beta_regularizer=None, gamma_regularizer=None, beta_constraint=None, gamma_constraint=None)
    Batch normalization layer 
    Normalize the activations of the previous layer at each batch, 
    i.e. applies a transformation that maintains the mean activation close to 0 
    and the activation standard deviation close to 1.
    Arguments
        axis: Integer, the axis that should be normalized (typically the features axis). 
            For instance, after a Conv2D layer with data_format="channels_first", 
            set axis=1 in BatchNormalization.
        momentum: Momentum for the moving average.
        epsilon: Small float added to variance to avoid dividing by zero.
        center: If True, add offset of beta to normalized tensor. 
            If False, beta is ignored.
        scale: If True, multiply by gamma. If False, gamma is not used. 
            When the next layer is linear (also e.g. nn.relu), this can be disabled since the scaling will be done by the next layer.
        beta_initializer: Initializer for the beta weight.
        gamma_initializer: Initializer for the gamma weight.
        moving_mean_initializer: Initializer for the moving mean.
        moving_variance_initializer: Initializer for the moving variance.
        beta_regularizer: Optional regularizer for the beta weight.
        gamma_regularizer: Optional regularizer for the gamma weight.
        beta_constraint: Optional constraint for the beta weight.
        gamma_constraint: Optional constraint for the gamma weight.
    Input shape
        Arbitrary. Use the keyword argument 'input_shape'
        (tuple of integers, does not include the samples axis) 
        when using this layer as the first layer in a model.
    Output shape
        Same shape as input.
        
        

##Keras - Noise layers
keras.layers.GaussianNoise(stddev)
    Apply additive zero-centered Gaussian noise.
    This is useful to mitigate overfitting 
    (you could see it as a form of random data augmentation). 
    Gaussian Noise (GS) is a natural choice as corruption process 
    for real valued inputs.
    As it is a regularization layer, it is only active at training time.
    Arguments
        stddev: float, standard deviation of the noise distribution.
    Input shape
        Arbitrary. Use the keyword argument 'input_shape '
        (tuple of integers, does not include the samples axis) 
        when using this layer as the first layer in a model.
    Output shape
        Same shape as input.

keras.layers.GaussianDropout(rate)
    Apply multiplicative 1-centered Gaussian noise.
    A Simple Way to Prevent Neural Networks from Overfitting 
    As it is a regularization layer, it is only active at training time.
    Arguments
        rate: float, drop probability (as with Dropout). 
            The multiplicative noise will have standard deviation sqrt(rate / (1 - rate)).
    Input shape
        Arbitrary. Use the keyword argument 'input_shape '
        (tuple of integers, does not include the samples axis) 
        when using this layer as the first layer in a model.
    Output shape
        Same shape as input.

keras.layers.AlphaDropout(rate, noise_shape=None, seed=None)
    Applies Alpha Dropout to the input.
    Alpha Dropout is a Dropout that keeps mean and variance of inputs 
    to their original values, in order to ensure the self-normalizing property even after this dropout. 
    Alpha Dropout fits well to Scaled Exponential Linear Units by randomly setting activations 
    to the negative saturation value.
    Arguments
        rate: float, drop probability (as with Dropout). The multiplicative noise will have standard deviation sqrt(rate / (1 - rate)).
        seed: A Python integer to use as random seed.
    Input shape
        Arbitrary. Use the keyword argument 'input_shape '
        (tuple of integers, does not include the samples axis) 
        when using this layer as the first layer in a model.
    Output shape
        Same shape as input.

        
    

###+++ Keras - Usage of initializers
#Initializations define the way to set the initial random weights of Keras layers.


from keras import initializers
model.add(Dense(64, kernel_initializer=initializers.random_normal(stddev=0.01)))
#OR
# also works; will use the default parameters.
model.add(Dense(64,kernel_initializer='random_uniform', bias_initializer='zeros'))
 


##Available initializers
keras.initializers.Zeros()
    Initializer that generates tensors initialized to 0.
keras.initializers.Ones()
    Initializer that generates tensors initialized to 1.
keras.initializers.Constant(value=0)
    value: float; the value of the generator tensors.
keras.initializers.RandomNormal(mean=0.0, stddev=0.05, seed=None)
    Initializer that generates tensors with a normal distribution.
keras.initializers.RandomUniform(minval=-0.05, maxval=0.05, seed=None)
    Initializer that generates tensors with a uniform distribution.
keras.initializers.TruncatedNormal(mean=0.0, stddev=0.05, seed=None)
    Initializer that generates a truncated normal distribution.
    
keras.initializers.VarianceScaling(scale=1.0, mode='fan_in', distribution='normal', seed=None)
    Initializer capable of adapting its scale to the shape of weights.
    With distribution="normal", samples are drawn from a truncated normal distribution 
    centered on zero, with stddev = sqrt(scale / n) where n is:
        number of input units in the weight tensor, if mode = "fan_in"
        number of output units, if mode = "fan_out"
        average of the numbers of input and output units, if mode = "fan_avg"
    With distribution="uniform", samples are drawn from a uniform distribution 
    within [-limit, limit], with limit = sqrt(3 * scale / n).
    Arguments
        scale: Scaling factor (positive float).
        mode: One of "fan_in", "fan_out", "fan_avg".
        distribution: Random distribution to use. One of "normal", "uniform".
        seed: A Python integer. Used to seed the random generator.
        
keras.initializers.Orthogonal(gain=1.0, seed=None)
    Initializer that generates a random orthogonal matrix.
    Arguments
        gain: Multiplicative factor to apply to the orthogonal matrix.
        seed: A Python integer. Used to seed the random generator.
        
keras.initializers.Identity(gain=1.0)
    Initializer that generates the identity matrix.
    Only use for square 2D matrices.
    Arguments
        gain: Multiplicative factor to apply to the identity matrix.

lecun_uniform(seed=None)
    LeCun uniform initializer.
    It draws samples from a uniform distribution within [-limit, limit] 
    where limit is sqrt(3 / fan_in) where fan_in is the number of input units 
    in the weight tensor.
    Arguments
        seed: A Python integer. Used to seed the random generator.

glorot_normal(seed=None)
    Glorot normal initializer, also called Xavier normal initializer.
    It draws samples from a truncated normal distribution centered on 0 
    with stddev = sqrt(2 / (fan_in + fan_out)) 
    where fan_in is the number of input units in the weight tensor 
    and fan_out is the number of output units in the weight tensor.
    Arguments
        seed: A Python integer. Used to seed the random generator.

glorot_uniform(seed=None)
    Glorot uniform initializer, also called Xavier uniform initializer.
    It draws samples from a uniform distribution within [-limit, limit] 
    where limit is sqrt(6 / (fan_in + fan_out)) 
    where fan_in is the number of input units in the weight tensor 
    and fan_out is the number of output units in the weight tensor.
    Arguments
        seed: A Python integer. Used to seed the random generator.

he_normal(seed=None)
    He normal initializer.
    It draws samples from a truncated normal distribution centered on 0 
    with stddev = sqrt(2 / fan_in) where fan_in is the number of input units in the weight tensor.
    Arguments
        seed: A Python integer. Used to seed the random generator.

lecun_normal(seed=None)
    LeCun normal initializer.
    It draws samples from a truncated normal distribution centered on 0 
    with stddev = sqrt(1 / fan_in) where fan_in is the number of input units in the weight tensor.
    Arguments
        seed: A Python integer. Used to seed the random generator.

he_uniform(seed=None)
    He uniform variance scaling initializer.
    It draws samples from a uniform distribution within [-limit, limit] 
    where limit is sqrt(6 / fan_in) where fan_in is the number of input units in the weight tensor.
    Arguments
        seed: A Python integer. Used to seed the random generator.


##Using custom initializers
#If passing a custom callable, then it must take the argument shape 
#(shape of the variable to initialize) and dtype (dtype of generated values):

from keras import backend as K

def my_init(shape, dtype=None):
    return K.random_normal(shape, dtype=dtype)

model.add(Dense(64, kernel_initializer=my_init))





###+++ Keras - Regularizers for overfitting 
#Regularizers allow to apply penalties on layer parameters or layer activity during optimization. 

#These penalties are incorporated in the loss function that the network optimizes.

#The penalties are applied on a per-layer basis. 
#The exact API will depend on the layer, 
#but the layers Dense, Conv1D, Conv2D and Conv3D have a unified API.
#These layers expose 3 keyword arguments:
    kernel_regularizer
        instance of keras.regularizers.Regularizer
    bias_regularizer
        instance of keras.regularizers.Regularizer
    activity_regularizer
        instance of keras.regularizers.Regularizer

#Example
from keras import regularizers
model.add(Dense(64, input_dim=64,
                kernel_regularizer=regularizers.l2(0.01),
                activity_regularizer=regularizers.l1(0.01)))

##Available penalties
keras.regularizers.l1(0.)
keras.regularizers.l2(0.)
keras.regularizers.l1_l2(0.)


##Developing new regularizers
#Any function that takes in a weight matrix 
#and returns a loss contribution tensor can be used as a regularizer, e.g.:

from keras import backend as K

def l1_reg(weight_matrix):
    return 0.01 * K.sum(K.abs(weight_matrix))

model.add(Dense(64, input_dim=64,
                kernel_regularizer=l1_reg))
                
                

###+++ Keras - constraints
#Functions from the constraints module allow setting constraints 
#(eg. non-negativity) on network parameters during optimization.

#The exact API will depend on the layer, 
#but the layers Dense, Conv1D, Conv2D and Conv3D have a unified API.
#These layers expose 2 keyword arguments:
    kernel_constraint 
        for the main weights matrix
    bias_constraint 
        for the bias.

from keras.constraints import max_norm
model.add(Dense(64, kernel_constraint=max_norm(2.)))

##Available constraints
max_norm(max_value=2, axis=0)
    maximum-norm constraint
non_neg()
    non-negativity constraint
unit_norm(axis=0)
    unit-norm constraint
min_max_norm(min_value=0.0, max_value=1.0, rate=1.0, axis=0)
    minimum/maximum-norm constraint







###Keras - Callbacks
#A callback is a set of functions to be applied at given stages of the training procedure. 

#You can use callbacks to get a view on internal states 
#and statistics of the model during training. 

#You can pass a list of callbacks (as the keyword argument callbacks) 
#to the .fit() method of the Sequential or Model classes. 
#The relevant methods of the callbacks will then be called at each stage of the training.

#For example using below loggers 
csv_logger = keras.callbacks.CSVLogger('training.log', separator=',', append=False)
tensor_logger = keras.callbacks.TensorBoard(log_dir='./logs', histogram_freq=0, batch_size=32, write_graph=True, write_grads=False, write_images=False, embeddings_freq=0, embeddings_layer_names=None, embeddings_metadata=None)
model.fit(X_train, Y_train, callbacks=[csv_logger,tensor_logger])

##Reference 
keras.callbacks.Callback()
    Abstract base class used to build new callbacks.
    Properties
        params: dict
            Training parameters 
            (eg. verbosity, batch size, number of epochs...).
        model: instance of keras.models.Model.
            Reference of the model being trained.
    callback methods take logs dictionary ,contains keys for quantities relevant to the current batch or epoch.
    Following events would send logs with following keys 
        on_epoch_end: logs include acc and loss, 
                and optionally include val_loss (if validation is enabled in fit), 
                and val_acc (if validation and accuracy monitoring are enabled).
        on_batch_begin: logs include size, the number of samples in the current batch.
        on_batch_end: logs include loss, and optionally acc (if accuracy monitoring is enabled).
    #Implements below call back methods which would get called 
    def on_epoch_begin(epoch,logs) 
    def on_epoch_end(epoch,logs)
    def on_batch_begin(batch,logs) 
    def on_batch_end(batch,logs) 
    def on_train_begin(logs) 
    def on_train_end(logs)

#Predefined callbacks 
keras.callbacks.BaseLogger()
    Callback that accumulates epoch averages of metrics.
    This callback is automatically applied to every Keras model.
    
keras.callbacks.TerminateOnNaN()
    Callback that terminates training when a NaN loss is encountered.
    
keras.callbacks.ProgbarLogger(count_mode='samples')
    Callback that prints metrics to stdout.
    Arguments
        count_mode: One of "steps" or "samples". 
            Whether the progress bar should count samples seen or steps (batches) seen.
            
keras.callbacks.History()
    Callback that records events into a History object.
    This callback is automatically applied to every Keras model. 
    The History object gets returned by the fit method of models.
    
keras.callbacks.ModelCheckpoint(filepath, monitor='val_loss', verbose=0, save_best_only=False, save_weights_only=False, mode='auto', period=1)
    Save the model after every epoch.
    filepath can contain named formatting options, 
    which will be filled the value of epoch and keys in logs  (passed in on_epoch_end).
    For example: if filepath is weights.{epoch:02d}-{val_loss:.2f}.hdf5, 
    then the model checkpoints will be saved with the epoch number 
    and the validation loss in the filename.
    Arguments
        filepath: string, path to save the model file.
        monitor: quantity to monitor.
        verbose: verbosity mode, 0 or 1.
        save_best_only: if save_best_only=True, the latest best model according to the quantity monitored will not be overwritten.
        mode: one of {auto, min, max}. If save_best_only=True, the decision to overwrite the current save file is made based on either the maximization or the minimization of the monitored quantity. For val_acc, this should be max, for val_loss this should be min, etc. In auto mode, the direction is automatically inferred from the name of the monitored quantity.
        save_weights_only: if True, then only the model's weights will be saved (model.save_weights(filepath)), else the full model is saved (model.save(filepath)).
        period: Interval (number of epochs) between checkpoints.

keras.callbacks.EarlyStopping(monitor='val_loss', min_delta=0, patience=0, verbose=0, mode='auto')
    Stop training when a monitored quantity has stopped improving.
    Arguments
        monitor: quantity to be monitored.
        min_delta: minimum change in the monitored quantity to qualify as an improvement, i.e. an absolute change of less than min_delta, will count as no improvement.
        patience: number of epochs with no improvement after which training will be stopped.
        verbose: verbosity mode.
        mode: one of {auto, min, max}. In min mode, training will stop when the quantity monitored has stopped decreasing; in max mode it will stop when the quantity monitored has stopped increasing; in auto mode, the direction is automatically inferred from the name of the monitored quantity.

keras.callbacks.RemoteMonitor(root='http://localhost:9000', path='/publish/epoch/end/', field='data', headers=None)
    Callback used to stream events to a server.
    Requires the requests library. 
    Events are sent to root + '/publish/epoch/end/' by default. 
    Calls are HTTP POST, with a data argument which is a JSON-encoded dictionary 
    of event data.
    Arguments
        root: String; root url of the target server.
        path: String; path relative to root to which the events will be sent.
        field: String; JSON field under which the data will be stored.
        headers: Dictionary; optional custom HTTP headers.

keras.callbacks.LearningRateScheduler(schedule)
    Learning rate scheduler.
    Arguments
        schedule: a function that takes an epoch index as input (integer, indexed from 0) 
            and returns a new learning rate as output (float).

keras.callbacks.TensorBoard(log_dir='./logs', histogram_freq=0, batch_size=32, write_graph=True, write_grads=False, write_images=False, embeddings_freq=0, embeddings_layer_names=None, embeddings_metadata=None)
    Tensorboard basic visualizations.
    TensorBoard is a visualization tool provided with TensorFlow.
    This callback writes a log for TensorBoard, 
    which allows you to visualize dynamic graphs of  training and test metrics, 
    as well as activation histograms for the different layers in  model.
    $ tensorboard --logdir=/full_path_to_your_logs
    Arguments
        log_dir: the path of the directory where to save the log files to be parsed by TensorBoard.
        histogram_freq: frequency (in epochs) at which to compute activation and weight histograms for the layers of the model. If set to 0, histograms won't be computed. Validation data (or split) must be specified for histogram visualizations.
        write_graph: whether to visualize the graph in TensorBoard. The log file can become quite large when write_graph is set to True.
        write_grads: whether to visualize gradient histograms in TensorBoard. histogram_freq must be greater than 0.
        batch_size: size of batch of inputs to feed to the network for histograms computation.
        write_images: whether to write model weights to visualize as image in TensorBoard.
        embeddings_freq: frequency (in epochs) at which selected embedding layers will be saved.
        embeddings_layer_names: a list of names of layers to keep eye on. If None or empty list all the embedding layer will be watched.
        embeddings_metadata: a dictionary which maps layer name to a file name in which metadata for this embedding layer is saved. See the details about metadata files format. In case if the same metadata file is used for all embedding layers, string can be passed.

keras.callbacks.ReduceLROnPlateau(monitor='val_loss', factor=0.1, patience=10, verbose=0, mode='auto', epsilon=0.0001, cooldown=0, min_lr=0)
    Reduce learning rate when a metric has stopped improving.
    Models often benefit from reducing the learning rate by a factor of 2-10 
    once learning stagnates. 
    This callback monitors a quantity 
    and if no improvement is seen for a 'patience' number of epochs, 
    the learning rate is reduced.
    Arguments
        monitor: quantity to be monitored.
        factor: factor by which the learning rate will be reduced. new_lr = lr * factor
        patience: number of epochs with no improvement after which learning rate will be reduced.
        verbose: int. 0: quiet, 1: update messages.
        mode: one of {auto, min, max}. In min mode, lr will be reduced when the quantity monitored has stopped decreasing; in max mode it will be reduced when the quantity monitored has stopped increasing; in auto mode, the direction is automatically inferred from the name of the monitored quantity.
        epsilon: threshold for measuring the new optimum, to only focus on significant changes.
        cooldown: number of epochs to wait before resuming normal operation after lr has been reduced.
        min_lr: lower bound on the learning rate.
    #Example
    reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.2,
                                  patience=5, min_lr=0.001)
    model.fit(X_train, Y_train, callbacks=[reduce_lr])

keras.callbacks.CSVLogger(filename, separator=',', append=False)
    Callback that streams epoch results to a csv file.
    Supports all values that can be represented as a string, 
    including 1D iterables such as np.ndarray.
    Arguments
        filename: filename of the csv file, e.g. 'run/log.csv'.
        separator: string used to separate elements in the csv file.
        append: True: append if file exists (useful for continuing training). 
            False: overwrite existing file,
    #Example
    csv_logger = CSVLogger('training.log')
    model.fit(X_train, Y_train, callbacks=[csv_logger])

keras.callbacks.LambdaCallback(on_epoch_begin=None, on_epoch_end=None, on_batch_begin=None, on_batch_end=None, on_train_begin=None, on_train_end=None)
    Callback for creating simple, custom callbacks on-the-fly.
    This callback is constructed with anonymous functions 
    that will be called at the appropriate time. 
    Note that the callbacks expects positional arguments, as:
        on_epoch_begin and on_epoch_end expect two positional arguments: epoch, logs
        on_batch_begin and on_batch_end expect two positional arguments: batch, logs
        on_train_begin and on_train_end expect one positional argument: logs
    Arguments
        on_epoch_begin: called at the beginning of every epoch.
        on_epoch_end: called at the end of every epoch.
        on_batch_begin: called at the beginning of every batch.
        on_batch_end: called at the end of every batch.
        on_train_begin: called at the beginning of model training.
        on_train_end: called at the end of model training.
    Following events would send logs with following keys 
        on_epoch_end: logs include acc and loss, 
                and optionally include val_loss (if validation is enabled in fit), and val_acc (if validation and accuracy monitoring are enabled).
        on_batch_begin: logs include size, the number of samples in the current batch.
        on_batch_end: logs include loss, and optionally acc (if accuracy monitoring is enabled).
  
    #Example
    # Print the batch number at the beginning of every batch.
    batch_print_callback = LambdaCallback(
        on_batch_begin=lambda batch,logs: print(batch))
    # Stream the epoch loss to a file in JSON format. The file content
    # is not well-formed JSON but rather has a JSON object per line.
    import json
    json_log = open('loss_log.json', mode='wt', buffering=1)
    json_logging_callback = LambdaCallback(
        on_epoch_end=lambda epoch, logs: json_log.write(
            json.dumps({'epoch': epoch, 'loss': logs['loss']}) + '\n'),
        on_train_end=lambda logs: json_log.close()
    )
    # Terminate some processes after having finished model training.
    processes = ...
    cleanup_callback = LambdaCallback(
        on_train_end=lambda logs: [
            p.terminate() for p in processes if p.is_alive()])

    model.fit(...,
              callbacks=[batch_print_callback,
                         json_logging_callback,
                         cleanup_callback])

                         
                         
                         
                         
##Create a callback
#example saving a list of losses over each batch during training:
#logs is a dict with below keys 
#on_epoch_end: logs include acc and loss, and optionally include val_loss (if validation is enabled in fit),and val_acc (if validation and accuracy monitoring are enabled).
#on_batch_begin: logs include size, the number of samples in the current batch.
#on_batch_end: logs include loss, and optionally acc (if accuracy monitoring is enabled).
        
class LossHistory(keras.callbacks.Callback):
    def on_train_begin(self, logs={}):
        self.losses = []

    def on_batch_end(self, batch, logs={}):
        self.losses.append(logs.get('loss'))

#Example: recording loss history

class LossHistory(keras.callbacks.Callback):
    def on_train_begin(self, logs={}):
        self.losses = []

    def on_batch_end(self, batch, logs={}):
        self.losses.append(logs.get('loss'))

model = Sequential()
model.add(Dense(10, input_dim=784, kernel_initializer='uniform'))
model.add(Activation('softmax'))
model.compile(loss='categorical_crossentropy', optimizer='rmsprop')

history = LossHistory()
model.fit(x_train, y_train, batch_size=128, epochs=20, verbose=0, callbacks=[history])

print(history.losses)
# outputs
'''
[0.66047596406559383, 0.3547245744908703, ..., 0.25953155204159617, 0.25901699725311789]
'''

##Example: model checkpoints

from keras.callbacks import ModelCheckpoint

model = Sequential()
model.add(Dense(10, input_dim=784, kernel_initializer='uniform'))
model.add(Activation('softmax'))
model.compile(loss='categorical_crossentropy', optimizer='rmsprop')

'''
saves the model weights after each epoch if the validation loss decreased
'''
checkpointer = ModelCheckpoint(filepath='/tmp/weights.hdf5', verbose=1, save_best_only=True)
model.fit(x_train, y_train, batch_size=128, epochs=20, verbose=0, validation_data=(X_test, Y_test), callbacks=[checkpointer])

    
    
    
    
    
###+++ Keras - Datasets

CIFAR10 small image classification
    Dataset of 50,000 32x32 color training images, 
    labeled over 10 categories, and 10,000 test images.
    Returns:
    2 tuples:
        x_train, x_test: uint8 array of RGB image data with shape (num_samples, 3, 32, 32) with "channels_first"
        y_train, y_test: uint8 array of category labels (integers in range 0-9) with shape (num_samples,).
    #Usage:
    from keras.datasets import cifar10
    (x_train, y_train), (x_test, y_test) = cifar10.load_data()  
    
CIFAR100 small image classification
    Dataset of 50,000 32x32 color training images, labeled over 100 categories, and 10,000 test images.
    Returns:
    2 tuples:
        x_train, x_test: uint8 array of RGB image data with shape (num_samples, 3, 32, 32).
        y_train, y_test: uint8 array of category labels with shape (num_samples,).
    Arguments:
        label_mode: "fine" or "coarse".
    #Usage:
    from keras.datasets import cifar100
    (x_train, y_train), (x_test, y_test) = cifar100.load_data(label_mode='fine')

    
IMDB Movie reviews sentiment classification
    Dataset of 25,000 movies reviews from IMDB, 
    labeled by sentiment (positive/negative). 
    Reviews have been preprocessed, and each review is encoded as a sequence of word indexes (integers)(can be used directly to Embedding)
    For convenience, words are indexed by overall frequency in the dataset, 
    so that for instance the integer "3" encodes the 3rd most frequent word in the data. 
    This allows for quick filtering operations such as: 
    "only consider the top 10,000 most common words, but eliminate the top 20 most common words".
    As a convention, "0" does not stand for a specific word, but instead is used to encode any unknown word.
    Returns:
        2 tuples:
            x_train, x_test: list of sequences, which are lists of indexes (integers). If the num_words argument was specific, the maximum possible index value is num_words-1. If the maxlen argument was specified, the largest possible sequence length is maxlen.
            y_train, y_test: list of integer labels (1 or 0).
    Arguments:
        path: if you do not have the data locally (at '~/.keras/datasets/' + path), it will be downloaded to this location.
        num_words: integer or None. Top most frequent words to consider. Any less frequent word will appear as oov_char value in the sequence data.
        skip_top: integer. Top most frequent words to ignore (they will appear as oov_char value in the sequence data).
        maxlen: int. Maximum sequence length. Any longer sequence will be truncated.
        seed: int. Seed for reproducible data shuffling.
        start_char: int. The start of a sequence will be marked with this character. Set to 1 because 0 is usually the padding character.
        oov_char: int. words that were cut out because of the num_words or skip_top limit will be replaced with this character.
        index_from: int. Index actual words with this index and higher.
    #Usage:
    from keras.datasets import imdb
    (x_train, y_train), (x_test, y_test) = imdb.load_data(path="imdb.npz",
                                                          num_words=None,
                                                          skip_top=0,
                                                          maxlen=None,
                                                          seed=113,
                                                          start_char=1,
                                                          oov_char=2,
                                                          index_from=3)      
        
Reuters newswire topics classification
    Dataset of 11,228 newswires from Reuters, labeled over 46 topics. 
    As with the IMDB dataset, each wire is encoded as a sequence of word indexes  (can be used directly to Embedding).
    Returns
        A dictionary where key are words (str) and values are indexes (integer). 
        eg. word_index["giraffe"] might return 1234.
    Arguments:
        path: if you do not have the index file locally (at '~/.keras/datasets/' + path), 
            it will be downloaded to this location.
    #Usage:
    from keras.datasets import reuters
    (x_train, y_train), (x_test, y_test) = reuters.load_data(path="reuters.npz",
                                                             num_words=None,
                                                             skip_top=0,
                                                             maxlen=None,
                                                             test_split=0.2,
                                                             seed=113,
                                                             start_char=1,
                                                             oov_char=2,
                                                             index_from=3)
    #This dataset also makes available the word index used for encoding the sequences:
    word_index = reuters.get_word_index(path="reuters_word_index.json")

    
MNIST database of handwritten digits
    Dataset of 60,000 28x28 grayscale images of the 10 digits, 
    along with a test set of 10,000 images.
    Returns:
        2 tuples:
            x_train, x_test: uint8 array of grayscale image data with shape (num_samples, 28, 28).
            y_train, y_test: uint8 array of digit labels (integers in range 0-9) with shape (num_samples,).
    Arguments:
        path: if you do not have the index file locally (at '~/.keras/datasets/' + path), it will be downloaded to this location.
    #Usage:
    from keras.datasets import mnist
    (x_train, y_train), (x_test, y_test) = mnist.load_data()

    
Fashion-MNIST database of fashion articles
    Dataset of 60,000 28x28 grayscale images of 10 fashion categories, 
    along with a test set of 10,000 images. 
    This dataset can be used as a drop-in replacement for MNIST. 
    The class labels are:
        Label 	Description
        0 	T-shirt/top
        1 	Trouser
        2 	Pullover
        3 	Dress
        4 	Coat
        5 	Sandal
        6 	Shirt
        7 	Sneaker
        8 	Bag
        9 	Ankle boot
    Returns:
        2 tuples:
            x_train, x_test: uint8 array of grayscale image data with shape (num_samples, 28, 28).
            y_train, y_test: uint8 array of labels (integers in range 0-9) with shape (num_samples,).
    #Usage:
    from keras.datasets import fashion_mnist
    (x_train, y_train), (x_test, y_test) = fashion_mnist.load_data()


Boston housing price regression dataset
    Dataset taken from the StatLib library which is maintained at Carnegie Mellon University.
    Samples contain 13 attributes of houses at different locations around the Boston suburbs in the late 1970s.
    Targets are the median values of the houses at a location (in k$).
    Arguments:
        path: path where to cache the dataset locally (relative to ~/.keras/datasets).
        seed: Random seed for shuffling the data before computing the test split.
        test_split: fraction of the data to reserve as test set.
    Returns: Tuple of Numpy arrays: (x_train, y_train), (x_test, y_test).
    #Usage:
    from keras.datasets import boston_housing
    (x_train, y_train), (x_test, y_test) = boston_housing.load_data()






###+++ Keras - Applications - DNN models with pretrained weights 
#https://keras.io/applications/
#These models can be used for prediction, feature extraction, and fine-tuning.

#Weights are downloaded automatically when instantiating a model. 
#They are stored at ~/.keras/models/.

#Available models
#Models for image classification with weights trained on ImageNet:
    Xception
    VGG16
    VGG19
    ResNet50
    InceptionV3
    InceptionResNetV2
    MobileNet
#Documentation for individual models
#The top-1 and top-5 accuracy refers to the model's performance on the ImageNet validation dataset.
Model 	            Size 	Top-1 Accuracy 	Top-5 Accuracy 	Parameters 	Depth
Xception 	        88 MB 	0.790 	        0.945 	        22,910,480 	126
VGG16 	            528 MB 	0.715 	        0.901 	        138,357,544 23
VGG19 	            549 MB 	0.727 	        0.910 	        143,667,240 26
ResNet50 	        99 MB 	0.759 	        0.929 	        25,636,712 	168
InceptionV3 	    92 MB 	0.788 	        0.944 	        23,851,784 	159
InceptionResNetV2 	215 MB 	0.804 	        0.953 	        55,873,736 	572
MobileNet 	        17 MB 	0.665 	0.871 	                        4,253,864 	88


##List of models 

keras.applications.xception.Xception(include_top=True, weights='imagenet', input_tensor=None, input_shape=None, pooling=None, classes=1000)
    Xception V1 model, with weights pre-trained on ImageNet.
    The default input size for this model is 299x299.
keras.applications.vgg16.VGG16(include_top=True, weights='imagenet', input_tensor=None, input_shape=None, pooling=None, classes=1000)
    VGG16 model, with weights pre-trained on ImageNet.
    The default input size for this model is 224x224.
keras.applications.vgg19.VGG19(include_top=True, weights='imagenet', input_tensor=None, input_shape=None, pooling=None, classes=1000)
    VGG19 model, with weights pre-trained on ImageNet.
    The default input size for this model is 224x224.
keras.applications.resnet50.ResNet50(include_top=True, weights='imagenet', input_tensor=None, input_shape=None, pooling=None, classes=1000)
    ResNet50 model, with weights pre-trained on ImageNet.
    The default input size for this model is 224x224.
keras.applications.inception_v3.InceptionV3(include_top=True, weights='imagenet', input_tensor=None, input_shape=None, pooling=None, classes=1000)
    Inception V3 model, with weights pre-trained on ImageNet.
    The default input size for this model is 299x299.
keras.applications.inception_resnet_v2.InceptionResNetV2(include_top=True, weights='imagenet', input_tensor=None, input_shape=None, pooling=None, classes=1000)
    Inception-ResNet V2 model, with weights pre-trained on ImageNet.
    The default input size for this model is 299x299.
keras.applications.mobilenet.MobileNet(input_shape=None, alpha=1.0, depth_multiplier=1, dropout=1e-3, include_top=True, weights='imagenet', input_tensor=None, pooling=None, classes=1000)
    MobileNet model, with weights pre-trained on ImageNet.
    The default input size for this model is 224x224.
        
#All of these architectures (except Xception and MobileNet) 
#are compatible with both TensorFlow and Theano, 
#and upon instantiation the models will be built according to the image data format 
#set in your Keras configuration file at ~/.keras/keras.json. 

#The Xception model is only available for TensorFlow,due to its reliance on SeparableConvolution layers. 
#The MobileNet model is only available for TensorFlow, due to its reliance on DepthwiseConvolution layers.

##Few importnat methods of these Models 
keras.applications.resnet50.preprocess_input
keras.applications.vgg16.preprocess_input
keras.applications.vgg19.preprocess_input

keras.applications.resnet50.preprocess_input(x,data_format=None, mode='caffe')
    Preprocesses  Numpy array encoding a batch of images.
    Arguments:
        x: Input Numpy , 3D or 4D.
        data_format: Data format of the image tensor/array.
        mode: One of "caffe", "tf". 
            caffe: will convert the images from RGB to BGR, then will zero-center each color channel with respect to the ImageNet dataset, without scaling. 
            tf: will scale pixels between -1 and 1, sample-wise.
    Returns:
    Preprocessed tensor or Numpy array.


##Keras - Applications - Classify ImageNet classes with ResNet50
from keras.applications.resnet50 import ResNet50
from keras.preprocessing import image
from keras.applications.resnet50 import preprocess_input, decode_predictions
import numpy as np

model = ResNet50(weights='imagenet')

img_path = 'elephant.jpg'
img = image.load_img(img_path, target_size=(224, 224)) #Loads an image into PIL format
x = image.img_to_array(img) #Converts a PIL Image instance to a Numpy array
x = np.expand_dims(x, axis=0) #Insert a new axis that will appear at the axis position in the expanded array shape.
x = preprocess_input(x)

preds = model.predict(x)
# decode the results into a list of tuples (class, description, probability)
# (one such list for each sample in the batch)
print('Predicted:', decode_predictions(preds, top=3)[0])
# Predicted: [(u'n02504013', u'Indian_elephant', 0.82658225), (u'n01871265', u'tusker', 0.1122357), (u'n02504458', u'African_elephant', 0.061040461)]



##Keras - Applications - Extract features with VGG16
from keras.applications.vgg16 import VGG16
from keras.preprocessing import image
from keras.applications.vgg16 import preprocess_input
import numpy as np

model = VGG16(weights='imagenet', include_top=False)

img_path = 'elephant.jpg'
img = image.load_img(img_path, target_size=(224, 224))
x = image.img_to_array(img)
x = np.expand_dims(x, axis=0)
x = preprocess_input(x)
features = model.predict(x)


##Keras - Applications - Extract features from an arbitrary intermediate layer with VGG19
from keras.applications.vgg19 import VGG19
from keras.preprocessing import image
from keras.applications.vgg19 import preprocess_input
from keras.models import Model
import numpy as np

base_model = VGG19(weights='imagenet')
model = Model(inputs=base_model.input, outputs=base_model.get_layer('block4_pool').output)

img_path = 'elephant.jpg'
img = image.load_img(img_path, target_size=(224, 224))
x = image.img_to_array(img)
x = np.expand_dims(x, axis=0)
x = preprocess_input(x)

block4_pool_features = model.predict(x)

##Keras - Applications - Fine-tune InceptionV3 on a new set of classes
from keras.applications.inception_v3 import InceptionV3
from keras.preprocessing import image
from keras.models import Model
from keras.layers import Dense, GlobalAveragePooling2D
from keras import backend as K

# create the base pre-trained model
base_model = InceptionV3(weights='imagenet', include_top=False)

# add a global spatial average pooling layer
x = base_model.output
x = GlobalAveragePooling2D()(x)
# let's add a fully-connected layer
x = Dense(1024, activation='relu')(x)
# and a logistic layer -- let's say we have 200 classes
predictions = Dense(200, activation='softmax')(x)

# this is the model we will train
model = Model(inputs=base_model.input, outputs=predictions)

# first: train only the top layers (which were randomly initialized)
# i.e. freeze all convolutional InceptionV3 layers
for layer in base_model.layers:
    layer.trainable = False

# compile the model (should be done *after* setting layers to non-trainable)
model.compile(optimizer='rmsprop', loss='categorical_crossentropy')

# train the model on the new data for a few epochs
model.fit_generator(...)

# at this point, the top layers are well trained and we can start fine-tuning
# convolutional layers from inception V3. We will freeze the bottom N layers
# and train the remaining top layers.

# let's visualize layer names and layer indices to see how many layers
# we should freeze:
for i, layer in enumerate(base_model.layers):
   print(i, layer.name)

# we chose to train the top 2 inception blocks, i.e. we will freeze
# the first 249 layers and unfreeze the rest:
for layer in model.layers[:249]:
   layer.trainable = False
for layer in model.layers[249:]:
   layer.trainable = True

# we need to recompile the model for these modifications to take effect
# we use SGD with a low learning rate
from keras.optimizers import SGD
model.compile(optimizer=SGD(lr=0.0001, momentum=0.9), loss='categorical_crossentropy')

# we train our model again (this time fine-tuning the top 2 inception blocks
# alongside the top Dense layers
model.fit_generator(...)


  
###+++ Keras - Model visualization

from keras.utils import plot_model
plot_model(model, to_file='model.png')

#plot_model takes two optional arguments:
show_shapes (defaults to False) 
    controls whether output shapes are shown in the graph.
show_layer_names (defaults to True) 
    controls whether layer names are shown in the graph.

#You can also directly obtain the pydot.Graph object 
#and render it yourself, for example to show it in an ipython notebook 
from IPython.display import SVG
from keras.utils.vis_utils import model_to_dot

SVG(model_to_dot(model).create(prog='dot', format='svg'))







###+++ Keras- multi-gpu model
keras.utils.multi_gpu_model(model, gpus)
    Replicates a model on different GPUs.
    Specifically, this function implements single-machine multi-GPU data parallelism. 
    It works in the following way:
        Divide the model's input(s) into multiple sub-batches.
        Apply a model copy on each sub-batch. Every model copy is executed on a dedicated GPU.
        Concatenate the results (on CPU) into one big batch.
    E.g. if your batch_size is 64 and you use gpus=2, 
    then we will divide the input into 2 sub-batches of 32 samples, 
    process each sub-batch on one GPU, then return the full batch of 64 processed samples.
    This induces quasi-linear speedup on up to 8 GPUs.
    This function is only available with the TensorFlow backend for the time being.
    Arguments
        model: A Keras model instance. To avoid OOM errors, this model could have been built on CPU, for instance
        gpus: Integer >= 2 or list of integers, number of GPUs or list of GPU IDs on which to create model replicas.
    Returns
        A Keras Model instance which can be used just like the initial model argument, 
        but which distributes its workload on multiple GPUs.
        
#To save the multi-gpu model, use .save(fname) or .save_weights(fname) with the template model 
# rather than the model returned by multi_gpu_model.
       
#Example
import tensorflow as tf
from keras.applications import Xception
from keras.utils import multi_gpu_model
import numpy as np

num_samples = 1000
height = 224
width = 224
num_classes = 1000

# Instantiate the base model (or "template" model).
# We recommend doing this with under a CPU device scope,
# so that the model's weights are hosted on CPU memory.
# Otherwise they may end up hosted on a GPU, which would
# complicate weight sharing.
with tf.device('/cpu:0'):
    model = Xception(weights=None,
                     input_shape=(height, width, 3),
                     classes=num_classes)

# Replicates the model on 8 GPUs.
# This assumes that your machine has 8 available GPUs.
parallel_model = multi_gpu_model(model, gpus=8)
parallel_model.compile(loss='categorical_crossentropy',optimizer='rmsprop')

# Generate dummy data.
x = np.random.random((num_samples, height, width, 3))
y = np.random.random((num_samples, num_classes))

# This `fit` call will be distributed on 8 GPUs.
# Since the batch size is 256, each GPU will process 32 samples.
parallel_model.fit(x, y, epochs=20, batch_size=256)

# Save model via the template model (which shares the same weights):
model.save('my_model.h5')









###+++ Keras - Wrappers for the Scikit-Learn API - only Sequential Keras models (single-input only)

#only Sequential Keras models (single-input only)
keras.wrappers.scikit_learn.KerasClassifier(build_fn=None, **sk_params)
    Implements the sklearn classifier interface,
keras.wrappers.scikit_learn.KerasRegressor(build_fn=None, **sk_params)
    Implements the sklearn regressor interface.
    build_fn
        a function(Optional_Model_params) returing compiled Sequential model 
    sk_params
       sk_params takes both  Model_params and fitting parameters ie parameters for calling  Sequential.fit, Sequential.predict,
       Sequential.predict_classes, Sequential.evaluate
       fitting/predicting parameters are selected in the following order:
            Values passed to the dictionary arguments of fit, predict, predict_proba, and score methods
            Values passed to sk_params
            The default values of the keras.models.Sequential fit, predict, predict_proba and score methods
       When using scikit-learn's grid_search API, 
       legal tunable parameters are those you could pass to sk_params,including fitting parameters. 
       For example, you could use grid_search 
       to search for the best batch_size or epochs as well as Model_params, build_fn's 
       #Methods 
           fit(self, x, y, sample_weight=None, **kwargs)
                Constructs a new model with build_fn & fit the model to (x, y).
                # Arguments
                x : array-like, shape (n_samples, n_features)
                    Training samples where n_samples is the number of samples
                    and n_features is the number of features.
                y : array-like, shape (n_samples,) or (n_samples, n_outputs)
                    True labels for x.
                **kwargs: dictionary arguments
                    Legal arguments are the arguments of Sequential.fit
                #Returns
                history : object
                    details about the training history at each epoch.
           predict(self, x, **kwargs):
               Returns the class predictions for the given test data.
                # Arguments
                    x: array-like, shape (n_samples, n_features)
                        Test samples where n_samples is the number of samples
                        and n_features is the number of features.
                    **kwargs: dictionary arguments
                        Legal arguments are the arguments
                        of Sequential.predict_classes.
                # Returns
                    preds: array-like, shape (n_samples,)
                        Class predictions.
            predict_proba(self, x, **kwargs):
                Returns class probability estimates for the given test data.
                # Arguments
                    x: array-like, shape (n_samples, n_features)
                        Test samples where n_samples is the number of samples
                        and n_features is the number of features.
                    **kwargs: dictionary arguments
                        Legal arguments are the arguments
                        of Sequential.predict_classes.
                # Returns
                    proba: array-like, shape (n_samples, n_outputs)
                        Class probability estimates.
                        In the case of binary classification,
                        to match the scikit-learn API,
                        will return an array of shape (n_samples, 2)
                        (instead of (n_sample, 1) as in Keras).           
            score(self, x, y, **kwargs):
                Returns the mean accuracy on the given test data and labels.
                # Arguments
                    x: array-like, shape (n_samples, n_features)
                        Test samples where n_samples is the number of samples
                        and n_features is the number of features.
                    y: array-like, shape (n_samples,) or (n_samples, n_outputs)
                        True labels for x.
                    **kwargs: dictionary arguments
                        Legal arguments are the arguments of Sequential.evaluate.
                # Returns
                    score: float
                        Mean accuracy of predictions on x wrt. y.

            
       
       
##Example of build_fn 
def create_model():
	#Create Sequential Model and compile 
	return model

model = KerasClassifier(build_fn=create_model)

#With few sk_params 
def create_model():
	##Create Sequential Model and compile 
	return model

model = KerasClassifier(build_fn=create_model, epochs=10)

#With Build_Params 
def create_model(dropout_rate=0.0):
	#Create Sequential Model and compile 
	return model

model = KerasClassifier(build_fn=create_model, dropout_rate=0.2)




##Keras with sklearn- Example - mnist_sklearn_wrapper.py 
'''Example of how to use sklearn wrapper

Builds simple CNN models on MNIST and uses sklearn's GridSearchCV to find best model
'''

from __future__ import print_function

import keras
from keras.datasets import mnist
from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation, Flatten
from keras.layers import Conv2D, MaxPooling2D
from keras.wrappers.scikit_learn import KerasClassifier
from keras import backend as K
from sklearn.grid_search import GridSearchCV


num_classes = 10

# input image dimensions
img_rows, img_cols = 28, 28

# load training data and do basic data normalization
(x_train, y_train), (x_test, y_test) = mnist.load_data()

if K.image_data_format() == 'channels_first':
    x_train = x_train.reshape(x_train.shape[0], 1, img_rows, img_cols)
    x_test = x_test.reshape(x_test.shape[0], 1, img_rows, img_cols)
    input_shape = (1, img_rows, img_cols)
else:
    x_train = x_train.reshape(x_train.shape[0], img_rows, img_cols, 1)
    x_test = x_test.reshape(x_test.shape[0], img_rows, img_cols, 1)
    input_shape = (img_rows, img_cols, 1)

x_train = x_train.astype('float32')
x_test = x_test.astype('float32')
x_train /= 255
x_test /= 255

# convert class vectors to binary class matrices
y_train = keras.utils.to_categorical(y_train, num_classes)
y_test = keras.utils.to_categorical(y_test, num_classes)

#Build Params are dense_layer_sizes, filters, kernel_size, pool_size, can be used with GridSearchCV
def make_model(dense_layer_sizes, filters, kernel_size, pool_size):
    '''Creates model comprised of 2 convolutional layers followed by dense layers
    dense_layer_sizes: List of layer sizes.
        This list has one number for each layer
    filters: Number of convolutional filters in each convolutional layer
    kernel_size: Convolutional kernel size
    pool_size: Size of pooling area for max pooling
    '''

    model = Sequential()
    model.add(Conv2D(filters, kernel_size,
                     padding='valid',
                     input_shape=input_shape))
    model.add(Activation('relu'))
    model.add(Conv2D(filters, kernel_size))
    model.add(Activation('relu'))
    model.add(MaxPooling2D(pool_size=pool_size))
    model.add(Dropout(0.25))

    model.add(Flatten())
    for layer_size in dense_layer_sizes:
        model.add(Dense(layer_size))
    model.add(Activation('relu'))
    model.add(Dropout(0.5))
    model.add(Dense(num_classes))
    model.add(Activation('softmax'))

    model.compile(loss='categorical_crossentropy',
                  optimizer='adadelta',
                  metrics=['accuracy'])

    return model

dense_size_candidates = [[32], [64], [32, 32], [64, 64]]
my_classifier = KerasClassifier(make_model, batch_size=32)
validator = GridSearchCV(my_classifier,
                         param_grid={'dense_layer_sizes': dense_size_candidates,  #Build Params
                                     # epochs is avail for tuning even when not
                                     # an argument to model building function
                                     'epochs': [3, 6],  # Fitting params 
                                     'filters': [8],  #Build Params
                                     'kernel_size': [3], #Build Params
                                     'pool_size': [2]}, #Build Params
                         scoring='neg_log_loss',
                         n_jobs=1)
validator.fit(x_train, y_train)

print('The parameters of the best model are: ')
print(validator.best_params_)

# validator.best_estimator_ returns sklearn-wrapped version of best model.
# validator.best_estimator_.model returns the (unwrapped) keras model
best_model = validator.best_estimator_.model
metric_names = best_model.metrics_names
metric_values = best_model.evaluate(x_test, y_test)
for metric, value in zip(metric_names, metric_values):
    print(metric, ': ', value)
    
    
    
##Keras with sklearn- Example - Tune Learning Rate and Momentum and many more 
import numpy
from sklearn.model_selection import GridSearchCV
from keras.models import Sequential
from keras.layers import Dense
from keras.wrappers.scikit_learn import KerasClassifier
from keras.optimizers import SGD

# Function to create model, required for KerasClassifier
#Note only experiemnt with few tunnable paramaters else search time would be exponential 
def create_model(neurons=12,learn_rate=0.01, momentum=0,init_mode='uniform', activation='relu',dropout_rate=0.0, weight_constraint=0):
	# create model
	model = Sequential()
	model.add(Dense(neurons, input_dim=8, activation=activation, kernel_initializer=init_mode))
    #model.add(Dense(12, input_dim=8, kernel_initializer='uniform', activation='linear', kernel_constraint=maxnorm(weight_constraint)))
	model.add(Dropout(dropout_rate))
	model.add(Dense(1, activation='sigmoid',kernel_initializer=init_mode))
	# Compile model
	optimizer = SGD(lr=learn_rate, momentum=momentum)
	model.compile(loss='binary_crossentropy', optimizer=optimizer, metrics=['accuracy'])
	return model
    
# fix random seed for reproducibility
seed = 7
numpy.random.seed(seed)
# load dataset
dataset = numpy.loadtxt("pima-indians-diabetes.txt", delimiter=",")
# split into input (X) and output (Y) variables
X = dataset[:,0:8]
Y = dataset[:,8]
# create model
model = KerasClassifier(build_fn=create_model, epochs=100, batch_size=10, verbose=0)

# define the grid search parameters
learn_rate = [0.001, 0.01, 0.1, 0.2, 0.3]
momentum = [0.0, 0.2, 0.4, 0.6, 0.8, 0.9]
activation = ['softmax', 'softplus', 'softsign', 'relu', 'tanh', 'sigmoid', 'hard_sigmoid', 'linear']
init_mode = ['uniform', 'lecun_uniform', 'normal', 'zero', 'glorot_normal', 'glorot_uniform', 'he_normal', 'he_uniform']
weight_constraint = [1, 2, 3, 4, 5]
dropout_rate = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
neurons = [1, 5, 10, 15, 20, 25, 30]


param_grid = dict(neurons=neurons,learn_rate=learn_rate, momentum=momentum,init_mode=init_mode, activation=activation,dropout_rate=dropout_rate, weight_constraint=weight_constraint)
grid = GridSearchCV(estimator=model, param_grid=param_grid, n_jobs=-1)
grid_result = grid.fit(X, Y)

# summarize results
print("Best: %f using %s" % (grid_result.best_score_, grid_result.best_params_))
means = grid_result.cv_results_['mean_test_score']
stds = grid_result.cv_results_['std_test_score']
params = grid_result.cv_results_['params']
for mean, stdev, param in zip(means, stds, params):
    print("%f (%f) with: %r" % (mean, stdev, param))








###+++Keras - Example - Handwritten digits recognitions with CNN - mnist.py 
'''Trains a simple convnet on the MNIST dataset.

Gets to 99.25% test accuracy after 12 epochs
(there is still a lot of margin for parameter tuning).
16 seconds per epoch on a GRID K520 GPU.

MNIST database of handwritten digits
    Dataset of 60,000 28x28 grayscale images of the 10 digits, 
    along with a test set of 10,000 images.
    Returns:
        2 tuples:
            x_train, x_test: uint8 array of grayscale image data with shape (num_samples, 28, 28).
            y_train, y_test: uint8 array of digit labels (integers in range 0-9) with shape (num_samples,).
    Arguments:
        path: if you do not have the index file locally (at '~/.keras/datasets/' + path), it will be downloaded to this location.
    #Usage:
    from keras.datasets import mnist
    (x_train, y_train), (x_test, y_test) = mnist.load_data()
'''

from __future__ import print_function
import keras
from keras.datasets import mnist
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten
from keras.layers import Conv2D, MaxPooling2D
from keras import backend as K

batch_size = 128
num_classes = 10
epochs = 12

# input image dimensions
img_rows, img_cols = 28, 28

# the data, shuffled and split between train and test sets
(x_train, y_train), (x_test, y_test) = mnist.load_data()

if K.image_data_format() == 'channels_first':
    x_train = x_train.reshape(x_train.shape[0], 1, img_rows, img_cols)
    x_test = x_test.reshape(x_test.shape[0], 1, img_rows, img_cols)
    input_shape = (1, img_rows, img_cols)
else:
    x_train = x_train.reshape(x_train.shape[0], img_rows, img_cols, 1)
    x_test = x_test.reshape(x_test.shape[0], img_rows, img_cols, 1)
    input_shape = (img_rows, img_cols, 1)

x_train = x_train.astype('float32')
x_test = x_test.astype('float32')
x_train /= 255
x_test /= 255
print('x_train shape:', x_train.shape)
print(x_train.shape[0], 'train samples')
print(x_test.shape[0], 'test samples')

# convert class vectors to binary class matrices
y_train = keras.utils.to_categorical(y_train, num_classes)
y_test = keras.utils.to_categorical(y_test, num_classes)

model = Sequential()
model.add(Conv2D(32, kernel_size=(3, 3),
                 activation='relu',
                 input_shape=input_shape))
model.add(Conv2D(64, (3, 3), activation='relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.25))
model.add(Flatten())
model.add(Dense(128, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(num_classes, activation='softmax'))

model.compile(loss=keras.losses.categorical_crossentropy,
              optimizer=keras.optimizers.Adadelta(),
              metrics=['accuracy'])

model.fit(x_train, y_train,
          batch_size=batch_size,
          epochs=epochs,
          verbose=1,
          validation_data=(x_test, y_test))
score = model.evaluate(x_test, y_test, verbose=0)
print('Test loss:', score[0])
print('Test accuracy:', score[1])



###+++Keras - Example - Handwritten digits recognitions with MLP  - mnist_mlp.py 
'''Trains a simple deep NN on the MNIST dataset.

Gets to 98.40% test accuracy after 20 epochs
(there is *a lot* of margin for parameter tuning).
2 seconds per epoch on a K520 GPU.
'''

from __future__ import print_function

import keras
from keras.datasets import mnist
from keras.models import Sequential
from keras.layers import Dense, Dropout
from keras.optimizers import RMSprop

batch_size = 128
num_classes = 10
epochs = 20

# the data, shuffled and split between train and test sets
(x_train, y_train), (x_test, y_test) = mnist.load_data()

x_train = x_train.reshape(60000, 784)
x_test = x_test.reshape(10000, 784)
x_train = x_train.astype('float32')
x_test = x_test.astype('float32')
x_train /= 255
x_test /= 255
print(x_train.shape[0], 'train samples')
print(x_test.shape[0], 'test samples')

# convert class vectors to binary class matrices
y_train = keras.utils.to_categorical(y_train, num_classes)
y_test = keras.utils.to_categorical(y_test, num_classes)

model = Sequential()
model.add(Dense(512, activation='relu', input_shape=(784,)))
model.add(Dropout(0.2))
model.add(Dense(512, activation='relu'))
model.add(Dropout(0.2))
model.add(Dense(num_classes, activation='softmax'))

model.summary()

model.compile(loss='categorical_crossentropy',
              optimizer=RMSprop(),
              metrics=['accuracy'])

history = model.fit(x_train, y_train,
                    batch_size=batch_size,
                    epochs=epochs,
                    verbose=1,
                    validation_data=(x_test, y_test))
score = model.evaluate(x_test, y_test, verbose=0)
print('Test loss:', score[0])
print('Test accuracy:', score[1])




    
    
###+++Keras - Example - CIFAR10 small images dataset recognitions with CNN - cifar10_cnn.py 
'''Train a simple deep CNN on the CIFAR10 small images dataset.

It gets to 75% validation accuracy in 25 epochs, and 79% after 50 epochs.
(it's still underfitting at that point, though).

CIFAR10 small image classification
    Dataset of 50,000 32x32 color training images, 
    labeled over 10 categories, and 10,000 test images.
    Returns:
    2 tuples:
        x_train, x_test: uint8 array of RGB image data with shape (num_samples, 3, 32, 32).
        y_train, y_test: uint8 array of category labels (integers in range 0-9) with shape (num_samples,).
    #Usage:
    from keras.datasets import cifar10
    (x_train, y_train), (x_test, y_test) = cifar10.load_data()  
'''

from __future__ import print_function
import keras
from keras.datasets import cifar10
from keras.preprocessing.image import ImageDataGenerator
from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation, Flatten
from keras.layers import Conv2D, MaxPooling2D
import os

batch_size = 32
num_classes = 10
epochs = 100
data_augmentation = True
num_predictions = 20
save_dir = os.path.join(os.getcwd(), 'saved_models')
model_name = 'keras_cifar10_trained_model.h5'

# The data, shuffled and split between train and test sets:
(x_train, y_train), (x_test, y_test) = cifar10.load_data()
print('x_train shape:', x_train.shape)
print(x_train.shape[0], 'train samples')
print(x_test.shape[0], 'test samples')

# Convert class vectors to binary class matrices.
y_train = keras.utils.to_categorical(y_train, num_classes)
y_test = keras.utils.to_categorical(y_test, num_classes)

model = Sequential()
model.add(Conv2D(32, (3, 3), padding='same',input_shape=x_train.shape[1:]))
model.add(Activation('relu'))
model.add(Conv2D(32, (3, 3)))
model.add(Activation('relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.25))

model.add(Conv2D(64, (3, 3), padding='same'))
model.add(Activation('relu'))
model.add(Conv2D(64, (3, 3)))
model.add(Activation('relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.25))

model.add(Flatten())
model.add(Dense(512))
model.add(Activation('relu'))
model.add(Dropout(0.5))
model.add(Dense(num_classes))
model.add(Activation('softmax'))

# initiate RMSprop optimizer
opt = keras.optimizers.rmsprop(lr=0.0001, decay=1e-6)

# Let's train the model using RMSprop
model.compile(loss='categorical_crossentropy',
              optimizer=opt,
              metrics=['accuracy'])

x_train = x_train.astype('float32')
x_test = x_test.astype('float32')
x_train /= 255
x_test /= 255

if not data_augmentation:
    print('Not using data augmentation.')
    model.fit(x_train, y_train,
              batch_size=batch_size,
              epochs=epochs,
              validation_data=(x_test, y_test),
              shuffle=True)
else:
    print('Using real-time data augmentation.')
    # This will do preprocessing and realtime data augmentation:
    datagen = ImageDataGenerator(
        featurewise_center=False,  # set input mean to 0 over the dataset
        samplewise_center=False,  # set each sample mean to 0
        featurewise_std_normalization=False,  # divide inputs by std of the dataset
        samplewise_std_normalization=False,  # divide each input by its std
        zca_whitening=False,  # apply ZCA whitening
        rotation_range=0,  # randomly rotate images in the range (degrees, 0 to 180)
        width_shift_range=0.1,  # randomly shift images horizontally (fraction of total width)
        height_shift_range=0.1,  # randomly shift images vertically (fraction of total height)
        horizontal_flip=True,  # randomly flip images
        vertical_flip=False)  # randomly flip images

    # Compute quantities required for feature-wise normalization
    # (std, mean, and principal components if ZCA whitening is applied).
    datagen.fit(x_train)

    # Fit the model on the batches generated by datagen.flow().
    model.fit_generator(datagen.flow(x_train, y_train,
                                     batch_size=batch_size),
                        epochs=epochs,
                        validation_data=(x_test, y_test),
                        workers=4)

# Save model and weights
if not os.path.isdir(save_dir):
    os.makedirs(save_dir)
model_path = os.path.join(save_dir, model_name)
model.save(model_path)
print('Saved trained model at %s ' % model_path)

# Score trained model.
scores = model.evaluate(x_test, y_test, verbose=1)
print('Test loss:', scores[0])
print('Test accuracy:', scores[1])



###+++Keras - Example -XOR Logic using MLP & Backpropagation
import numpy as np
from keras.models import Sequential
from keras.layers.core import Activation, Dense

training_data = np.array([[0,0],[0,1],[1,0],[1,1]], "float32")
target_data = np.array([[0],[1],[1],[0]], "float32")

model = Sequential()
model.add(Dense(32, input_dim=2, activation='relu'))
model.add(Dense(1, activation='sigmoid'))

model.compile(loss='mean_squared_error', optimizer='adam', metrics=['binary_accuracy'])

model.fit(training_data, target_data, nb_epoch=1000, verbose=2)

print model.predict(training_data)


###+++Keras - Example - iris Classifications 
import numpy
import pandas
from keras.models import Sequential
from keras.layers import Dense
from keras.wrappers.scikit_learn import KerasClassifier
import keras.utils 
from sklearn.cross_validation import cross_val_score
from sklearn.cross_validation import KFold
from sklearn.preprocessing import LabelEncoder
from sklearn.pipeline import Pipeline

numpy.random.seed(0)

dataframe   = pandas.read_csv("iris.csv", header=None)
dataset     = dataframe.values

X = dataset[:,0:4].astype(float)
Y = dataset[:,4]

# Preprocess the labels

# LabelEncoder from scikit-learn turns each text label
# (e.g "Iris-setosa", "Iris-versicolor") into a vector
# In this case, each of the three labels are just assigned
# a number from 0-2.
encoder = LabelEncoder()
encoder.fit(Y)
encoded_Y = encoder.transform(Y)

# to_categorical converts the numbered labels into a one-hot vector
dummy_y = keras.utils.to_categorical(encoded_Y)

def baseline_model():
    model = Sequential()
    model.add(Dense(4, input_dim=4, init='normal', activation='relu'))
    model.add(Dense(3, init='normal', activation='sigmoid'))
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model

estimator = KerasClassifier(build_fn=baseline_model, nb_epoch=200, batch_size=5, verbose=0)

kfold = KFold(n=len(X), n_folds=10, shuffle=True, random_state=0)
results = cross_val_score(estimator, X, dummy_y, cv=kfold)
print("Baseline: %.2f%% (%.2f%%)" % (results.mean()*100, results.std()*100))





###+++Keras - Example -Boston housing price regression 
'''
Target : The last column MEDV is a median value of owner-occupied homes in $1000
Features:
CRIM per capita crime rate by town
ZN proportion of residential land zoned for lots over 25,000 sq.ft.
INDUS proportion of non-retail business acres per town
CHAS Charles River dummy variable (= 1 if tract bounds river; 0 otherwise)
NOX nitric oxides concentration (parts per 10 million)
RM average number of rooms per dwelling
AGE proportion of owner-occupied units built prior to 1940
DIS weighted distances to five Boston employment centres
RAD index of accessibility to radial highways
TAX full-value property-tax rate per $10,000
PTRATIO pupil-teacher ratio by town
B 1000(Bk - 0.63)^2 where Bk is the proportion of blacks by town
LSTAT % lower status of the population
'''
import pandas as pd
import numpy as np

# Read dataset into X and Y
df = pd.read_csv('data/housing.csv', delim_whitespace=True, header=None)
dataset = df.values

X = dataset[:, 0:13]
Y = dataset[:, 13]

#print "X: ", X
#print "Y: ", Y


# Define the neural network
from keras.models import Sequential
from keras.layers import Dense

def build_nn():
    model = Sequential()
    model.add(Dense(20, input_dim=13, init='normal', activation='relu'))
    # No activation needed in output layer (because regression)
    model.add(Dense(1, init='normal'))

    # Compile Model
    model.compile(loss='mean_squared_error', optimizer='adam')
    return model


# Evaluate model (kFold cross validation)
from keras.wrappers.scikit_learn import KerasRegressor

# sklearn imports:
from sklearn.cross_validation import cross_val_score, KFold
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

# Before feeding the i/p into neural-network, standardise the dataset because all input variables vary in their scales
estimators = []
estimators.append(('standardise', StandardScaler()))
estimators.append(('multiLayerPerceptron', KerasRegressor(build_fn=build_nn, nb_epoch=100, batch_size=5, verbose=0)))

pipeline = Pipeline(estimators)

kfold = KFold(n=len(X), n_folds=10)
results = cross_val_score(pipeline, X, Y, cv=kfold)

print "Mean: ", results.mean()
print "StdDev: ", results.std()




###+++Keras - Example - Diabetes Data Predictive Analysis using DNN
from keras.models import Sequential
from keras.layers import Dense
import numpy


numpy.random.seed(10)


dataset = numpy.loadtxt("pima-indians-diabetes.csv", delimiter=",")


Z = dataset[:,0:8]
Q = dataset[:,8]


model = Sequential()
model.add(Dense(12, input_dim=8, activation='relu'))
model.add(Dense(8, activation='relu'))
model.add(Dense(1, activation='sigmoid'))


model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])


model.fit(Z, Q, epochs=150, batch_size=10)


predictions = model.predict(Z)

rounded = [round(x[0]) for x in predictions]
print(rounded)


scores = model.evaluate(Z, Q)
print("\n%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))



  
        
   




