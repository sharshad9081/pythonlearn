.. _svm_examples:

Support Vector Machines
-----------------------

Examples concerning the :mod:`sklearn.svm` module.
