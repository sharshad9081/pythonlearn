###Note update joblib such that if __name__=='__main__'
#is not required to wrapping up 
pip install --upgrade --no-deps  --force-reinstall joblib

###All import 
from sklearn.pipeline import * 
#from sklearn.grid_search import * 
from sklearn.naive_bayes import * 
from sklearn.cluster import *  
from sklearn.covariance import *  
from sklearn.cross_decomposition import *  
from sklearn.datasets import *  
from sklearn.decomposition import *  
from sklearn.ensemble import *  
from sklearn.feature_extraction import *  
from sklearn.feature_extraction.text import *  
from sklearn.feature_selection import *  
from sklearn.gaussian_process import *  
from sklearn.linear_model import *  
from sklearn.manifold import *  
from sklearn.metrics import *  
from sklearn.mixture import *  
from sklearn.model_selection import *  
from sklearn.neighbors import *  
from sklearn.neural_network import *  
from sklearn.preprocessing import *  
from sklearn.svm import *  
from sklearn.tree import *  

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt

#if required 
import statsmodels.api as sm           #General imports 
import statsmodels.formula.api as smf  #for formula support in various regression 


from keras.models import *
from keras.layers import *
from keras.wrappers.scikit_learn import *
import keras.utils 
from keras.metrics import *
from keras.initializers import *
from keras.regularizers import * 


###train_test_split and DummyClassifier/DummyRegressor

##Train/test split and comparing with DummyClassifier/DummyRegressor 
#Also, main steps - fit, score and predict 
#also how to load dataset available with pandas 

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
iris = load_iris()
dir(iris)
iris.feature_names
X, y = iris.data, iris.target
#make it binary class
y[y != 1] = -1
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)

#compare the accuracy of SVC and most_frequent:
from sklearn.dummy import DummyClassifier
from sklearn.svm import SVC
clf = SVC(kernel='linear', C=1).fit(X_train, y_train)
clf.get_params() #check all parameters 
>>> clf.score(X_test, y_test)  #Returns the mean accuracy on the given test data and labels.
0.63...

#with dummy 
clf = DummyClassifier(strategy='most_frequent',random_state=0)
clf.fit(X_train, y_train)
>>> clf.score(X_test, y_test)  
0.57...




### Let's understand what is SVM 



from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split

iris = load_iris()
X, y = iris.data, iris.target
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)

#compare the accuracy of SVC and most_frequent:
from sklearn.svm import SVC
clf = SVC(kernel='linear', C=1).fit(X_train, y_train)
#check all hyper params 
clf.get_params()
clf.predict(X_train)  #takes 2D, predicts for each row/feature 
'classes_', 'coef_' 'support_', 'support_vectors_'
clf.classes_
clf.coef_       #only for linear problem
clf.support_    #SupportVectorIndices — Vector of indices that specify the rows in the training data(X_train), that were selected as support vectors 
clf.support_vectors_  #are subset of features (rows of X_train) which would be used for decision boundary
#X.tolist().index([6.8, 3. , 5.5, 2.1])  # 112 
clf.n_support_ # get number of support vectors for each class


>>> clf.score(X_test, y_test)  #Returns the mean accuracy on the given test data and labels.
0.63...
#OR 
from sklearn.metrics import f1_score
f1_score(y_test, clf.predict(X_test), average='macro')



#https://scikit-learn.org/stable/modules/svm.html#kernel-functions
#polynomial: d is specified by keyword degree, r by coef0(is a constant)
#Radial Basis Function, rbf: gamma is specified by keyword gamma, must be greater than 0.
#sigmoid r is specified by coef0(is a constant)

#C (default=1)
#A low C(<1) makes the decision surface smooth, (use for noisy data)
#while a high C (> 1)(eg 1000) aims at classifying all training examples correctly. 
#LinearSVC and LinearSVR are less sensitive to C when it becomes large, 
#and prediction results stop improving after a certain threshold. 
#Meanwhile, larger C values will take more time to train,


#gamma defines how much influence a single training example has. 
#The larger gamma is, the closer other examples must be to be affected.
#< 1, default is 'auto' = 1/n_feature, can use 'scale'

#nu [0,1)The parameter is an upper bound on the fraction of training errors 
#and a lower bound of the fraction of support vectors.


>>> clf = SVC(kernel='rbf', C=1).fit(X_train, y_train)
>>> clf.score(X_test, y_test)  
0.97...

#See and Execute plot_iris_svc.py




###HandsOn 
#Use DummyRegressor with boston data and SVR with varying kernel 
from sklearn.datasets import load_boston
from sklearn.model_selection  import train_test_split
boston = load_boston()
X, y = boston.data, boston.target
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)

#compare the accuracy of SVC and most_frequent:
from sklearn.dummy import DummyRegressor
from sklearn.svm import SVR
clf = SVR(kernel='linear', C=1).fit(X_train, y_train)
>>> clf.score(X_test, y_test)  # R^2 of the prediction.
0.56...
clf = DummyRegressor(strategy='mean',random_state=0)
clf.fit(X_train, y_train) 
>>> clf.score(X_test, y_test)   # R^2 of the prediction., could be negative as model could be arbitrarily worse
-0.0100

#Check and execute plot_svm_regression.py


###PCA
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA

iris = pd.read_csv('toBeShared/data/iris.csv')
X, y = iris.iloc[:, 0:4], iris.iloc[:,4]
pca = PCA(n_components=2)
pca.fit(X)
>>> print(pca.explained_variance_ratio_)  
array([0.92461621, 0.05301557])
>>> print(pca.singular_values_)  
[6.30061... 0.54980...]

trans = pca.transform(X)
pca.inverse_transform(trans)


###Describe Pipeline  

from sklearn.pipeline import Pipeline
from sklearn.svm import SVC
from sklearn.decomposition import PCA
from sklearn.datasets import load_digits

digits = load_digits()
pca1 = PCA()
svm1 = SVC(gamma='scale')
pipe = Pipeline([('reduce_dim', pca1), ('clf', svm1)])
>>> pipe.fit(digits.data, digits.target)
Pipeline(memory=None,
         steps=[('reduce_dim', PCA(...)), ('clf', SVC(...))])
# The pca instance can be inspected directly
>>> print(pca1.components_) 
    [[-1.77484909e-19  ... 4.07058917e-18]]

>>> pipe 
Pipeline(memory=None,
         steps=[('reduce_dim', PCA(copy=True,...)),
                ('clf', SVC(C=1.0,...))])
                
#The estimators of a pipeline are stored as a list in the steps attribute:
>>> pipe.steps[0]
('reduce_dim', PCA(copy=True, iterated_power='auto', n_components=None, random_state=None,
  svd_solver='auto', tol=0.0, whiten=False))

#and as a dict in named_steps:
>>> pipe.named_steps['reduce_dim']
PCA(copy=True, iterated_power='auto', n_components=None, random_state=None,
  svd_solver='auto', tol=0.0, whiten=False)

#Parameters of the estimators , <estimator>__<parameter> 
>>> pipe.set_params(clf__C=10) 
Pipeline(memory=None,
         steps=[('reduce_dim', PCA(copy=True, iterated_power='auto',...)),
                ('clf', SVC(C=10, cache_size=200, class_weight=None,...))])

#Attributes of named_steps map to keys
pipe.named_steps.reduce_dim is pipe.named_steps['reduce_dim']

#for Grid search 
from sklearn.model_selection import GridSearchCV
param_grid = dict(reduce_dim__n_components=[2, 5, 10], clf__C=[0.1, 10, 100])
grid_search = GridSearchCV(pipe, param_grid=param_grid)

#Individual steps may also be replaced as parameters, 
#and non-final steps may be ignored by setting them to None:
from sklearn.linear_model import LogisticRegression
param_grid = dict(reduce_dim=[None, PCA(5), PCA(10)],
              clf=[SVC(), LogisticRegression()], clf__C=[0.1, 10, 100])
grid_search = GridSearchCV(pipe, param_grid=param_grid)






#Fitting transformers may be computationally expensive. 
#With its memory parameter set, 
#Pipeline will cache each transformer after calling fit.

#Warning - Side effect of caching transformers 
#with Cache enabled, original instances of estimators can not be accessed 

from tempfile import mkdtemp
from shutil import rmtree
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from sklearn.pipeline import Pipeline
estimators = [('reduce_dim', PCA()), ('clf', SVC())]
cachedir = mkdtemp()
pipe = Pipeline(estimators, memory=cachedir)
>>> pipe 
Pipeline(...,
         steps=[('reduce_dim', PCA(copy=True,...)),
                ('clf', SVC(C=1.0,...))])
# Clear the cache directory when you don't need it anymore
rmtree(cachedir)



#FeatureUnion combines several transformer objects into a new transformer 
#that combines their output
#FeatureUnion and Pipeline can be combined to create complex models.

from sklearn.pipeline import FeatureUnion
from sklearn.decomposition import PCA
from sklearn.decomposition import KernelPCA
estimators = [('linear_pca', PCA()), ('kernel_pca', KernelPCA())]
combined = FeatureUnion(estimators)
>>> combined 
FeatureUnion(n_jobs=None,
             transformer_list=[('linear_pca', PCA(copy=True,...)),
                               ('kernel_pca', KernelPCA(alpha=1.0,...))],
             transformer_weights=None)

#individual steps may be replaced using set_params, 
#and ignored by setting to 'drop':
>>> combined.set_params(kernel_pca='drop')
FeatureUnion(n_jobs=None,
             transformer_list=[('linear_pca', PCA(copy=True,...)),
                               ('kernel_pca', 'drop')],
             transformer_weights=None)


pipe = Pipeline([('reduce_dim', combined), ('clf', SVC())])

pipe.steps[0]
pipe.named_steps['reduce_dim']
pipe.get_params()
pipe.get_params().keys()
pipe.set_params(clf__C=10) 
pipe.set_params(reduce_dim__kernel_pca__kernel='rbf')







###Extraction, selection and transformation 


iris = pd.read_csv('toBeShared/data/iris.csv')
#For compatbility reasons, to work with pandas , convert pandas DF to ndArray 
#Note latest version of sklearn can directly take pandas(coerce with np.array())
#but , if pandas has all numeric, then OK, else, convert to ndArray as object- which is NotOK
#can convert to ndarray.astype(floaf64) etc 
dataset_array = iris.values[:, 0:4].astype(float64)
dataset_array.dtype
#or 
np.array(iris.iloc[:, 0:4])
#or 
mat = iris.iloc[:, 0:4].as_matrix()

#How ever sklearn preprocessing works on full array, not individual features 
#Note .fit(X), then .transform(X), .inverse_transform(transformed)
#each column of X is one feature 
y = string or numeric categorical 
    Use LabelEncoder(takes 1D/vector ie (n,)) to convert to integer 0...No_Of_classes,
    Note, one hot encoding (LabelBinarizer()) is not required for y at all
    (but LabelBinarizer() exists for converting binary classification to multi-class, 
    which done by sklearn by default)
X = string categorical , must be one hot encoded 
        Use LabelEncoder(1D/vector) , convert to (n,1) 
        ( reshape(-1,1)  or reshape(n,1) or [:, np.newaxis]
        and then use OneHotEncoder(takes 2D)
    numeric categorical - must be one hot encoded 
        Use OneHotEncoder(takes 2D)

All other values can be directly used
But X may require some below (all, .fit() takes 2D, first four takes 1D as well), all has default parameters
    sklearn.preprocessing.StandardScaler for mean=0, unit std , feature/columnwise 
        Check with .mean(axis=0), .std(axis=0)
    MinMaxScaler for [min,max] or MaxAbsScaler for [0,1], feature/columnwise 
    RobustScaler  for data with outlier , feature/columnwise
    If feature independence is required, 
        Put it with sklearn.decomposition.PCA(whiten=True) #ie n_components=None
    QuantileTransformer puts all features into the same, known range or distribution.
    PowerTransformer to Normal distribution featurewise 
    Normalizer  for each samples to have unit norm (row wise)
    Binarizer(threshold=..)thresholding numerical features to get boolean values
    PolynomialFeatures(n) to add a + b + ... + a*a +... + a*b + b*c+... (including iteraction term) 
        interaction_only=True, only interaction term 
    SimpleImputer(missing_values=np.nan, strategy='mean') for imputing missing value   

Feature Selection , fit(X,y) 
    SelectKBest removes all but the highest scoring features
    SelectFromModel is a meta-transformer that can be used along with any estimator that has a coef_ or feature_importances_ attribute after fitting.
    
Feature Extraction from text 
    CountVectorizer implements both tokenization and occurrence counting in a single class:
    TfidfVectorizer that combines all the options of CountVectorizer and TfidfTransformer in a single model:
    
##LabelEncoder with OneHotEncoder for handling categorical string in X 
lenc = LabelEncoder()
oH = OneHotEncoder()

iris = pd.read_csv('toBeShared/data/iris.csv')
lenc = lenc.fit(iris.iloc[0:, 4])
catName = lenc.transform(iris.iloc[0:, 4])
oH.fit(catName[:, np.newaxis]).transform(catName[:, np.newaxis])
oH = oH.fit(catName[:, np.newaxis])
name = oH.transform(catName[:, np.newaxis]).toarray()  #ndArray 
iris.columns 
#colum wise stacking, axis=0=append=row wise stacking 
iris_final = pd.concat([iris.iloc[:,0:4], pd.DataFrame(name)], axis=1)
iris_final.columns = iris.columns.tolist()[:-1] + ["Name_"+str(i) for i in range(3)]
iris_final.head()
#inverse 
oH.inverse_transform(name) #'OneHotEncoder' object has no attribute 'inverse_transform'

#with pipeline, possible ?
X, y = iris.iloc[:, 0:4], iris.iloc[:,4]
pipe = Pipeline([('first', LabelEncoder()),('second', OneHotEncoder())])
pipe = pipe.fit(y) #ERROR 
#hence use LabelBinarizer
lenc = LabelBinarizer().fit(y)
name = lenc.transform(y)
iris_final = pd.concat([iris.iloc[:,0:4], pd.DataFrame(name)], axis=1)
lenc.inverse_transform(name)
>>> lenc.inverse_transform(name).shape
(150,)




##QuantileTransformer : puts all features into the same, known range or distribution
X, y = iris.iloc[:, 0:4], iris.iloc[:,4]
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0) #DF
quantile_transformer = QuantileTransformer(random_state=0)
X_train_trans = quantile_transformer.fit_transform(X_train) #ndArray
X_test_trans = quantile_transformer.transform(X_test)#ndArray
>>> np.percentile(X_train.values[:, 0], [0, 25, 50, 75, 100]) 
array([ 4.3,  5.1,  5.8,  6.5,  7.9])

#Mapping to a Gaussian distribution
pt = PowerTransformer(method='box-cox', standardize=False)
>>> X_lognormal = np.random.RandomState(616).lognormal(size=(3, 3))
>>> X_lognormal                                         
array([[1.28..., 1.18..., 0.84...],
       [0.94..., 1.60..., 0.38...],
       [1.35..., 0.21..., 1.09...]])
>>> pt.fit_transform(X_lognormal)          #this is normal           
array([[ 0.49...,  0.17..., -0.15...],
       [-0.05...,  0.58..., -0.57...],
       [ 0.69..., -0.84...,  0.10...]])
       


#StandardScalar 
X, y = iris.iloc[:, 0:4], iris.iloc[:,4]

scaler = StandardScaler().fit(X)
scaler.transform(X)   

>>> scaler
StandardScaler(copy=True, with_mean=True, with_std=True)

>>> scaler.mean_                                      
array([1. ..., 0. ..., 0.33...])

>>> scaler.scale_                                       
array([0.81..., 0.81..., 1.24...])
scaler.inverse_transform(scaler.transform(X) )

       
#Normalizer- each sample unit norm 
normalizer = Normalizer().fit(X)  
>>> normalizer
Normalizer(copy=True, norm='l2')
normalizer.transform(X)

#Selecting Best k=2 
X.shape 
X_new = SelectKBest(chi2, k=2).fit_transform(X, y)
>>> X_new.shape
(150, 2)

#with Pipeline and Selection based on Model (where .coef_ or .feature_importances_ exists)
#Feature selection as part of a pipeline
X, y = iris.iloc[:, 0:4], iris.iloc[:,4]
y = LabelEncoder().fit_transform(y)
X_train, X_test, y_train, y_test = train_test_split(X, y)
clf = Pipeline([
  ('feature_selection', SelectFromModel(LinearSVC(penalty="l2"))), #l1 is not supported with dual=True
  ('classification', RandomForestClassifier())
])
clf.fit(X_train, y_train)
clf.score(X_train, y_train)
clf.score(X_test, y_test)
#repeat above code few times, you get varying bias and variance 
#so how can you estimate these estimates? Coming back later on this, but 
#returns holds out score
cross_val_score(clf, X,y,cv=5) #accuracy 
cross_val_score(clf, X,y,cv=5, scoring='f1_macro')
#for multiple metrics 
scoring = ['precision_macro', 'recall_macro']
cross_validate(clf, X,y, scoring=scoring,cv=5, return_train_score=False)

#Even prediction 
y_pred = cross_val_predict(clf, X, y, cv=3)
>>> y_pred.shape
(150,)


#Extraction from Text , CountVectorizer - tokenization and count frequency 
#This model has many parameters, however the default values are quite reasonable 

vectorizer = CountVectorizer()
>>> vectorizer                     
CountVectorizer(analyzer=...'word', binary=False, decode_error=...'strict',
        dtype=<... 'numpy.int64'>, encoding=...'utf-8', input=...'content',
        lowercase=True, max_df=1.0, max_features=None, min_df=1,
        ngram_range=(1, 1), preprocessor=None, stop_words=None,
        strip_accents=None, token_pattern=...'(?u)\\b\\w\\w+\\b',
        tokenizer=None, vocabulary=None)

#corpus is list of Sentences or line 
import glob
#list of list 
lst = [open(name, "rt").readlines() for name in glob.glob("tobeShared/data/corpus/*")]
corpus = [ line.strip() for inner in lst for line in inner]

>>> X = vectorizer.fit_transform(corpus)
>>> X                              
<4x9 sparse matrix of type '<... 'numpy.int64'>'
    with 19 stored elements in Compressed Sparse ... format>

vectorizer.get_feature_names()#see the feature name 
X.toarray()           

#OR to Tf-idf = Term frquency * inverse document frequency      
vectorizer = TfidfVectorizer()
vectorizer.fit_transform(corpus)
vectorizer.get_feature_names()

#Using pipeline, FetureUnion,...
X, y = iris.iloc[:, 0:4], iris.iloc[:,4]
y = LabelEncoder().fit_transform(y)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size= .10) #10%

# This dataset is way too high-dimensional. Better do PCA:
pca = PCA(n_components=2)

# Maybe some original features where good, too?
selection = SelectKBest(k=1)

# Build estimator from PCA and Univariate selection:
combined_features = FeatureUnion([("pca", pca), ("univ_select", selection)])

svm = SVC(kernel="linear")
pipeline = Pipeline([("features", combined_features), ("svm", svm)])

param_grid = dict(features__pca__n_components=[1, 2, 3],
                  features__univ_select__k=[1, 2],
                  svm__C=[0.1, 1, 10])

grid_search = GridSearchCV(pipeline, param_grid=param_grid, cv=5, verbose=10)
grid_search.fit(X_train, y_train)
final_model = grid_search.best_estimator_
print(final_model)
y_pred = final_model.predict(X_test)
final_model.score(X_train, y_train)
accuracy_score(y_test, y_pred) #y_true, y_pred

#save this and load again
import pickle
s = pickle.dumps(final_model) #or pickle.dump(final_model, open("final","wb"))
clf = pickle.loads(s)         #clf = pickle.load(open("final", "rb"))
accuracy_score(y_test, clf.predict(X_test))





###With sklearn-pandas

from sklearn_pandas import * 

iris = pd.read_csv('toBeShared/data/iris.csv')
X, y = iris.iloc[:, 0:4], iris.iloc[:,4]      

#Name LabelEncoder , All other columns together-PCA and then StandardScaler 
mapper = DataFrameMapper([
     ('Name', LabelEncoder()),
     (['SepalLength', 'SepalWidth', 'PetalLength', 'PetalWidth'], [PCA(3), StandardScaler()] )
 ],  df_out=True) #output is df , else it is ndArray 
out_df = mapper.fit_transform(iris.copy())
mapper.transformed_names_
                      
#Example of LabelBinarizer(one hot encoded) and StandardScaler
#Note LabelBinarizer takes 1D, hence 'Name' without []
#StandardScaler takes 2D, hence ['SepalLength']
mapper = DataFrameMapper([
    ('Name', LabelBinarizer()),  #LabelBinarizer can take 2D , all columns would be independently onehot encoded , use ['pet']
    (['SepalLength'], StandardScaler() ) #rest are not outputed 
    ])
arr = mapper.fit_transform(iris.copy())
mapper.transformed_names_
#OR 
mapper = DataFrameMapper([
    ('Name', LabelBinarizer()),  #LabelBinarizer can take 2D , all columns would be independently onehot encoded , use ['pet']
    ('SepalLength', None ) #direct output
    ], default=StandardScaler()) #all rest standard Scalar 
arr = mapper.fit_transform(iris.copy())
arr[:, 3] #no transformation

#or 
mapper = DataFrameMapper([
    ('Name', LabelBinarizer()),  #LabelBinarizer can take 2D , all columns would be independently onehot encoded , use ['pet']
    ('SepalLength', None ) ] +
    gen_features(
        columns=[['SepalWidth'],['PetalLength'], ['PetalWidth']], 
        # classes= [StandardScaler]
        classes=[{'class': StandardScaler, 'with_std': True}] #can pass changed arg
    )) #all rest standard Scalar 
arr = mapper.fit_transform(iris.copy())
arr[:, 3] #no transformation
    
 
###HandsOn Titanic Data processing 
#Let's go through an example from Kaggle, the Titanic dataset. 
#The task here is to predict who will survive on Titanic, 
#based on a subset of whole dataset.
0. Note survived is 'y', rest all are 'X' 
1. Replace nan values of embarked, fare by mode of embarked, fare 
2. Create a transformer with following transformation 
   String categorical - embarked, pclass, sex, Title
                        FamilyID
   Take as it is - fare, parch , sibsp , FamiliySize, AgeOriginallyNaN
                   AgeFilledMedianByTitle   
   Create following columns as 
        Title - get Title portion from name
        LastName  - get last name ftom name 
        FamilySize - total of sibsp and parch + 1 
        FamilyID  - String of "LastName:FamiliySize"
                    If FamiliySize <=2 , then "Small_Family"
        AgeOriginallyNaN - new column where 0 = age is NaN, 1 = age is not NaN 
            Hint: Use .isnull() and convert to int 
        AgeFilledMedianByTitle , median age for that Title 
            Find median age for each title(groupby)
            then merge that with original DF on Title 
            
 

#Solutions 
from sklearn_pandas import *

df_train = pd.read_csv('toBeShared/data/titanic_train.csv', header = 0, index_col = 'ticket')
df_test = pd.read_csv('toBeShared/data/titanic_test.csv', header = 0, index_col = 'ticket')

#axis=0 , means vertical(row) stacking , axis=1, columnwise append 
df = pd.concat([df_train, df_test], keys=["train", "test"])

df.index.get_level_values(0)  #train, test 
df.index.get_level_values(1)  #ticket
df.index.names # [None, 'ticket']
df.index.names = ['type', 'ticket']
df.index.get_level_values('type')
df.index.get_level_values('ticket')
df.columns 
>>> df['sex'].reset_index()
       type              ticket     sex
0     train           A/5 21171    male
1     train            PC 17599  female

#get back 
df.loc['train', :]
df.loc['test', :]
df.loc[:, 'name' : 'sibsp']  #for all index 
df.loc[('train', '113803') , :] #one row 
df.iloc[3:4, :]  #DF 

#df.mode() gives DF of most frequent , take first col 
#replace NaN of 'fare' by mode of that 
df.loc[df['fare'].isnull(), 'fare'] = df['fare'].mode()[0]
#or could be used fillna as well 
df.fillna({'fare': df['fare'].mode()[0], 'embarked': df['embarked'].mode()[0] }, inplace=True)
#or could use replace 
df.replace({'fare':np.nan, 'embarked': np.nan}, {'fare': df['fare'].mode()[0], 'embarked': df['embarked'].mode()[0] }, inplace=True)

#drop cabin 
df.drop(columns='cabin', inplace=True)

#check any more null 
df[df.isnull().any(axis=1)]  #axis=1 is row 
df[df.isnull().any(axis=1)].loc['train',:]


#Setting up 
#Series.apply can take py fn or ufun, py fn- operates on eah element 
#df.apply has to be ufunc , if python func, vectorise with np.vectorize 
df['Title'] = df['name'].apply(lambda c: c[c.index(',') + 2 : c.index('.')])
df['LastName'] = df['name'].apply(lambda n: n[0:n.index(',')])

df['FamilySize'] = df['sibsp'] + df['parch'] + 1

df['FamilyID'] = df['LastName'] + ':' + df['FamilySize'].apply(str) #python fn, so operates on each element 
#if family size is <=2 
df.loc[df['FamilySize'] <= 2, 'FamilyID'] = 'Small_Family'

#convert age to 0 or 1 based on age is NaN or present 
df['AgeOriginallyNaN'] = df['age'].isnull().astype(int)

#for each title, get median age , and rename that column as AgeFilledMedianByTitle
medians_by_title = pd.DataFrame(df.groupby('Title')['age'].median()) \
  .rename(columns = {'age': 'AgeFilledMedianByTitle'}) #index is Title 
  
#Then for each row, fill AgeFilledMedianByTitle column 
#ie merge with df.Title with medians_by_title.index
#that merge would hamper original [train, test] sort order , hence sort_index 
df = df.merge(medians_by_title, left_on = 'Title', right_index = True) \
  .sort_index(level = 0).sort_index(level = 1) #by level 0 and the level=1 
  
#after processing , split 
df_train = df.ix['train']
df_test  = df.ix['test'].drop(columns=['survived'])

#Note Categoricals are embarked, pclass, sex , title, FamilyIDD 


#to create dummy variables out of categorical ones. 
#In Scikit ,algorithms accept only float variables.


transformations = [
                      ('embarked', LabelBinarizer()),
                      ('fare', None),
                      ('parch', None),
                      ('pclass', LabelBinarizer()),
                      ('sex', LabelBinarizer()),
                      ('sibsp', None),                                       
                      ('Title', LabelBinarizer()),
                      ('FamilySize', None),
                      ('FamilyID', LabelBinarizer()),
                      ('AgeOriginallyNaN', None),
                      ('AgeFilledMedianByTitle', None)]

mapper = DataFrameMapper(transformations)

arr = mapper.fit_transform(df_train)


#Create pipeline 
pipeline = Pipeline([('featurize', mapper), ('forest', RandomForestClassifier())])

X = df_train[df_train.columns.drop('survived')]
y = df_train['survived']
model = pipeline.fit(X = X, y = y)
model.score(X, y)
#prediction
prediction = model.predict(df_test)  #their is no truth value 







###KNN 
#The default value, weights = 'uniform', assigns uniform weights to each neighbor. 
#weights = 'distance' assigns weights proportional to the inverse of the distance from the query point.

##Regresion 

# Generate sample data
import numpy as np
import matplotlib.pyplot as plt
from sklearn import neighbors

np.random.seed(0)
X = np.sort(5 * np.random.rand(40, 1), axis=0) #(40, 1)
T = np.linspace(0, 5, 500)[:, np.newaxis] #(500, 1)
y = np.sin(X).ravel() #(40,)

# Add noise to targets
y[::5] += 1 * (0.5 - np.random.rand(8)) #every 5 th point, add some noise, note np.random.rand(8) generates (8,)


# Fit regression model
n_neighbors = 5


knn = neighbors.KNeighborsRegressor(n_neighbors, weights='distance')
y_ = knn.fit(X, y).predict(T)

#plt.subplot(2, 1, i + 1)
plt.scatter(X, y, c='k', label='data')
plt.plot(T, y_, c='g', label='prediction')
plt.axis('tight')
plt.legend()
plt.title("KNeighborsRegressor ")
#Automatically adjust subplot parameters to give specified padding(default =1.08)
plt.tight_layout()
plt.show()


##classification 
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from sklearn import neighbors, datasets

n_neighbors = 15

iris = datasets.load_iris()

# we only take the first two features
#such that drawing can be on 2D page 
X = iris.data[:, :2]
y = iris.target

h = .02  # step size in the mesh

#Colormap object generated from a list of colors.
cmap_light = ListedColormap(['#FFAAAA', '#AAFFAA', '#AAAAFF'])
cmap_bold = ListedColormap(['#FF0000', '#00FF00', '#0000FF'])

clf = neighbors.KNeighborsClassifier(n_neighbors, weights='uniform')
clf.fit(X, y)

# Plot the decision boundary. For that, we will assign a color to each
# point in the mesh [x_min, x_max]x[y_min, y_max].
x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
#XX is row stack of x, YY is column stack of y 
xx, yy = np.meshgrid(np.arange(x_min, x_max, h),np.arange(y_min, y_max, h))
#column stack of xx and yy , ravel-flatten , se we get 2D of feature 1 and feature 2
Z = clf.predict(np.c_[xx.ravel(), yy.ravel()])
# Put the result into a color plot
Z = Z.reshape(xx.shape) #get the same shape of xx 
plt.figure()
#Create a pseudocolor plot with a non-regular rectangular grid.
plt.pcolormesh(xx, yy, Z, cmap=cmap_light)
# Plot also the training points
# c : color or sequence of floats, would be used to map colors from cmap 
#The colormap is a dictionary which maps numbers(float) to colors
plt.scatter(X[:, 0], X[:, 1], c=y, cmap=cmap_bold, edgecolor='k', s=20)
plt.xlim(xx.min(), xx.max())
plt.ylim(yy.min(), yy.max())
plt.title("KNN classification ")
plt.show()



#then check and execute plot_classification.py










###Clustering with KMeans    

from sklearn.cluster import KMeans


iris = pd.read_csv('toBeShared/data/iris.csv')

iris_m = iris.assign( SepalRatio = lambda df: df.SepalWidth / df.SepalLength, PetalRatio = lambda df: df.PetalWidth / df.PetalLength) 
iris_m.plot(kind='scatter', x='SepalRatio', y='PetalRatio')

numpy_features = iris_m[ ['SepalRatio','PetalRatio' ]].values #.values not required 
kmeans = KMeans(n_clusters=2, random_state=0).fit(numpy_features)
>>> kmeans.cluster_centers_
array([[0.68569927, 0.16512688],
       [0.46103872, 0.33785156]])
>>> kmeans.labels_  #each point's cluster index 
array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
       0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1])
       
       
###Clustering Visualizers using yellowbrick
##The elbow method for K
#visualizes multiple clustering models with different values for K

#Model selection is based on whether or not there is an “elbow” in the curve; 
#e.g. if the curve looks like an arm, if there is a clear change in angle from one part of the curve to another.


from sklearn.cluster import MiniBatchKMeans

from yellowbrick.cluster import KElbowVisualizer

# Instantiate the clustering model and visualizer
visualizer = KElbowVisualizer(MiniBatchKMeans(), k=(1,12))

visualizer.fit(iris_m[ ['SepalRatio','PetalRatio' ]] ) # Fit the training data to the visualizer
visualizer.poof() # Draw/show/poof the data


##Silhouette Visualizer
#The Silhouette Coefficient is used when the ground-truth about the dataset is unknown 
#and computes the density of clusters computed by the model. 
#The score is computed by averaging the silhouette coefficient for each sample, computed as the difference between the average intra-cluster distance 
#and the mean nearest-cluster distance for each sample, normalized by the maximum value. 

#This produces a score between 1 and -1, where 1 is highly dense clusters and -1 is completely incorrect clustering.

#The Silhouette Visualizer displays the silhouette coefficient for each sample on a per-cluster basis, 
#visualizing which clusters are dense and which are not. 
#This is particularly useful for determining cluster imbalance, or for selecting a value for K by comparing multiple visualizers.

from sklearn.datasets import make_blobs

# Make 8 blobs dataset
X, y = make_blobs(centers=8)

from sklearn.cluster import MiniBatchKMeans

from yellowbrick.cluster import SilhouetteVisualizer

# Instantiate the clustering model and visualizer
model = MiniBatchKMeans(6)
visualizer = SilhouetteVisualizer(model)

visualizer.fit(X) # Fit the training data to the visualizer
visualizer.poof() # Draw/show/poof the data
#K=2 would give good 


##Check and execute plot_color_quantization.py       