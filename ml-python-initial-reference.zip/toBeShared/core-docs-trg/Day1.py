    Linear algebra using numpy,
    Plotting using matplotlib
    Dataframe manipulation using pandas
    Basic Statistics and essentials **
        o Population and Sample
        o Measures of Central tendency
        o Measures of dispersion
        o Percentiles & Quartiles
        o Box plots and outlier detection
        o Creating Graphs and Reporting
----------------------------------------------
###Linear algebra using numpy, 
import numpy as np

a = np.array([1, 2, 3])  # Create a rank 1 array
print(type(a))            # Prints "<type 'numpy.ndarray'>"
print(a.shape)            # Prints "(3,)"
print(a.ndim) 			 # 1
print(a[0], a[1], a[2])   # Prints "1 2 3"
a[0] = 5                 # Change an element of the array
print(a)                  # Prints "[5, 2, 3]"

b = np.array([[1,2,3],[4,5,6]])   # Create a rank 2 array
print(b.shape)                     # Prints "(2, 3)"
print(b[0, 0], b[0, 1], b[1, 0])   # Prints "1 2 4"
b[0,]	#or b[0,:]   			  # array([1, 2, 3])  
b[:,0]                            #array([1, 4])



#Note the difference of below, one is vector and another is 1x3
>>> x = np.array([[1,2,3]])        
>>> x.shape                         #rank 2 as two dimension 
(1, 3)

>>> x = np.array([1,2,3])           # rank 1, generally called vector 
>>> x.shape
(3,)

##Creation of array - these methods take (m,n,...) dimensions 
# similar methods (zeros/ones/full)_like(another_array) which creates based on another_array.shape
import numpy as np

a = np.zeros((2,2))  # Create an array of all zeros 

    
b = np.ones((1,2))   # Create an array of all ones

c = np.full((2,2), 7) # Create a constant array
print(c)               # Prints "[[ 7.  7.]
                      #          [ 7.  7.]]"

d = np.eye(2)        # Create a 2x2 identity matrix

#numpy.linspace(start, stop, num=50, endpoint=True, retstep=False, dtype=None)
>>> np.linspace(2.0, 3.0, num=5)
array([ 2.  ,  2.25,  2.5 ,  2.75,  3.  ])

#numpy.arange([start, ]stop, [step, ]dtype=None)
>>> np.arange(3.0)
array([ 0.,  1.,  2.])

>>> np.arange(10).reshape(2,5)
array([[0, 1, 2, 3, 4],
       [5, 6, 7, 8, 9]])

#numpy.logspace(start, stop, num=50, endpoint=True, base=10.0, dtype=None)
#base ** start is the starting value of the sequence.
>>> np.logspace(2.0, 3.0, num=4)
array([  100.        ,   215.443469  ,   464.15888336,  1000.        ])

##Broadcasting 
x = np.linspace(1.0, 5.0, num=5)
y = np.linspace(10.0, 50.0, num=5)
>>> x
array([1., 2., 3., 4., 5.])
>>> y
array([10., 20., 30., 40., 50.])
>>> x.shape
(5,)
>>> y.shape
(5,)
>>> y1 = y[:, None]
>>> y1
array([[10.],
       [20.],
       [30.],
       [40.],
       [50.]])
>>> y2 = y[:, np.newaxis]
>>> y2
array([[10.],
       [20.],
       [30.],
       [40.],
       [50.]])
>>> y3 = y[None, :]
>>> y3
array([[10., 20., 30., 40., 50.]])
#means removes any dim if it is of  1 
>>> np.squeeze(y1)
array([10., 20., 30., 40., 50.])
#boardcasting 
>>> x + y1  #== x[None,:] + y1 #X becomes (1, 5), then x becomes (5,5) with all title of first row 
array([[11., 12., 13., 14., 15.],
       [21., 22., 23., 24., 25.],
       [31., 32., 33., 34., 35.],
       [41., 42., 43., 44., 45.],
       [51., 52., 53., 54., 55.]])
#ie 
>>> np.tile(x, (5,1))   #row five times, column 1 times 
array([[1., 2., 3., 4., 5.],
       [1., 2., 3., 4., 5.],
       [1., 2., 3., 4., 5.],
       [1., 2., 3., 4., 5.],
       [1., 2., 3., 4., 5.]])
>>> np.tile(y1, (1,5))          #row 1 times , column 5 times , final dim =(5*1, 1*5)
array([[10., 10., 10., 10., 10.],
       [20., 20., 20., 20., 20.],
       [30., 30., 30., 30., 30.],
       [40., 40., 40., 40., 40.],
       [50., 50., 50., 50., 50.]])
#OR 
>>> x
array([1., 2., 3., 4., 5.])
>>> XX,YY = np.meshgrid(x,y)
>>> XX
array([[1., 2., 3., 4., 5.],
       [1., 2., 3., 4., 5.],
       [1., 2., 3., 4., 5.],
       [1., 2., 3., 4., 5.],
       [1., 2., 3., 4., 5.]])
>>> YY
array([[10., 10., 10., 10., 10.],
       [20., 20., 20., 20., 20.],
       [30., 30., 30., 30., 30.],
       [40., 40., 40., 40., 40.],
       [50., 50., 50., 50., 50.]])
#mgrid  are helper classes which use index notation 
#without having to use 'linspace'. 
#Note The order in which the output are generated is reversed.
YY1, XX1 = np.mgrid[10:40:10, 1:4]
XX1
array([[1, 2, 3],
       [1, 2, 3],
       [1, 2, 3]])
YY1
array([[10, 10, 10],
       [20, 20, 20],
       [30, 30, 30]])
#ravel means flatten 
>>> XX.ravel()
array([1., 2., 3., 4., 5., 1., 2., 3., 4., 5., 1., 2., 3., 4., 5., 1., 2., 3., 4., 5., 1., 2., 3., 4., 5.])
>>> YY.ravel()
array([10., 10., 10., 10., 10., 20., 20., 20., 20., 20., 30., 30., 30.,30., 30., 40., 40., 40., 40., 40., 50., 50., 50., 50., 50.])
>>> (x+y1).ravel()
array([11., 12., 13., 14., 15., 21., 22., 23., 24., 25., 31., 32., 33., 34., 35., 41., 42., 43., 44., 45., 51., 52., 53., 54., 55.])
>>> XX.ravel() + YY.ravel()
array([11., 12., 13., 14., 15., 21., 22., 23., 24., 25., 31., 32., 33.,34., 35., 41., 42., 43., 44., 45., 51., 52., 53., 54., 55.])

##random 
#https://docs.scipy.org/doc/numpy-1.14.1/reference/routines.random.html
#Seed
RandomState([seed]) 	
    Container for the Mersenne Twister pseudo-random number generator.
    RandomState has similar methods like np.random.  where these seed would be valid 
seed([seed]) 	
    Seed the generator, used for np.random methods 

##many methods(few are similar) are there eg  
#Note size is either single N or (d1, d2,..) for multidimesion      
rand(d0, d1, …, dn) 	
    Random values in a given shape.
randn(d0, d1, …, dn) 	
    Return a sample (or samples) from the "standard normal" distribution.
randint(low[, high, size, dtype]) 	
    Return random integers from low (inclusive) to high (exclusive).
random_integers(low[, high, size]) 	
    Random integers of type np.int between low and high, inclusive.
    
random_sample([size]) 	
ranf([size]) 	
sample([size]) 	
random([size]) 	
    All these methods Return random floats in the half-open interval [0.0, 1.0).


#Example     
np.random.random((2,2)) 
np.random.rand(3,2) 
2.5 * np.random.randn(2, 4) + 3


#Many distributions, 
#for example 
lognormal([mean, sigma, size]) 	
    Draw samples from a log-normal distribution.
multinomial(n, pvals[, size]) 	
    Draw samples from a multinomial distribution.
normal([loc, scale, size]) 	    
    Draw random samples from a normal (Gaussian) distribution.
#Example      
mu, sigma = 0, 0.1 # mean and standard deviation
s = np.random.normal(mu, sigma, 1000)    
s.shape  #(1000,)
s = np.random.normal(mu, sigma, (6,4))     
s.shape     #(1000,)
       
       
        





##Array indexing - Slice Indexing (can be mutated)
#index can be single number, or start:stop:step (stop exclusive)
#or :(means all elements of that dimension) or array of indexes
#or boolean array(where True indexes are selected)
import numpy as np

# Create the following rank 2 array with shape (3, 4)
a = np.array([[1,2, 3, 4], 
              [5,6, 7, 8], 
              [9,10,11,12]])


b = a[:2, 1:3]
print(a[0, 1])   # Prints "2"
b[0, 0] = 77    # b[0, 0] is the same piece of data as a[0, 1]
print(a[0, 1])   # Prints "77"

row_r1 = a[1, :]    # Rank 1 view of the second row of a  
row_r2 = a[1:2, :]  # Rank 2 view of the second row of a
col_r1 = a[:, 1]
col_r2 = a[:, 1:2]

##Boolean array indexing - a[bool], bool and a are of same dimension 

import numpy as np

a = np.array([[1,2], [3, 4], [5, 6]])

bool_idx = (a > 2)  
            
print(bool_idx)      # Prints "[[False False]
                    #          [ True  True]
                    #          [ True  True]]"

print(a[bool_idx])  # Prints "[3 4 5 6]", 

# We can do all of the above in a single concise statement:
print(a[a > 2])     # Prints "[3 4 5 6]"

>>> a[ (a > 2) & (a<5)]    #Use &, | and ~ for boolean operation , ==, !=, > >= etc for comparison
array([3, 4])
>>> a[ (a > 2) | (a<5)]
array([1, 2, 3, 4, 5, 6])
>>> a[ ~(a > 2) ]
array([1, 2])

>>> a[ a == 2]
array([2])
>>> a[ a != 2]
array([1, 3, 4, 5, 6])


##Numpy - Array indexing - using ... (means all remaining dimensions)
>>> from numpy import arange
>>> a = arange(16).reshape(2,2,2,2)

#you have a 4-dimensional matrix of order 2x2x2x2. 
#To select all first elements in the 4th dimension, you can use the ellipsis notation
>>> a[..., 0].flatten()
array([ 0,  2,  4,  6,  8, 10, 12, 14])

#which is equivalent to
>>> a[:,:,:,0].flatten()
array([ 0,  2,  4,  6,  8, 10, 12, 14])


##Numpy - numpy.newaxis
#Either ndarray.reshape or numpy.newaxis can be used to add a new dimension to an array. 
#the newaxis is used to increase the dimension of the existing array 

#Example
# 1D array
arr = np.arange(4)
>>> arr.shape
(4,)

# make it as row vector by inserting an axis along first dimension
row_vec = arr[np.newaxis, :]
row_vec.shape
#(1, 4)

# make it as column vector by inserting an axis along second dimension
col_vec = arr[:, np.newaxis]
col_vec.shape
#(4, 1)
#Example 
A = np.ones((3,4,5,6)) #shape 
B = np.ones((4,6))   #shape 
(A + B[:, np.newaxis, :]).shape
#(3, 4, 5, 6)


# Default iteration
a = np.arange(6).reshape(3,2)
>>> a
array([[0, 1],
       [2, 3],
       [4, 5]])
       
for val in a:
    print('item:', val)
#output 
item: [0 1]
item: [2 3]
item: [4 5]


##Array math 
#ndarray.methods or np.methods(ndarray) - operates elementwise on array 
#check by 
#https://docs.scipy.org/doc/numpy-1.13.0/reference/ufuncs.html
dir(np)

import numpy as np

x = np.array([[1,2],[3,4]], dtype=np.float64)
y = np.array([[5,6],[7,8]], dtype=np.float64)

# Elementwise sum; both produce the array
# [[ 6.0  8.0]
#  [10.0 12.0]]
print(x + y)
print(np.add(x, y))
# Elementwise
print(x - y)    #print np.subtract(x, y)
print(x * y)    #print np.multiply(x, y)
print(x / y)    #print np.divide(x, y)

##Use .dot  for inner product of vector or matrix multiplication 
v = np.array([9,10])
w = np.array([11, 12])

# Inner product of vectors; both produce 219
print(v.dot(w))
print(np.dot(v, w))
# Matrix / vector product; both produce the rank 1 array [29 67]
print(x.dot(v)
print(np.dot(x, v))
# Matrix / matrix product; both produce the rank 2 array
# [[19 22]
#  [43 50]]
print(x.dot(y))
print(np.dot(x, y))
#Many mathemaical functions 
np.log(x) 
print(np.sqrt(x))  #other math methods eg np.sin(), np.log() ....



##Sum -  for performing computations on arrays 

# For , np.sum(axis=n),  then dimension n is collapsed and deleted, 
#For example, if b has shape (5,6,7,8), and c = b.sum(axis=2), 
#then axis 2 (dimension with size 7) is collapsed, and the result has shape (5,6,8). 
#c[x,y,z] is equal to the sum of all elements c[x,y,:,z].


#Other similar methods are 
ndarray.cumsum([axis, dtype, out]) 					Return the cumulative sum of the elements along the given axis. 
ndarray.mean([axis, dtype, out, keepdims]) 			Returns the average of the array elements along given axis. 
ndarray.var([axis, dtype, out, ddof, keepdims]) 	Returns the variance of the array elements, along given axis. 
ndarray.std([axis, dtype, out, ddof, keepdims]) 	Returns the standard deviation of the array elements along given axis. 
ndarray.prod([axis, dtype, out, keepdims]) 			Return the product of the array elements over the given axis 
ndarray.cumprod([axis, dtype, out]) 				Return the cumulative product of the elements along the given axis. 

#for 2D , axis=0, means column sum and axis=1, means row sum 

import numpy as np

x = np.array([[1,2],[3,4]])

print(np.sum(x))  # Compute sum of all elements; prints "10"
print(np.sum(x, axis=0))  # Compute sum of each column; prints "[4 6]"
print(np.sum(x, axis=1))  # Compute sum of each row; prints "[3 7]"

>>> np.cumsum(x, axis=0)
array([[1, 2],
       [4, 6]], dtype=int32)

>>> np.cumsum(x, axis=1)
array([[1, 3],
       [3, 7]], dtype=int32)
       
       
       
##Transposing  an array 
import numpy as np

x = np.array([[1,2], [3,4]])
print(x)    # Prints "[[1 2]
           #          [3 4]]"
print(x.T)  # Prints "[[1 3]
           #          [2 4]]"

# Note that taking the transpose of a rank 1 array does nothing:
v = np.array([1,2,3])
print(v)    # Prints "[1 2 3]"
print(v.T)  # Prints "[1 2 3]"


##Conversion
x = np.array([1, 2, 2.5])
>>> x
array([ 1. ,  2. ,  2.5])

>>> x.astype(int)
array([1, 2, 2])
>>> x.astype(str)
array(['1.0', '2.0', '2.5'],
      dtype='|S32')
      
##Repeat and Tile 
x = np.array([[1,2],[3,4]])
>>> np.repeat(x, 2)   #default is flattened, and each element 2 times 
array([1, 1, 2, 2, 3, 3, 4, 4])
>>> np.repeat(x, 3, axis=1)     #axis=1 means column , each column 3 times 
array([[1, 1, 1, 2, 2, 2],
       [3, 3, 3, 4, 4, 4]])
>>> np.repeat(x, [1, 2], axis=0) #axis=0 means row, row1 one time, row2 two times 
array([[1, 2],
       [3, 4],
       [3, 4]])

#numpy.tile(A, reps)
#Construct an array by repeating A  given by reps(The number of repetitions of A along each axis.)
#If reps has length d, the result will have dimension of max(d, A.ndim).
#If A.ndim < d, A is promoted to be d-dimensional by prepending new axes(broadcasting)
#So a shape (3,) array is promoted to (1, 3) for 2-D replication, or shape (1, 1, 3) for 3-D replication. 
#If this is not the desired behavior, promote A to d-dimensions manually before calling this function.
#If A.ndim > d, reps is promoted to A.ndim by pre-pending 1’s to it. 
#Thus for an A of shape (2, 3, 4, 5), a reps of (2, 2) is treated as (1, 1, 2, 2).
a = np.array([0, 1, 2])
>>> np.tile(a, 2)
array([0, 1, 2, 0, 1, 2])

>>> np.tile(a, (2, 2))   #promote a to (1,3), then to (1*reps, 3*reps)
array([[0, 1, 2, 0, 1, 2],
       [0, 1, 2, 0, 1, 2]])
>>> np.tile(a, (2, 1, 2))  #promote a to (1,1,3), then to (1*2, 1*1, 3*2)
array([[[0, 1, 2, 0, 1, 2]],
       [[0, 1, 2, 0, 1, 2]]])

b = np.array([[1, 2], [3, 4]])
>>> np.tile(b, 2)    #promote reps to (1,2) ie b dim = (2*1, 2*2), each row one times, each column two times 
array([[1, 2, 1, 2],
       [3, 4, 3, 4]])
>>> np.tile(b, (2, 1))   #b dim =(2*2, 2*1)
array([[1, 2],
       [3, 4],
       [1, 2],
       [3, 4]])

>>> c = np.array([1,2,3,4])
>>> np.tile(c,(4,1))    #c is promoted to (1,4), then dim= (1*4,4*1)
array([[1, 2, 3, 4],
       [1, 2, 3, 4],
       [1, 2, 3, 4],
       [1, 2, 3, 4]])


       
      
##r_ , c_ , stack etc 
#In general use concatenate for row(vertical) stacking or column(horizontal) stacking
#Many other functions do the same activity, 
#Use .r_[] or .c_[] if you want to use integer slice 

#a,b are 2D , axis=0, rowwise, axis=1, columnwise 
a = np.array([[1, 2], [3, 4]])
b = np.array([[5, 6]])
>>> np.concatenate((a, b), axis=0)
array([[1, 2],
       [3, 4],
       [5, 6]])
       
>>> b.T
array([[5],
       [6]]) 
>>> np.concatenate((a, b.T), axis=1)
array([[1, 2, 5],
       [3, 4, 6]])       
       
>>> np.concatenate((a, b), axis=None)
array([1, 2, 3, 4, 5, 6])



##When a,b are 1D 
np.r_  
    By default: create a array(1D) from comma seperated many slices start:stop:step (stop exclusive)
    or comman seperated numbers (along the first axis ie row)
    it has many other functonalities - check Reference 

np.c_ 
    create a array(2D) from comma seperated many 1D arrays or start:stop:step (stop exclusive)
    but  along the second axis(ie column) -> Column stack 


#note used with []   not ()

#column stacking 
a = np.array([1, 2, 3])
b = np.array([4,5,6])

>>> np.c_[a,b]
array([[1, 4],
       [2, 5],
       [3, 6]])
       

>>> x = np.r_[-2:3, 0,0, 3:9]
>>> x
array([-2, -1,  0,  1,  2,  0,  0,  3,  4,  5,  6,  7,  8]

#vstack vs hstack
a = np.array([1, 2, 3])
b = np.array([2, 3, 4])
>>> np.vstack((a,b))
array([[1, 2, 3],
       [2, 3, 4]])
       
>>> np.hstack((a,b))
array([1, 2, 3, 2, 3, 4])

#when a,b re 2D
a1 = np.array([[1],[2],[3]])
b1 = np.array([[2],[3],[4]])       
>>> np.vstack((a1,b1))
array([[1],
       [2],
       [3],
       [2],
       [3],
       [4]])
       
>>> np.hstack((a1,b1))
array([[1, 2],
       [2, 3],
       [3, 4]])

#columnwise append 
a = np.array((1,2,3))
b = np.array((2,3,4))
>>> np.column_stack((a,b))
array([[1, 2],
       [2, 3],
       [3, 4]])
       
   
       
#General stack , axis=0, rowwise, axis=1, columnwise 
a = np.array([1, 2, 3])
b = np.array([2, 3, 4])
>>> np.stack((a, b))
array([[1, 2, 3],
       [2, 3, 4]])

>>> np.stack((a, b), axis=-1) #stack as column, -1 means last dimension 
array([[1, 2],
       [2, 3],
       [3, 4]])


       
       
##numpy Matrix 
x = np.array([[1, 2], [3, 4]])
m = np.asmatrix(x)
x[0,0] = 5
>>> m
matrix([[5, 2],
        [3, 4]])
#matrix multiplication 
print(m * m) 

#3. Matrices have special attributes which make calculations easier. 
matrix.T 
    Returns the transpose of the matrix. 
matrix.H 
    Returns the (complex) conjugate transpose of self. 
matrix.I 
    Returns the (multiplicative) inverse of invertible self. 
matrix.A 
    Return self as an ndarray object. 

    
    
#ndarray.reshape(shape[, order]) 				Returns an array containing the same data with a new shape. 
#ndarray.resize(new_shape[, refcheck]) 			Change shape and size of array in-place. 

#Example , one shape arg could be -1 , then that is calculated 
b = np.array([[0, 1], [2, 3]])
b.resize(2, 3) # or tuple (2,3)
#or 
b = b.reshape((2,3)) #or varargs 2,3 
b = b.reshape(2,-1)  #-1 would be autocalculated 
>>> b
array([[0, 1, 2],
       [3, 0, 0]])
  
#ndarray.ravel([order]) 							Return a flattened array. 
x = np.array([[1, 2, 3], [4, 5, 6]])
>>> print(np.ravel(x))
[1 2 3 4 5 6]
#OR 
>>> print(x.reshape(-1))
[1 2 3 4 5 6]

#ndarray.squeeze([axis]) 						Remove single-dimensional entries from the shape of a. 
x = np.array([[[0], [1], [2]]])
>>> x.shape
(1, 3, 1)
>>> np.squeeze(x).shape
(3,)
>>> np.squeeze(x, axis=(2,)).shape
(1, 3)
  
#More ndarray methods  
ndarray.sort([axis, kind, order]) 				
    Sort an array, in-place. 
#Example 
a = np.array([[1,4],[3,1]])
>>> np.sort(a)                # sort along the last axis, ie axis=1 for 2D, rowwise 
array([[1, 4],
       [1, 3]])
       
>>> np.sort(a, axis=None)     # sort the flattened array
array([1, 1, 3, 4])

>>> np.sort(a, axis=0)        # sort along the first axis/ columnwise 
array([[1, 1],
       [3, 4]])   
    
    
ndarray.argsort([axis, kind, order]) 			
    Returns the indices that would sort this array. 
#Example 
x = np.array([3, 1, 2])
>>> np.argsort(x)
array([1, 2, 0])  #ie sorted array is x[1], x[2], x[0]

x = np.array([[0, 3], [2, 2]])
>>> x
array([[0, 3],
       [2, 2]])
       
>>> np.argsort(x, axis=0)  # sorts along first axis (down), columnwise 
array([[0, 1],
       [1, 0]])

>>> np.argsort(x, axis=1)  # sorts along last axis (across), rowwise 
array([[0, 1],
       [0, 1]])


    
ndarray.argmax([axis, out]) 						
    Return indices of the maximum values along the given axis. 
ndarray.argmin([axis, out]) 						
    Return indices of the minimum values along the given axis of a. 
#Example 
a = np.arange(6).reshape(2,3)
>>> a
array([[0, 1, 2],
       [3, 4, 5]])
>>> np.argmax(a)
5
>>> np.argmax(a, axis=0) #columnwise 
array([1, 1, 1])
>>> np.argmax(a, axis=1) #rowwise 
array([2, 2])


ndarray.max(axis=None, out=None, keepdims=False)
ndarray.min(axis=None, out=None, keepdims=False)
    Return the maximum/minimum along a given axis.
    equivalent to numpy.amax, numpy.amin 
numpy.amax, amin(a, axis=None, out=None, keepdims=<class 'numpy._globals._NoValue'>)
    Return the maximum/minimum of an array or maximum along an axis.

#Example 
a = np.arange(4).reshape((2,2))
>>> a
array([[0, 1],
       [2, 3]])
       
>>> np.amin(a)           # Minimum of the flattened array
0

>>> np.amin(a, axis=0)   # Minima along the first axis(columnwise)
array([0, 1])

>>> np.amin(a, axis=1)   # Minima along the second axis(rowwise)
array([0, 2])  
    
       
       
meshgrid(*xi, **kwargs) 							
    Return coordinate matrices from coordinate vectors.
mgrid 												
    nd_grid instance which returns a dense multi-dimensional 'meshgrid'.
ogrid 												
    nd_grid instance which returns an open multi-dimensional 'meshgrid'.

#Difference of meshgrid, mgrid, ogrid, Scipy.ndgrid, Scipy.Boxgrid
#meshgrid- It is used to vectorise functions of two variables, so that you can write
x = np.array([1, 2, 3])
y = np.array([10, 20, 30]) 
XX, YY = np.meshgrid(x, y)  #XX is row stack of x, YY is column stack of y 
XX                          #
array([[1, 2, 3],
       [1, 2, 3],
       [1, 2, 3]])
YY
array([[10, 10, 10],
       [20, 20, 20],
       [30, 30, 30]])


ZZ = XX + YY    #all the combinations of x and y put into the function
ZZ => array([[11, 12, 13],
             [21, 22, 23],
             [31, 32, 33]])

#equivalent to below 
XX, YY = np.atleast_2d(x, y)
XX  #array([[1, 2, 3]])
YY #array([[10, 20, 30]])
YY = YY.T # transpose to allow broadcasting
ZZ = XX + YY


#mgrid and ogrid are helper classes which use index notation 
#without having to use 'linspace'. 
#Note The order in which the output are generated is reversed.
YY, XX = np.mgrid[10:40:10, 1:4]
XX
array([[1, 2, 3],
       [1, 2, 3],
       [1, 2, 3]])
YY
array([[10, 10, 10],
       [20, 20, 20],
       [30, 30, 30]])
ZZ = XX + YY # These are equivalent to the output of meshgrid

YY, XX = numpy.ogrid[10:40:10, 1:4]
XX  #array([[1, 2, 3]])
YY 
array([[10],
       [20],
       [30]])
ZZ = XX + YY # These are equivalent to the atleast_2d example

#Scipy.ndgrid === meshgrid, 
#Sci.pyBoxGrid is the class to help with this kind of generation.


##Splitting arrays
   
hsplit(ary, indices_or_sections) 	
    Split an array into multiple sub-arrays horizontally (column-wise).
#Example 
x = np.arange(16.0).reshape(4, 4)
>>> x
array([[  0.,   1.,   2.,   3.],
       [  4.,   5.,   6.,   7.],
       [  8.,   9.,  10.,  11.],
       [ 12.,  13.,  14.,  15.]])
>>> np.hsplit(x, 2)
[array([[  0.,   1.],
       [  4.,   5.],
       [  8.,   9.],
       [ 12.,  13.]]),
 array([[  2.,   3.],
       [  6.,   7.],
       [ 10.,  11.],
       [ 14.,  15.]])]



 
vsplit(ary, indices_or_sections) 	
    Split an array into multiple sub-arrays vertically (row-wise).

#Example 
x = np.arange(16.0).reshape(4, 4)
>>> x
array([[  0.,   1.,   2.,   3.],
       [  4.,   5.,   6.,   7.],
       [  8.,   9.,  10.,  11.],
       [ 12.,  13.,  14.,  15.]])
>>> np.vsplit(x, 2)
[array([[ 0.,  1.,  2.,  3.],
       [ 4.,  5.,  6.,  7.]]),
 array([[  8.,   9.,  10.,  11.],
       [ 12.,  13.,  14.,  15.]])]
 
    
##Tiling arrays
tile(A, reps) 	
    Construct an array by repeating A the number of times given by reps.
#Example 
b = np.array([[1, 2], [3, 4]])
>>> np.tile(b, 2)
array([[1, 2, 1, 2],
       [3, 4, 3, 4]])
>>> np.tile(b, (2, 1)) #2 rows, 1 columns 
array([[1, 2],
       [3, 4],
       [1, 2],
       [3, 4]])       
    
repeat(a, repeats[, axis]) 	
    Repeat elements of an array.
#Example 
x = np.array([[1,2],[3,4]])
>>> np.repeat(x, 2)
array([1, 1, 2, 2, 3, 3, 4, 4])
>>> np.repeat(x, 3, axis=1)
array([[1, 1, 1, 2, 2, 2],
       [3, 3, 3, 4, 4, 4]])
>>> np.repeat(x, [1, 2], axis=0) #no of repetations of x element , [1,2]- 1, [3,4] -2 
array([[1, 2],
       [3, 4],
       [3, 4]])    
    

##Adding and removing elements
delete(arr, obj[, axis]) 	
    Return a new array with sub-arrays along an axis deleted.
#Exmaple 
arr = np.array([[1,2,3,4], [5,6,7,8], [9,10,11,12]])
>>> arr
array([[ 1,  2,  3,  4],
       [ 5,  6,  7,  8],
       [ 9, 10, 11, 12]])
>>> np.delete(arr, 1, axis=0)#axis =0, row delete, 1=means which subarray to delete 
array([[ 1,  2,  3,  4],
       [ 9, 10, 11, 12]])
       
    
insert(arr, obj, values[, axis]) 	
    Insert values along the given axis before the given indices.
#Example 
a = np.array([[1, 1], [2, 2], [3, 3]])
>>> a
array([[1, 1],
       [2, 2],
       [3, 3]])
>>> np.insert(a, 1, 5, axis=1) #axis=1, insert column, before 1, value 5 
array([[1, 5, 1],
       [2, 5, 2],
       [3, 5, 3]])   
    
    
append(arr, values[, axis]) 	
    Append values to the end of an array.
#Example 
arr = np.array([1, 2, 3])
values = [[4, 5, 6], [7, 8, 9]]
>>> np.append(arr, values)
array([1, 2, 3, 4, 5, 6, 7, 8, 9])
>>> np.append([[1, 2, 3], [4, 5, 6]], [[7, 8, 9]], axis=0) #axis=0 , row append 
array([[1, 2, 3],
       [4, 5, 6],
       [7, 8, 9]])    
    
unique(ar[, return_index, return_inverse, ...]) 	
    Find the unique elements of an array.
#Example 
>>> np.unique([1, 1, 2, 2, 3, 3])
array([1, 2, 3])
>>> a = np.array([[1, 1], [2, 3]])
>>> np.unique(a)
array([1, 2, 3])
a = np.array([[1, 0, 0], [1, 0, 0], [2, 3, 4]])
>>> np.unique(a, axis=0)  #axis=0, rowwise 
array([[1, 0, 0], [2, 3, 4]])


#More funtions 
atleast_1d(*arys) 	
    Convert inputs to arrays with at least one dimension.
atleast_2d(*arys) 	
    View inputs as arrays with at least two dimensions.
atleast_3d(*arys) 	
    View inputs as arrays with at least three dimensions.
#Example 
>>> np.atleast_1d(1.0)
array([ 1.])
>>> np.atleast_2d(3.0)
array([[ 3.]])
>>> x = np.arange(3.0)
>>> np.atleast_2d(x)
array([[ 0.,  1.,  2.]])

   
broadcast_to(array, shape[, subok]) 	
    Broadcast an array to a new shape.

#Example 
x = np.array([1, 2, 3])
>>> np.broadcast_to(x, (3, 3))
array([[1, 2, 3],
       [1, 2, 3],
       [1, 2, 3]])
        
rollaxis(a, axis[, start]) 	
    Roll the specified axis backwards, until it lies in a given position.
    
    
moveaxis(a, source, destination) 	
    Move axes of an array to new positions.
    source, destination could be list of indices as well as one indices 
swapaxes(a, axis1, axis2) 	
    Interchange two axes of an array.
transpose(a[, axes]) 	
    Permute the dimensions of an array.
#Example 
x = np.zeros((3, 4, 5))
>>> np.moveaxis(x, 0, -1).shape # Move 0 to last, by swapping two two , eg 3 <=>4, then 3 <=> 5
(4, 5, 3)
>>> np.moveaxis(x, -1, 0).shape # 5 <=> 4, then 5 <=> 3
(5, 3, 4)
x = np.zeros((3, 4, 5,6,7))
>>> np.moveaxis(x, 0, -1).shape #3<=>4, 3<=>5, 3<=>6, 3<=>7
(4, 5, 6, 7, 3)
>>> np.moveaxis(x,  -1, 0).shape #7<=>6, 7<=>5, 7<=>4, 7<=>3
(7, 3, 4, 5, 6)
#transpose 
x = np.zeros((3, 4, 5,6)) # 3 <=> 6 , 4 <=> 5
>>> np.transpose(x).shape
(6, 5, 4, 3)
x = np.zeros((3, 4, 5,6,7)) # 3 <=> 7 , 4 <=> 6 , 5 middle one 
>>> np.transpose(x).shape
(7, 6, 5, 4, 3)



 
###Some Example of numpy applications 
#Solve the system of equations 3 * x0 + x1 = 9 and x0 + 2 * x1 = 8:

a = np.array([[3,1], [1,2]])
b = np.array([9,8])
x = np.linalg.solve(a, b)
>>> x
array([ 2.,  3.])
#Check that the solution is correct:
>>> np.allclose(np.dot(a, x), b)
True

from numpy.linalg import inv
a = np.array([[1., 2.], [3., 4.]])
ainv = inv(a)
>>> np.allclose(np.dot(a, ainv), np.eye(2))
True
>>> np.allclose(np.dot(ainv, a), np.eye(2))
True
 

 
 
 
 
###Plotting using matplotlib 
#There are three layers to the matplotlib API. 
1.The matplotlib.backend_bases.FigureCanvas 
    is the area  onto which the figure is drawn, 
2.The matplotlib.backend_bases.Renderer 
    is the object  which knows how to draw on the FigureCanvas, 
    The FigureCanvas and Renderer handle all the details of talking 
    to user interface toolkits like wxPython or drawing languages like PostScript®
3.The matplotlib.artist.Artist 
    is the object that knows how to use a renderer to paint onto the canvas. 
    The Artist handles all the high level constructs 
    like representing and laying out the figure, text, and lines. 
    The typical user will spend 95% of their time working with the Artists.  
    There are two types of Artists: primitives and containers. 
    #check class hierarchy https://matplotlib.org/api/artist_api.html  
    The primitives represent the standard graphical objects 
    eg  Line2D, Rectangle, Text, AxesImage, etc.(subclass of Artist)
    and the containers are places to put primitives (Axis, Axes and Figure)(subclass of Artist) 


#character      description 
'-'             solid line style 
'--'            dashed line style 
'-.'            dash-dot line style 
':'             dotted line style 
'.'             point marker 
','             pixel marker 
'o'             circle marker 
'v'             triangle_down marker 
'^'             triangle_up marker 
'<'             triangle_left marker 
'>'             triangle_right marker 
'1'             tri_down marker 
'2'             tri_up marker 
'3'             tri_left marker 
'4'             tri_right marker 
's'             square marker 
'p'             pentagon marker 
'*'             star marker 
'h'             hexagon1 marker 
'H'             hexagon2 marker 
'+'             plus marker 
'x'             x marker 
'D'             diamond marker 
'd'             thin_diamond marker 
'|'             vline marker 
'_'             hline marker 

#character   color 
'b'         blue 
'g'         green 
'r'         red 
'c'         cyan 
'm'         magenta 
'y'         yellow 
'k'         black 
'w'         white

# few Line2D properties that can be passsed to  plt.plot or ax.plot or other plot functions 
alpha                   float (0.0 transparent through 1.0 opaque) 
animated                [True | False] 
antialiased or aa       [True | False] 
clip_box                a matplotlib.transforms.Bbox instance 
clip_on                 [True | False] 
color or c              any matplotlib color 
dash_capstyle           ['butt' | 'round' | 'projecting'] 
dash_joinstyle          ['miter' | 'round' | 'bevel'] 
drawstyle               ['default' | 'steps' | 'steps-pre' | 'steps-mid' | 'steps-post'] 
fillstyle               ['full' | 'left' | 'right' | 'bottom' | 'top' | 'none'] 
label                   string or anything printable with '%s' conversion. 
linestyle or ls         ['solid' | 'dashed', 'dashdot', 'dotted' | (offset, on-off-dash-seq) | '-' | '--' | '-.' | ':' | 'None' | ' ' | ''] 
linewidth or lw         float value in points 
marker                  A valid marker style 
markeredgecolor or mec  any matplotlib color 
markeredgewidth or mew  float value in points 
markerfacecolor or mfc  any matplotlib color 
markersize or ms        float 
solid_capstyle          ['butt' | 'round' | 'projecting'] 
solid_joinstyle         ['miter' | 'round' | 'bevel'] 
visible                 [True | False] 
zorder                  any number 

###Specifying matplotlib.colors
#Only For the below basic colors, use a single letter
b: blue,g: green,r: red,c: cyan,m: magenta,y: yellow,k: black w: white

#All examples of colors 
#https://matplotlib.org/examples/color/named_colors.html

#Gray shades can be given as a string encoding a float in the 0-1 range, e.g.:
color = '0.75'

#can specify the color using an html hex string(RGB or RGBA), as in:
color = '#eeefff' or '#0F0F0F0F'

#or you can pass an R , G , B tuple, or RGBA 
#where each of R , G , B are in the range [0,1].
color = (0.5,0.5,0.5) or (0.1, 0.2, 0.5, 0.3));

#Or use legal html names for colors, like 'red, 'burlywood and 'chartreuse'
#https://www.w3schools.com/tags/ref_colornames.asp
color = 'burlywood'




#Example
import matplotlib.pyplot as plt
#x,y , red and line 
plt.plot([1,2,3,4], [1,2,3,4],'r-', lw=2)                #y values , x is taken as 0,1,2,3
plt.xlabel('x axis label', fontsize=14, color='red')
plt.ylabel('y axis label')
plt.title('My first plot ')
plt.legend(['Straight Line'], loc='best')
plt.grid(True)
plt.yscale('linear') #log, symlog, logit
plt.xscale('linear')
#https://matplotlib.org/api/_as_gen/matplotlib.pyplot.axis.html
plt.axis([0, 4, 0, 10]) #Set the axis, [xmin, xmax, ymin, ymax] or 'off' or 'equal' or 'scaled' or 'tight' etc 
#or 
plt.ylim(0, 4)
plt.xlim(0, 10)


#x,y this is in data coordinates.
plt.text(2, 2, r'$\mu=100,\ \sigma=15$')  #Any text  or  '$any LaTex code$'
#for axis coords (0,0 is lower-left and 1,1 is upper-right)
plt.text(0.5, 0.5, 'matplotlib', horizontalalignment='center',
            verticalalignment='center', transform=ax.transAxes)

#put a rectangular box around the text 
text(4,4, "Another text", bbox=dict(facecolor='red', alpha=0.5))

#https://matplotlib.org/api/_as_gen/matplotlib.pyplot.annotate.html
#text with arrow 
plt.annotate('local max', xy=(2, 1), xytext=(3, 1.5),arrowprops=dict(facecolor='black', shrink=0.05),) #xytext=location of text, xy=location for annotation
plt.show()




##With multiple x, y pairs in same plot
import numpy as np
import matplotlib.pyplot as plt

# evenly sampled time at 200ms intervals
t = np.arange(0., 5., 0.2)

# red dashes, blue squares and green triangles
plt.plot(t, t, 'r-', t, t**2, 'b--', t, t**3, 'g^')
plt.show()


## Working with multiple figures and axes
#Plots may contain many Figure, 
#each figure is one display window
#each Figure may contain many Axes
#Figure contains set/get of figure related attributes 
#eg get_figheight(),get_figwidth()
#Axes contains plot() and set/get of xlabel, ylabel etc


#https://matplotlib.org/api/_as_gen/matplotlib.pyplot.subplots.html 
##Option-1 
#note subplots(..) returns (figure,axes)
#where axes is numpy.ndarray, hence access like axes[0,0], axes[0,1],... for complex subplots 
#for simple , can destructure immediately
t = np.arange(0., 5., 0.2)

#sharex=True, means only one X ticks value printing , similarly for sharey
figure, (ax1, ax2) = plt.subplots(nrows=1, ncols=2, sharex=False, sharey=True, figsize=(15,15))
ax1.plot(t, t, 'r-')  
ax1.set_title('Sharing Y axis')
ax2.scatter(t, t**2, color='b')
#then show 
plt.show()


##Option-2 
#https://matplotlib.org/api/_as_gen/matplotlib.pyplot.figure.html#matplotlib.pyplot.figure 
fig = plt.figure(figsize=(10,10), edgecolor='b', tight_layout=True)        #create a figure 

ax1 = fig.add_subplot(211)               # nrows, ncols, which_Axes_tomake_current ie 1  
x = np.linspace(0, 2*np.pi, 400)
y = np.sin(x**2)
ax1.plot(x,y,'r-')  
ax2 = fig.add_subplot(212)
ax2.plot(x,y**2,'b--') 
ax2.plot(x,y**3,'go') 
#then show 
plt.show()


##Option-3 
#All plotting commands apply to the current axes.
#figure means one window 
x = np.linspace(0, 2*np.pi, 400)
y = np.sin(x**2)

plt.figure(1)                # the first figure
plt.subplot(211)             # nrows,ncols, which_Axes_tomake_current ie 1                             
plt.plot(x,y,'r-')      # all plot/scatter/box/hist etc goes subplot 1 
plt.subplot(212)             # nrows,ncols, which_Axes_tomake_current ie 2
plt.plot(x,y**2,'b--')      # all plot/scatter/box/hist etc goes subplot 2

plt.figure(2)                # a second figure, sets to this figure, all plot commands go here
plt.plot(x,y**3,'go')      # creates a subplot(111) by default

plt.figure(1)                # figure 1 current; subplot(212) still current
plt.subplot(211)             # make subplot(211) in figure1 current
plt.title('Easy as 1, 2, 3') # subplot 211 title
#then show 
plt.show()



#The function gca() returns the current axes (a matplotlib.axes.Axes instance ),
#and gcf() returns the current figure (matplotlib.figure.Figure instance ).
#clear the current figure with clf() and the current axes with cla()
ax = plt.gca()  #Get the current Axes instance on the current figure 
fig = plt.gcf()  #Get a reference to the current figure.
ax.cla() #clear 
fig.clf() # clear 


##Option-4, advanced 
#https://matplotlib.org/api/_as_gen/matplotlib.pyplot.subplot2grid.html


#3x3 grid , 
fig1= plt.figure(1)
ax1 = plt.subplot2grid((3,3), (0,0), colspan=3) #for (0,0), 3 columns 
ax2 = plt.subplot2grid((3,3), (1,0), colspan=2) #for (1,0), 2 columns 
ax3 = plt.subplot2grid((3,3), (1, 2), rowspan=2) #for (1,2), 2 rows 
ax4 = plt.subplot2grid((3,3), (2, 0))  #one row and col
ax5 = plt.subplot2grid((3,3), (2, 1))   #one row and col 
#Now use ax1.plot() to direct commands to ax1, etc
x = np.linspace(-5,5,20)
y = np.sin(x)
ax1.plot(x,y,"r-")
ax2.plot(x,y,"b-")
ax3.plot(x,y,"r-")
ax4.plot(x,y,"b-")
plt.tight_layout() #tight_layout automatically adjusts subplot params so that the subplot(s) fits in to the figure area
plt.show()






##Few Axes methods  , many are available on plt. as well 
#Note below relevant methods withour arg or get_*() gives current value 
#eg xlim() gives current xlimit , get_xlabel() gives current xlabel 

ax.set_xlabel('x axis label')
ax.set_ylabel('y axis label')
ax.set_title('Simple plot')
ax.legend(['Sine', 'Cosine'])

ax.axis([0, 4, 0, 10]) #Set the axis, [xmin, xmax, ymin, ymax] or 'off' or 'equal' or 'scaled' or 'tight' etc 
ax.set_axis_off() #Turn off the axis. 
ax.set_axis_on()  # Turn on the axis. 

ax.text(60, .025, r'$\mu=100,\ \sigma=15$')  #Any text 
ax.annotate('local max', xy=(2, 1), xytext=(3, 1.5),arrowprops=dict(facecolor='black', shrink=0.05),) #xytext=location of text, xy=location for annotation
ax.arrow(x, y, dx, dy, **kwargs)    #Add an arrow to the axes.
ax.grid(b=True|False, color='r', linestyle='-', linewidth=2)
ax.set_label(s)       #Set the label to s for auto legend.
 
ax.set_ylim(-2,2)
ax.set_xlim(-2,2)
ax.set_yscale('linear') #log, symlog, logit
ax.set_xscale('linear')
ax.set_visible(b)     #Set the artist's visibility.
ax.set_zorder(level)  #Set the zorder for the artist. Artists with lower zorder values are drawn first.

ax.set_xticks(ticks, minor=False)     #Set the x ticks with list of ticks
ax.set_xticklabels(labels, fontdict=None, minor=False, **kwargs)#Set the x-tick labels with list of string labels.
ax.set_yticks(ticks, minor=False)#Set the y ticks with list of ticks
ax.set_yticklabels(labels, fontdict=None, minor=False, **kwargs)#Set the y-tick labels with list of strings labels.

ax.xaxis_date(tz=None)  #Sets up x-axis ticks and labels that treat the x data as dates.
ax.yaxis_date(tz=None)  #Sets up y-axis ticks and labels that treat the y data as dates.
ax.minorticks_off()     #Remove minor ticks from the axes.
ax.minorticks_on()      #Remove minor ticks from the axes.
new_ax = ax.twinx()     #Create a twin Axes sharing the xaxis
new_ax = ax.twiny()     #Create a twin Axes sharing the yaxis


##Few figure methods 
#1st arg = Either a 3-digit integer or three separate integers 
#If the three integers are I, J, and K, 
#the subplot is the Ith plot on a grid with J rows and K columns.
#projection :['aitoff' | 'hammer' | 'lambert' | 'mollweide' | 'polar' | 'rectilinear'], optional The projection type of the axes.
#polar : boolean, optionalIf True, equivalent to projection='polar'.
fig.add_subplot(i,j,k, projection, polar,**kwargs)

#Add an axes at position rect [left, bottom, width, height] 
#where all quantities are in fractions of figure width and height.
#also takes keyword arguments for Axes, get properties via plt.setp(ax) 
fig.add_axes(rect,projection, polar,**kwargs) 

#Other 
fig.legend(handles=(line1, line2, line3), labels=('label1', 'label2', 'label3'), loc='upper right') #loc can be (x,y) or predefined string , linen are matplotlib line instance
fig.text(x, y, s, *args, **kwargs) #Add text to figure.
fig.savefig(fname, **kwargs) #Save the current figure
fig.sca(a)          #Set the current axes to be a and return a
fig.set_dpi(val)            #Set the dots-per-inch of the figure, val is float 
fig.set_edgecolor(color)    #any matplotlib color 
fig.set_facecolor(color)    #any matplotlib color 
fig.set_figheight(val, forward=False) #val is float 
fig.set_figwidth(val, forward=False)  #val is float 
fig.set_size_inches(w, h=None, forward=True)
fig.subplots(nrows=1, ncols=1, sharex=False, sharey=False, squeeze=True, subplot_kw=None, gridspec_kw=None) #returns axes as ndarray




##Saving to a file
#output format is deduced from the extension of the filename
matplotlib.pyplot.savefig(file_name)


#understanding polyfit 
x = np.array([0.0, 1.0, 2.0, 3.0,  4.0,  5.0])
y = np.array([0.0, 0.8, 0.9, 0.1, -0.8, -1.0])

z = np.polyfit(x, y, 3)  #Polynomial coefficients, highest power first,0th index 
>>> z
array([ 0.08703704, -0.81349206,  1.69312169, -0.03968254])

>>> p = np.poly1d(z) #highest power first,0th index 
>>> print(p)
         3          2
0.08704 x - 0.8135 x + 1.693 x - 0.03968

>>> p(0.5)   #evaluate 
0.6143849206349179

>>> p.r #roots
array([6.24151464, 3.08128307, 0.02370685])
#+,-,*,**,/ are overloaded , np.methods() can be called 

>> p**2
poly1d([ 7.57544582e-03, -1.41607878e-01,  9.56497928e-01, -2.76158982e+00,
       2.93122393e+00, -1.34374738e-01,  1.57470396e-03])
>> np.sin(p)
array([ 0.08692719, -0.72669053,  0.99252758, -0.03967213])


#High-order polynomials may oscillate wildly:
p30 = np.poly1d(np.polyfit(x, y, 30))
>>> p30(4)
-0.80000000000000204

##HandsON - Create equal spaced 100 points between -2 and 6 and 
#then plot above p and p30 graphs for those x points 

#plot 
import matplotlib.pyplot as plt
xp = np.linspace(-2, 6, 100)
_ = plt.plot(x, y, '.', xp, p(xp), '-', xp, p30(xp), '--')
plt.ylim(-2,2)
plt.show()





##3D plots 
#3D plots require x,y (create from meshgrid) and Z 
#Z points are mapped to color  from ColorMap 
#https://matplotlib.org/gallery/color/colormap_reference.html


from matplotlib import cm 
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.axes3d import Axes3D
import numpy as np

X = np.arange(-5, 5, 0.25)
Y = np.arange(-5, 5, 0.25)
X, Y = np.meshgrid(X, Y)
R = np.sqrt(X**2 + Y**2)
Z = np.sin(R)



fig = plt.figure(figsize=(10,6))
ax1 = fig.add_subplot(141, projection='3d')  #requires Axes3D
#rstride 	Array row stride (step size)
#cstride 	Array column stride (step size)
surf = ax1.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=cm.coolwarm, linewidth=0, antialiased=False)
ax1.set_zlim(-1.01, 1.01)
# Add a color bar which maps values to colors.
fig.colorbar(surf, shrink=0.5, aspect=10)



##Mesh graph 
ax2 = fig.add_subplot(142) 
surf2 = ax2.pcolormesh(X, Y, Z, cmap=cm.ocean, alpha=0.2)


##Contour graph 
#contourf() differs from the MATLAB version in that it does not draw the polygon edges. 
#To draw edges, add line contours with calls to contour().


#If an int n, use n data intervals; i.e. draw n+1 contour lines. The level heights are automatically chosen.
ax3 = fig.add_subplot(143) 
surf3 = ax3.contourf(X, Y, Z, levels=[-.25,0,.25], cmap=cm.Dark2, alpha=0.2)
ax3.set_ylim(-5,5)
ax3.set_xlim(-5,5)

ax4 = fig.add_subplot(144) 
surf3 = ax4.contour(X, Y, Z, levels=[-.25,0,.25], cmap=cm.Dark2, alpha=0.2)

plt.show()

#Other 3D plots 
#https://matplotlib.org/mpl_toolkits/mplot3d/api.html
#https://matplotlib.org/mpl_toolkits/mplot3d/tutorial.html#wireframe-plots

#Example wireframe plot 


def get_test_data(delta=0.05):
    from matplotlib.mlab import  bivariate_normal
    x = y = np.arange(-3.0, 3.0, delta)
    X, Y = np.meshgrid(x, y)
    Z1 = bivariate_normal(X, Y, 1.0, 1.0, 0.0, 0.0)
    Z2 = bivariate_normal(X, Y, 1.5, 0.5, 1, 1)
    Z = Z2 - Z1
    X = X * 10
    Y = Y * 10
    Z = Z * 500
    return X, Y, Z

from mpl_toolkits.mplot3d import axes3d
import matplotlib.pyplot as plt
import numpy as np

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
x, y, z = get_test_data(0.05)
ax.plot_wireframe(x,y,z, rstride=2, cstride=2)
plt.show()

#Filled contour ie contourf
fig = plt.figure()
ax = fig.gca(projection='3d')
X, Y, Z = get_test_data(0.05)
ax.plot_surface(X, Y, Z, rstride=8, cstride=8, alpha=0.3)

#zdir 	The direction to use: x, y or z (default)
#offset if specified plot a projection of the filled contour on this position in plane normal to zdir
cset = ax.contourf(X, Y, Z, zdir='z', offset=-100, cmap=cm.coolwarm)
cset = ax.contourf(X, Y, Z, zdir='x', offset=-40, cmap=cm.coolwarm)
cset = ax.contourf(X, Y, Z, zdir='y', offset=40, cmap=cm.coolwarm)

ax.set_xlabel('X')
ax.set_xlim(-40, 40)
ax.set_ylabel('Y')
ax.set_ylim(-40, 40)
ax.set_zlabel('Z')
ax.set_zlim(-100, 100)

plt.show()




##Polar plot 
r = np.arange(0, 2, 0.01)
theta = 2 * np.pi * r

ax = plt.subplot(111, projection='polar')
ax.plot(theta, r)
ax.set_rmax(2)
ax.set_rticks([0.5, 1, 1.5, 2])  # less radial ticks
ax.set_rlabel_position(-22.5)  # get radial labels away from plotted line
ax.grid(True)

ax.set_title("A line plot on a polar axis", va='bottom')
plt.show()



##Advanced matplotlib 
##V0 
from PIL import Image 
import time
from functools import partial 


# drawing area 
center_x = -0.75
center_y = 0.0

delta_x_left, delta_x_right = -1.25, 1.75 
delta_y_left, delta_y_right = -1.5, 1.5 


# max iterations allowed 
maxIt = 512
# image size 
width = 512
height = 512

from numba import jit
import numpy as np 
import matplotlib.pyplot as plt 

@jit
def mandelbrot4(creal,cimag,maxiter):
    real = creal
    imag = cimag
    for n in range(maxiter):
        real2 = real*real
        imag2 = imag*imag
        if real2 + imag2 > 4.0:
            return n
        imag = 2* real*imag + cimag
        real = real2 - imag2 + creal       
    return 0  



@jit
def mandelbrot_set4(xmin,xmax,ymin,ymax,width,height,maxiter):
    #(start, stop, num)
    r1 = np.linspace(xmin, xmax, width)
    r2 = np.linspace(ymin, ymax,height)
    lst = np.empty(width*height, dtype=[('x', int), ('y', int),('z', int)])
    cnt = 0
    for i in range(width):
        for j in range(height):
            v = mandelbrot4(r1[i],r2[j],maxiter)
            lst[cnt] = (i, j, v) 
            cnt += 1
    return lst.tolist()  


    
def all_calculate(center_x,center_y):
    xmin,xmax = center_x + delta_x_left,  center_x + delta_x_right
    ymin, ymax = center_y+ delta_y_left,  center_y+delta_y_right 
    return xmin,xmax, ymin, ymax
    
def draw(ax,center_x,center_y, maxIt , width=width, height=height):
    ax.clear()
    xmin,xmax, ymin, ymax = all_calculate(center_x,center_y)            
    image = Image.new("RGB", (width, height)) 
    st = time.time()    
    pixels  = mandelbrot_set4(xmin,xmax,ymin,ymax,width,height,maxIt)    
    print("-"*40)
    print("time taken", time.time()-st, "seconds")
    for x,y,i in pixels:
        image.putpixel((x, y), (i % 4 * 64, i % 8 * 32, i % 16 * 16)) 
    ax.imshow(np.asarray(image), aspect="equal")#"auto"
    return None 

  


if __name__ == '__main__':
    fig, ax = plt.subplots()
    draw(ax, center_x,center_y, maxIt)
    plt.show()

##V1: WIth zoom effect 
from PIL import Image 
import time
from functools import partial 


# drawing area 
center_x = -0.75
center_y = 0.0

delta_x_left, delta_x_right = -1.25, 1.75 
delta_y_left, delta_y_right = -1.5, 1.5 


# max iterations allowed 
maxIt = 512
# image size 
width = 512
height = 512

#<- 
mag = 0  # number , 1,2,3....
#delta 
delta = 0.1      # delta for magnification (used for power)
mag_delta = 0.5  #delta for magnification when on click results 

#Click gives in Window cordinate 
#transform into our data cordinate 
def translate(value, leftMin, leftMax, rightMin, rightMax):
    leftSpan = leftMax - leftMin
    rightSpan = rightMax - rightMin
    valueScaled = float(value - leftMin) / float(leftSpan)
    return rightMin + (valueScaled * rightSpan)
    
#<-

from numba import jit
import numpy as np 
import matplotlib.pyplot as plt 

@jit
def mandelbrot4(creal,cimag,maxiter):
    real = creal
    imag = cimag
    for n in range(maxiter):
        real2 = real*real
        imag2 = imag*imag
        if real2 + imag2 > 4.0:
            return n
        imag = 2* real*imag + cimag
        real = real2 - imag2 + creal       
    return 0  



@jit
def mandelbrot_set4(xmin,xmax,ymin,ymax,width,height,maxiter):
    #(start, stop, num)
    r1 = np.linspace(xmin, xmax, width)
    r2 = np.linspace(ymin, ymax,height)
    lst = np.empty(width*height, dtype=[('x', int), ('y', int),('z', int)])
    cnt = 0
    for i in range(width):
        for j in range(height):
            v = mandelbrot4(r1[i],r2[j],maxiter)
            lst[cnt] = (i, j, v) 
            cnt += 1
    return lst.tolist()  


 
def all_calculate(center_x,center_y, mag, delta):
    #change here
    magnification = delta ** mag
    xmin,xmax = center_x + delta_x_left*magnification,  center_x + delta_x_right*magnification
    ymin, ymax = center_y+ delta_y_left*magnification,  center_y+delta_y_right*magnification 
    return xmin,xmax, ymin, ymax
    
def draw(ax,center_x,center_y, maxIt , mag, delta, width=width, height=height): #change here
    ax.clear()
    xmin,xmax, ymin, ymax = all_calculate(center_x,center_y, mag, delta)   #change here          
    image = Image.new("RGB", (width, height)) 
    st = time.time()    
    pixels  = mandelbrot_set4(xmin,xmax,ymin,ymax,width,height,maxIt)    
    print("-"*40)
    print("time taken", time.time()-st, "seconds")
    for x,y,i in pixels:
        image.putpixel((x, y), (i % 4 * 64, i % 8 * 32, i % 16 * 16)) 
    ax.imshow(np.asarray(image), aspect="equal")#"auto"
    return None 

#<- 
cid = None 

def calculate_mag(button, omag):
    if omag == 0 and button == 3: #right click, can not go below 0 
        return omag 
    if button == 1:  #left click 
        return omag + mag_delta
    if button == 2:   #middle click 
        return omag 
    if button == 3 :
        return omag - mag_delta
        
def onclick_gen(event, ax, center_x, center_y, mag, delta, maxIt, width,height):
    global cid 
    if event.inaxes:
        xmin,xmax, ymin, ymax = all_calculate(center_x,center_y, mag, delta)
        x,y = event.xdata, event.ydata  # this is part of width x height
        #convert to 
        x = translate(x, 0,width, xmin, xmax)
        y = translate(y,0, height, ymin, ymax)
        new_mag = calculate_mag(event.button, mag)
        plt.gcf().canvas.mpl_disconnect(cid)
        onclick = partial(onclick_gen, ax=ax, center_x=x,center_y=y, mag=new_mag, delta=delta, maxIt=maxIt,width=width,height=height)
        cid = plt.gcf().canvas.mpl_connect('button_press_event', onclick)
        draw(ax,x,y,  maxIt, new_mag , delta, width, height)
        plt.gcf().canvas.draw_idle()


#<-


if __name__ == '__main__':
    fig, ax = plt.subplots()
    #change here
    onclick = partial(onclick_gen, ax=ax, center_x=center_x,center_y=center_y, mag=mag, delta=delta, maxIt=maxIt,width=width,height=height)
    cid = plt.gcf().canvas.mpl_connect('button_press_event', onclick)
    draw(ax, center_x,center_y, maxIt,mag, delta,width, height) #change here
    plt.show()












###Dataframe manipulation using pandas 

df = pd.DataFrame(np.random.randn(6,4),index=list('abcdef'),columns=list('ABCD'))


##DataFrame Accessing 
df.column_name
    when column_name is string
    Only for accessing or update 
    Not for creation of new column, use df['column_name'] style 
    For index column, access always like df.index 
    
df.head()
df.tail()
df.index 
df.columns 
df.dtypes 
df.size #30
df.shpe #6,5
df.A 
#for update , in place 
df['A-1'] = df.A + df.C   
#new copy  
df.assign(AA= df.A + df.C, BB= lambda df: df.A + df.C    )

#all arithmatic operations possible  
df['A-1'] = df.A ** 2 
df['A-1'] = np.sqrt(df.A) 
 
#also at DF level , elementwise 
df + 1 
df + df 
1/df 
np.log(df)  #with Nan 
np.log(df).fillna(0) #all fill 
#or 
np.log(df).fillna({'A': np.mean(df.A)}) #only A column fill 

#fill all columns by A mean where df.A is null (might not be intended)
df11 = np.log(df)
df11[df11.A.isnull()] =  np.mean(df.A)

#but below OK , fill only those points in A by A mean 
df11 = np.log(df)
df11['A'][df11.A.isnull()]=  np.mean(df.A)

 
df[column]
    column can be 
        Single column label eg 'City'
        Array of column lables eg ['City', 'City']
        A boolean eg df[df.City == 'Chicago']
        A callable, fn(df):returns_any_from_above eg. df[lambda d: d.City == 'Chicago']
    Can be used for update dfi['C'] = dfi['A']
    
#df[column]
df['A']  #Series 
df[['A']  # DF 
df[['A', 'B']] 
df[ df['A'] >= 1.0] #DF  #all rows where df['A'] is >= 1.0 , True , rows includes all Column
df[lambda df: df['A'] >= 1.0]

df.query('A > B')
# same result as the previous expression  
df[df.A > df.B] 

df.where(df.A > df.B, 0) #Replace values by 0 (all columns) where the condition is False.
df.where(df.A > df.B) #Replace values by NaN(all columns) where the condition is False.
    

df[row_slice]
    row_slice can be 
        start:stop:step, stop exclusive 
        where start,stop are row index 
    But for DatetimeIndex, it's possible to access based on datetime index 
    
df[1:3]
df[1:3]['A']  #only A 
df['a':'c']   #based on index label , but index should be sorted one 
df.sort_index(level=0)
    
    
df.loc[row,column] 
    label based(both row and column)
    row,column takes 
        A single label, e.g. 5 or 'a', 
        A list or array of labels ['a', 'b', 'c']
        A slice object with labels 'a':'f' (end inclusive)
        A boolean array eg df.A > 0 
        :  means all 
        A Callable fn(df):returns_any_from_above eg. lambda d: d.A > 0 
        For DatetimeIndex, row can be as given in above example 
    Can be used for update eg dfi.loc[:,'C'] = dfi.loc[:,'A']
df.loc[row]
    equivalent to df.loc[row,:]
#label based    
df.loc['a' , :]  #Series of all COlumns 
df.loc['a']      #same as above 
df.loc[['a'] , :] #now DF of single row 
df.loc[: , 'A']   #Series of all rows of column A 
df.loc[: , ['A']]   #now DF of single column
df.loc['a', 'A']   #single cell 
df.loc[['a','b'], ['A','B']] 
df.loc[['a','b']] 
df.loc['a': 'c', 'A': 'C']  #inclusive index must be sorted
df.loc[df.A >=1.0, 'C']   #Series 
df.loc[df.A >=1.0, ['C']]  #now DF 
df.loc[lambda df: df.A >=1.0, 'C']
#update , LHS can have any of the above, RHS dimension must match 
df.loc[:,'C'] = df.loc[:,'A']


df.iloc[row,column] 
    index based(both row, column)
    row,column takes 
        An integer e.g. 5
        A list or array of integers [4, 3, 0]
        A slice object with ints 1:7:1 , end exclusive 
        A boolean array *** NOT IMPLEMENTED *** 
        :  means all 
        A Callable fn(df):returns_any_from_above eg. lambda d: d.A > 0 
    Can be used for update eg dfi.loc[:,'C'] = dfi.loc[:,'A']    
df.iloc[row]
    equivalent to df.iloc[row,:]
#Same with integer index  now   
df.iloc[0 , :]  #Series of all COlumns 
df.iloc[0]      #same as above 
df.iloc[[0] , :] #now DF of single row 
df.iloc[: , 0]   #Series of all rows of column A 
df.iloc[: , [0]]   #now DF of single column
df.iloc[0, 0]   #single cell 
df.iloc[[0,1], [0,1]] 
df.iloc[[0,1]] 
df.iloc[0: 3, 0: 3]  #inclusize
#below three not available 
#df.iloc[df.A >=1.0, 2]   #Series 
#df.iloc[df.A >=1.0, [2]]  #now DF 
#df.iloc[lambda df: df.A >=1.0, 2]
#update , LHS can have any of the above, RHS dimension must match 
df.iloc[:,2] = df.iloc[:,0]

   
df.ix[row,column] 
    For each of row,column ,at first tries label based like df.loc[] 
    if Fails, then tries index based like df.iloc[]
    If the index or column does not have label,then behaves like df.iloc[] always 
    For DatetimeIndex, row can be as given in above example 
df.ix[row]
    equivalent to df.ix[row,:]
    For DatetimeIndex, row can be as given in above example
#Firt label, then index 
#all .loc and iloc can be used exactly like above 
#but now can be mixed     
df.ix['a' , :]  #Series of all COlumns 
df.ix['a']      #same as above 
df.ix[[0] , :] #now DF of single row 
df.ix[: , 'A']   #Series of all rows of column A 
df.ix[: , [0]]   #now DF of single column
df.ix['a', 0]   #single cell 
df.ix[[0,1], ['A','B']] 
df.ix[[0,1]] 
df.ix['a': 'c', 0: 2]  #label inclusive, integer exclusive , index must be sorted
df.ix[df.A >=1.0, 2]   #Series 
df.ix[df.A >=1.0, ['C']]  #now DF 
df.ix[lambda df: df.A >=1.0, 2]
#update , LHS can have any of the above, RHS dimension must match 
df.ix[:,'C'] = df.ix[:,0]

df.iat[row_index,column_index]
df.at[row_label, column_label] 
    for accessing a cell 
df.at['a', 'A']
df.iat[0,0]  
    
df.xs(key, axis=0, level=None, drop_level=True)
    key : label or tuple of label
    Mainly for  for multiindex 
    
df.xs('a')  #rowwise , but a Series 
df.xs('A', axis=1) #closumnwise, but a series     
#Multiindex 
d = {'num_legs': [4, 4, 2, 2],
     'num_wings': [0, 0, 2, 2],
     'class': ['mammal', 'mammal', 'mammal', 'bird'],
     'animal': ['cat', 'dog', 'bat', 'penguin'],
     'locomotion': ['walks', 'walks', 'flies', 'walks']}     
df = pd.DataFrame(data=d)
#set level-0 class, level-1, animal, level-3 locomotion 
#Note length of each must be same 
df = df.set_index(['class', 'animal', 'locomotion'])
>>> df
                           num_legs  num_wings
class  animal  locomotion
mammal cat     walks              4          0
       dog     walks              4          0
       bat     flies              2          2
bird   penguin walks              2          2

#Get values at (level0, level1, level2), and that lavel is gone 
df.xs('mammal')
df.xs(('mammal', 'dog'))
#or give explicit via level=n or [n_or_label, ..]
df.xs('cat', level=1)
df.xs(('bird', 'walks'), level=[0, 'locomotion'])

#Get values at specified column and axis
df.xs('num_wings', axis=1)

#Only loc, and ix , not iloc, Note multiindex has to be based on label
df.loc[('mammal', 'cat', 'walks'), 'num_legs']
df.loc[('mammal', 'cat', 'walks')]
df.loc[('mammal', 'cat'), 'num_legs']
df.loc[('mammal', slice(None), 'walks'), 'num_legs'] #any animal 
df.loc[('mammal', 'cat', 'walks'):('mammal', 'bat', 'walks'), 'num_legs']

df.ix[('mammal', slice(None), 'walks'), [0,1]]
df.ix[('mammal', slice(None), 'walks'), 0]

#for slicing, index should be sorted one 
df.index.lexsort_depth #0 
df.sort_index(level=0)  #level-0 sorted , now depth should be 1 
df.sort_index(level=[0,1,2], inplace=True) #all levels are sorted now 
df.loc['bird':'mammal']
df.loc['bird':('mammal', 'bat', 'flies'), ['num_legs']]



    
##Datetime based indexing 
#Freq 
#check http://pandas.pydata.org/pandas-docs/stable/timeseries.html#offset-aliases for offset aliases, 
#note for multiple, you can give '5H' ie every 5th hour 
#check https://github.com/pandas-dev/pandas/blob/master/doc/source/timeseries.rst#id11        
#eg '2Q'  denotes two quarterly, '30min' means 30 min

#Weekly can take day to denote which day of week eg 'W-MON' means Monday of week
#Q can take Month eg 'Q-Feb' means every 2nd month of Q

#B,D,H,Min,S,MS,U,N can be combined eg '30min20s' means 30 min 20 second
#eg '2H20min30s' , '2D12H20Min30s'


#datetime based freq= 'M', 'D'(default), 'Y','YS','Q','W','H',
#'T'(min),'S'(sec),'ms','us', or n muliples eg "nH" or combination "xD yH zT"
#start is generally "yyymmdd" or "yyyDELIMmmDELIMdd" where DELIM is some deliminator 
dft = pd.DataFrame(np.random.randn(100000,1),columns=['A'],index=pd.date_range('20130101',periods=100000,freq='T')) 
ts = pd.Series(np.random.randn(100000), index=pd.date_range('20130101',periods=100000,freq='T'))

>>> dft.head()
                            A
2013-01-01 00:00:00  0.602450
2013-01-01 00:01:00 -2.708178
2013-01-01 00:02:00 -0.087823
2013-01-01 00:03:00  0.351917
2013-01-01 00:04:00 -0.231122

#Accessing 
dft.iloc[0:3]
dft.iloc[0:3, 0]
dft.iloc[0:3, [0]]

#for index based indexing 
from datetime import datetime
#For specific exact index for Only DF , use .loc[] 
dft['2013-01-01 00:00:00'] #ERROR 
dft[datetime(2013, 1, 1)] #equivalent to exact  #ERROR 

#use below 
dft.loc['2013-01-01 00:00:00']
dft.loc[datetime(2013, 1, 1)] 

#note for Series, below works 
ts['2013-01-01 00:00:00']
ts[datetime(2013, 1, 1)]
ts.loc[datetime(2013, 1, 1)]

#for both DF and Series- any partial date string or slice of exact index works 
dft['2013-01-01 00:00:00':'2013-01-01 00:04:00']
dft['2013-1-1']             #from 2013-01-01 00:00:00 till upto 2013-01-01 23:59:00
dft['2013']                 #Year based , from 2013-01-01 00:00:00 till upto 2013-03-11 10:39:00
dft['2013-1':'2013-2']      #slice, end inclusive 
dft['2013-1':'2013-2-28']   # stop time that includes all of the times on the last day
dft['2013-1':'2013-2-28 00:00:00'] #exact stop time     
dft[datetime(2013, 1, 1):datetime(2013,2,28)] #exact start and stop time 
dft[datetime(2013, 1, 1, 10, 12, 0):datetime(2013, 2, 28, 10, 12, 0)] #exact start and stop time 

dft.loc['2013', 'A']  
dft.loc['2013', ['A']]  

#Note 
ts[0] #first item , scalar 
#but 
dft[0] #error as for DF, [] includes column label 
dft['A'] #OK 
#but for slicing , works as it is row slicing 
ts[0:5]
dft[0:5]

###String, Datetime and categorical columns 

##If a DF's Column or Series or Index is of strings , check string methods 
df = pd.DataFrame({'A': ['cat', 'dog', 'bat']})
dir(df.A.str)
df.A.str.lower() #elementwise 
#other methods- similar to 'str' class 
#concatenation 
df['B'] = df.A 
df.A.str.cat(df.B, sep=':') #A and B values concatenated and returns a series 
df.A.str.cat(['1' for i in range(len(df.A))], sep='-')
df.A.str.cat(sep='-') #'cat-dog-bat'

#contains , match 
df.A.str.contains('c') #boolean series 
df.A.str.contains(r'c.{2}')
df.loc[df.A.str.contains(r'c.{2}'), 'B']
df.loc[df.A.str.match(r'cat|dog'), 'B']

#Extract - named group's name become column name 
df.A.str.extract(r'(?P<first>.)(?P<rest>.+)') #DF with two columns first, rest 

#get(index)
df.A.str.get(0)  #first char 

#findall 
df.A.str.findall(r'cat|dog')  #Series of result, note, result is list like str 
>>> df.A.str.findall(r'cat|dog')
0    [cat]
1    [dog]
2       []
Name: A, dtype: object
>>> df.A.str.findall(r'cat|dog').str.get(0)
0    cat
1    dog
2    NaN
#split, join 
>>> df.A.str.split("a")
0    [c, t]
1     [dog]
2    [b, t]
Name: A, dtype: object
>>> df.A.str.split("a").str.join(":")
0    c:t
1    dog
2    b:t
Name: A, dtype: object
#replace ,slice
df.A.str.replace(r'(\w+)', r'\1s')
df.A.str.slice(0,None,2) #0::2

#other 
str.capitalize() 	
str.center(width[, fillchar])
str.count(pat[, flags]) 	
str.decode(encoding[, errors]) 	
str.encode(encoding[, errors]) 	
str.endswith(pat[, na]) 	
str.find(sub[, start, end]) 	
str.get(i) 	
str.index(sub[, start, end]) 	
str.join(sep) 	
str.len() 	
str.ljust(width[, fillchar]) 	
str.lower() 	
str.lstrip([to_strip]) 	
str.normalize(form) 	
str.pad(width[, side, fillchar]) 	
str.repeat(repeats) 	
str.rfind(sub[, start, end]) 	
str.rindex(sub[, start, end]) 	
str.rjust(width[, fillchar]) 	
str.rstrip([to_strip]) 	
str.rsplit([pat, n, expand]) 	
str.startswith(pat[, na]) 	
str.strip([to_strip])
str.swapcase()
str.title()
str.upper()
str.isalnum()
str.isalpha()
str.isdigit()
str.isspace()
str.islower()
str.isupper()
str.istitle()
str.isnumeric()
Series.str.isdecimal()

##if a DF's Column or Series or Index is of datetime , check datetime methods 
dft = pd.DataFrame(np.random.randn(100000,1),columns=['A'],
    index=pd.date_range('20130101',periods=100000,freq='T')) 
dft = dft.reset_index() #old index would become a column 'index'
#note df.index and df['index'] are different 
dft.rename(columns={'index':'B'}, inplace=True)
dft.columns  #B,A

dir(dft.B.dt)

# .date, .time, .timetz, .year, .month, .day, .hour, .minute, .second, 
# .microsecond, .nanosecond, .week, .weekofyear, .dayofweek, .weekday, 
# .dayofyear, .quarter, .is_month_start, .is_month_end, .is_quarter_start, 
# .is_quarter_end, .is_year_start, .is_year_end, 
# .is_leap_year, .daysinmonth, .days_in_month, 
# .tz, .freq 	
dft.B.dt.hour #elementwise 
dft.B.dt.normalize()  #Convert times to midnight
dft.B.dt.strftime('%B %d, %Y, %r') #format 
#.floor(freq), .ceil(freq)
dft.B.dt.round('H') #Perform round operation on the data to the specified freq.



##if a DF's Column or Series or Index is of type categorical, check category method 
df = pd.DataFrame({'A': pd.Series(["a","b","c","a"], dtype="category"),
                'B': ['cat','cat','bat','bat']})
                
df['B']=df.B.astype('category')

dir(df.A.cat)
df.A.cat.categories   #Index(['a', 'b', 'c'], dtype='object')
df.A.cat.codes  #Seris of 0,1,2,0

df.A.cat.rename_categories([1,2,3]) #'a' by 1, so on , value gets changes 
df.A.cat.set_categories(['a','b'],ordered=True) #c would be Nan , Categories (2, object): [a < b]

df.A.cat.add_categories(['d']) #Categories (4, object): [a, b, c, d]
df.A.cat.add_categories(['d']).cat.remove_categories(['d']) #Categories (3, object): [a, b, c]
df.A.cat.add_categories(['d']).cat.remove_unused_categories()#Categories (3, object): [a, b, c]

df.A.cat.as_ordered()  #Categories (3, object): [a < b < c]
#now can be compared 
df.A.cat.as_ordered() > 'b' #False,False, True,False
df.A.cat.as_unordered() #Categories (3, object): [a, b, c]
df.A.cat.ordered  #False 
df.A.cat.reorder_categories(['b','c','a'], ordered=True)#Categories (3, object): [b < c < a]













##Creation 

pd.DataFrame([{'A':1, 'B':1},{'A':2, 'B':2}])
pd.DataFrame( np.array([[1,2],[3,4]]), columns=['A', 'B'])
pd.DataFrame([[1,2],[3,4]], columns=['a','b'])
df = pd.DataFrame({'A': [1,2,3], 'B':[1,2,3]})
df.head()

#For conversion use, pd.to_numeric(arg), pd.to_datetime(arg, ,format='%Y %m %d'), 
#pd.to_timedelta(arg, unit='ns')
df1 = pd.DataFrame({'A': ['1', '2'], 'B':['20181231', '20180304'],
                     'C': [10000, 10000]})

                     #new column creation and accessing 
df1['AA'] = pd.to_numeric(df1.A)
df1['BB'] = pd.to_datetime(df1.B ,format='%Y%m%d')
df1['CC'] = pd.to_timedelta(df1.C, unit='ns')

#drop a column 
df1.drop('C', inplace=True, axis=1) #axis=0, for row, axis=0 for column 
df1.drop(0,  axis=0)  #0th row 

#rename 
df1.rename(columns={'CC': 'C'}, inplace=True)
#rename index 
df1.index 
df1.index  = [10,20]
#or
df1.index = [0,1]
df1r = df1.rename({0:20, 1:30}, axis='index')

#creation of new row and column, if existing in earlier, get value from earlier 
#else, put Nan or fill_value 
>>> df1
   A         B  AA               C         BB
0  1  20181231   1 00:00:00.000010 2018-12-31
1  2  20180304   2 00:00:00.000010 2018-03-04
#creation of two new row, 10,20 and one column 'a'
df1.reindex(index=[10,20,0,1], columns=['A', 'B', 'a'])
df1.reindex(index=[10,20,0,1], columns=['A', 'B', 'a'], fill_value=0)


#rename all columns name s
cols = df1.columns.tolist()
n_cols = {c: c + "1" for c in cols}
df11 = df1.rename(columns=n_cols)

#copy and append 
df2 = df1.copy()
df3 = pd.concat([df1,df2], axis=0) #rowwise stack 
df3 = pd.concat([df1,df2], axis=0).reset_index() #reseting index 
df3 = pd.concat([df1,df2], axis=0, ignore_index=True) #reseting index 
#or 
df2.append(df1)    #index copied 
df2.append(df1, ignore_index=True) #equivlent to reset_index

df4 = pd.concat([df1,df11], axis=1)  #columnwise stack for same index
df5 = pd.concat([df1,df1r], axis=1) #creates Nan
df5.columns =list( "ABCDEFGHIJ") #change column names(earlier has dumplicates

#dropna, fillna , inplace=False 
df5.dropna(axis=0, how='all') #row wise, if row consists of 'all' or 'any' Nan
df5.dropna(axis=0, how='any')
df5.dropna(axis=1, how='any')  #columnwise 

df5.fillna(0)   #nan by 0 
df5.fillna({'A': 0})   #only A



#replace 
df1.replace('1', 20)  #one valye by one value 
df1.replace({'A':'1'}, 20) #only for A 
df1.replace({'A':{'1':20}})  #Only for A, '1'
df1.replace({'A':'1'}, {'A':20}) #Another way 
df1.replace(['1','2'], 20) #multiple values 
df1.replace(['1','2'], [20,30])

#map(only for series, convert one value to other)
df1.A.map({'1': 'cat', '2':'dog'}) #missing  = Nan 
#or takes a fun (each element)
df1.A.map(lambda e: 'cat', na_action='ignore') #NaN values would not be passed to fn 

#apply for Series(fn takes each element) 
df1.A.apply(lambda e: len(e))
#or fn takes an ufunc 
df1.AA.apply(np.log)

df1.AA.apply(str)
#or
df1.AA.astype('str')
df1.A.astype(np.float64) #conversion 
df1[['A', 'A']].astype(np.float64) #works with DF as well 

#applymap:DF (fn takes each element)
df1[['A','B']].applymap(lambda e: len(e))

#apply: DF(fn = ufunc takes full Series/columns)
df1[['A','B']]
df1[['A','B']].apply(lambda col : len(col)) #column wise , ie get each column value
df1[['A','B']].apply(lambda col : len(col), axis=1) #rowwise, ie get each row value 

df1[['AA', 'AA']].apply(np.sum)  #columnwise 
df1[['AA', 'AA']].apply(np.sum, axis=1) #rowwise  

#threeways - replace 
df5 = pd.DataFrame({'A':[0, np.nan, 0, np.nan], 'B':[np.nan, 0, np.nan, 0]})
df5.fillna({'A': 0})
df5.replace({'A':{np.nan:0}})
df5.loc[df5.A.isnull(), 'A'] = 0



##Lets check complex Operations 


##DF - Database-style DataFrame merging
DataFrame.join(other, on=None, how='left', lsuffix='', rsuffix='', sort=False)
    Join : this DF's index or column(if 'on' given) with 'other' index 
    Note, other index must be having same value of 'this' index/'on'
    lsuffix, rsuffix are used if both contain same columns 
pandas.merge(left, right, how='inner', on=None, left_on=None, right_on=None,      
        left_index=False, right_index=False, sort=True,      
        suffixes=('_x', '_y'), copy=True, indicator=False)
DataFrame.merge(right, how='inner', on=None, left_on=None, right_on=None, 
        left_index=False, right_index=False, sort=False, suffixes=('_x', '_y'), copy=True, indicator=False, validate=None)
    column name - on (same in both), left_on, right_on 
    or with index , left_index, right_index. Note index must have same value of key column
    how : {'left', 'right', 'outer', 'inner'}, default 'inner'

>>> A              >>> B
    lkey value        rkey value
0   foo  1            foo  5
1   bar  2            bar  6
2   baz  3            qux  7
3   foo  4            bar  8
#read above and split 
df = pd.read_clipboard() #lkey  value rkey  value.1
A = df.iloc[:,[0,1]]
B = df.iloc[:, [2,3]]
B.columns= [ B.columns[0], 'value'] #rename 
>>> A
  lkey  value
0  foo      1
1  bar      2
2  baz      3
3  foo      4
>>> B
  rkey  value
0  foo      5
1  bar      6
2  qux      7
3  bar      8
#default inner , means both key column/index value must be same 
#note for below index-column joining, one can use 'join' as well 
>>> pd.merge(A, B,  left_on='value',right_index = True) #left column 'value' == right index
   value lkey  value_x rkey  value_y
0      1  foo        1  bar        6
1      2  bar        2  qux        7
2      3  baz        3  bar        8


>>> A.merge(B, left_index=True, right_index=True) #index joining 
  lkey  value_x rkey  value_y
0  foo        1  foo        5
1  bar        2  bar        6
2  baz        3  qux        7
3  foo        4  bar        8
>>> A.merge(B, left_index=True, right_index=True, how='outer')#does not matter 
  lkey  value_x rkey  value_y
0  foo        1  foo        5
1  bar        2  bar        6
2  baz        3  qux        7
3  foo        4  bar        8
>>> A.merge(B, left_on='lkey', right_on='rkey', how='outer') #column joining 
   lkey  value_x  rkey  value_y
0  foo   1        foo   5
1  foo   4        foo   5
2  bar   2        bar   6
3  bar   2        bar   8
4  baz   3        NaN   NaN
5  NaN   NaN      qux   7
>>> A.merge(B, left_on='lkey', right_on='rkey', how='inner')
  lkey  value_x rkey  value_y
0  foo        1  foo        5
1  foo        4  foo        5
2  bar        2  bar        6
3  bar        2  bar        8
>>> A.merge(B, left_on='lkey', right_on='rkey', how='left')
  lkey  value_x rkey  value_y
0  foo        1  foo      5.0
1  bar        2  bar      6.0
2  bar        2  bar      8.0
3  baz        3  NaN      NaN
4  foo        4  foo      5.0
>>> A.merge(B, left_on='lkey', right_on='rkey', how='right')
  lkey  value_x rkey  value_y
0  foo      1.0  foo        5
1  foo      4.0  foo        5
2  bar      2.0  bar        6
3  bar      2.0  bar        8
4  NaN      NaN  qux        7




#Example multiple key 
left = pd.DataFrame({'key1': ['K0', 'K0', 'K1', 'K2'],                      
        'key2': ['K0', 'K1', 'K0', 'K1'],                     
        'A': ['A0', 'A1', 'A2', 'A3'],                     
        'B': ['B0', 'B1', 'B2', 'B3']})
right = pd.DataFrame({'key1': ['K0', 'K1', 'K1', 'K2'],                      
        'key2': ['K0', 'K0', 'K0', 'K0'],                        
        'C': ['C0', 'C1', 'C2', 'C3'],                         
        'D': ['D0', 'D1', 'D2', 'D3']}) 
#multiple keys 
result = pd.merge(left, right, on=['key1', 'key2'])
>>> result
    A   B key1 key2   C   D
0  A0  B0   K0   K0  C0  D0
1  A2  B2   K1   K0  C1  D1
2  A2  B2   K1   K0  C2  D2

# With The merge indicator
>>> pd.merge(left, right, on=['key1', 'key2'], indicator=True)
    A   B key1 key2   C   D _merge
0  A0  B0   K0   K0  C0  D0   both
1  A2  B2   K1   K0  C1  D1   both
2  A2  B2   K1   K0  C2  D2   both




###More Replace 
#Note you can use .replace(to_repace, value) as well where to_replace could be np.nan 
df = pd.DataFrame({'A': [0, 1, 2, 3, 4],
                   'B': [5, 6, 7, 8, 9],
                    'C': ['a', 'b', 'c', 'd', 'e']})
>>> df.replace(0, 5) #0 by 5 
   A  B  C
0  5  5  a
1  1  6  b
2  2  7  c
3  3  8  d
4  4  9  e

#replace [0, 1, 2, 3] by 4 
>>> df.replace([0, 1, 2, 3], 4)
   A  B  C
0  4  5  a
1  4  6  b
2  4  7  c
3  4  8  d
4  4  9  e
#Replace 0 by 4 , 1 by 3, 2 by 2 and 3 by 1 
>>> df.replace([0, 1, 2, 3], [4, 3, 2, 1])
   A  B  C
0  4  5  a
1  3  6  b
2  2  7  c
3  1  8  d
4  4  9  e
#replace 0 by 10 and 1 by 100 
>>> df.replace({0: 10, 1: 100})
     A  B  C
0   10  5  a
1  100  6  b
2    2  7  c
3    3  8  d
4    4  9  e
#Replace column A , 0 by 100 and column B 5 by 100 
>>> df.replace({'A': 0, 'B': 5}, 100)
     A    B  C
0  100  100  a
1    1    6  b
2    2    7  c
3    3    8  d
4    4    9  e
#Replace column A , 0 by 100 and column B 5 by 500 
>>> df.replace({'A': 0, 'B': 5}, {'A': 100, 'B': 500})
     A    B  C
0  100  100  a
1    1    6  b
2    2    7  c
3    3    8  d
4    4    9  e
#replace column A, 0 by 100 and 4 by 400 
>>> df.replace({'A': {0: 100, 4: 400}})
     A  B  C
0  100  5  a
1    1  6  b
2    2  7  c
3    3  8  d
4  400  9  e

#with regular expression , regex=True 
df = pd.DataFrame({'A': ['bat', 'foo', 'bait'],
            'B': ['abc', 'bar', 'xyz']})
#            
>>> df.replace(to_replace=r'^ba.$', value='new', regex=True)
      A    B
0   new  abc
1   foo  new
2  bait  xyz
#only for column A
>>> df.replace({'A': r'^ba.$'}, {'A': 'new'}, regex=True)
      A    B
0   new  abc
1   foo  bar
2  bait  xyz

>>> df.replace(regex=r'^ba.$', value='new')
      A    B
0   new  abc
1   foo  new
2  bait  xyz
>>> df.replace(regex={r'^ba.$': 'new', 'foo': 'xyz'})
      A    B
0   new  abc
1   xyz  new
2  bait  xyz

>>> df.replace(regex=[r'^ba.$', 'foo'], value='new')
      A    B
0   new  abc
1   new  new
2  bait  xyz



##Transform 
DataFrame.transform(func, *args, **kwargs)
    func : callable, string, dictionary, or list of string/callables    
        Function would take each column (as Series) one by one 
        so inside function, you can not access other columns of the df 
        args and kwargs would be passed to function 
        Accepted Combinations are:
            •string function name
            •function
            •list of functions
            •dict of column names -> functions (or list of functions)

#Examples
df = pd.DataFrame(np.random.randn(10, 3), columns=['A', 'B', 'C'],
            index=pd.date_range('1/1/2000', periods=10))
            
df1 = df.copy()      
df.iloc[3:7] = np.nan
>>> df.transform(lambda x: (x - x.mean()) / x.std()) #x is each column 
                   A         B         C
2000-01-01  0.579457  1.236184  0.123424
2000-01-02  0.370357 -0.605875 -1.231325
2000-01-03  1.455756 -0.277446  0.288967
2000-01-04       NaN       NaN       NaN
2000-01-05       NaN       NaN       NaN
2000-01-06       NaN       NaN       NaN
2000-01-07       NaN       NaN       NaN
2000-01-08 -0.498658  1.274522  1.642524
2000-01-09 -0.540524 -1.012676 -0.828968
2000-01-10 -1.366388 -0.614710  0.005378


df1.transform(np.log) #each column by np.log 
(-df1).transform('abs')  #string function , must exist on Series/column 
df22 = df1.transform([np.log, 'abs']) #column is now multiindex, A,(log,abs)
df22.loc[:, ('A', 'log')]
df1.transform({'A': np.log, 'B': 'abs'})
#with arg 
df1.transform(lambda c, b : c-b , b=3)  #lambda function gets Series 




##GroupBy 
DataFrame.groupby(by=None, axis=0, level=None, as_index=True, sort=True, group_keys=True, squeeze=False, **kwargs)
    by can be 
        • [g1,g1..,g2,g2] or NumPy array of the same length as the selected axis
        •A dict providing a label -> group name mapping
        •For DataFrame objects, a string indicating a column to be used to group. 
         df.groupby('A') is just syntactic sugar for df.groupby(df['A']), 
        •For DataFrame objects, a column label(axis=0) or index label(axis=1)
        •A list of any of the above things
    axis : default 0, Split along rows/columnwise (0) or columns/rowwise (1)
    
DataFrameGroupBy.agg(arg, *args, **kwargs)
    fun gets each column (excluding grouped column)
    for each unique grouped column  
    Hence func can not access other column for that dataframe 
    Note result is dataframe(including grouped column) hence all data frame's methods can be applied 
    func : Accepted Combinations are:
        •string function name
        •function
        •list of functions
        •dict of column names -> functions (or list of functions)        
DataFrameGroupBy.manyMethods....
    check dir(g)    
g['colName']
    accessing that column's SeriesGroupBy object from whole GroupBy object 
#Rule of thumbs 
•if we want to get a single value for each group -> use aggregate()
•if we want to get a subset of the input rows -> use filter()
•if we want to get a new value for each input row -> use transform()

##String acceptable for apply 
_common_apply_whitelist = frozenset([
    'last', 'first',
    'head', 'tail', 'median',
    'mean', 'sum', 'min', 'max',
    'cumcount', 'ngroup',
    'resample',
    'rank', 'quantile',
    'fillna',
    'mad',
    'any', 'all',
    'take',
    'idxmax', 'idxmin',
    'shift', 'tshift',
    'ffill', 'bfill',
    'pct_change', 'skew',
    'corr', 'cov', 'diff',
]) | _plotting_methods

_series_apply_whitelist = ((_common_apply_whitelist |
                            {'nlargest', 'nsmallest'}) -
                           {'boxplot'}) | frozenset(['dtype', 'unique'])

_dataframe_apply_whitelist = ((_common_apply_whitelist |
                              frozenset(['dtypes', 'corrwith'])) -
                              {'boxplot'})

##String acceptable for transforms                       
_cython_transforms = frozenset(['cumprod', 'cumsum', 'shift',
                                'cummin', 'cummax'])
                                
##String acceptable for aggregate                          
'aggregate': {
            'add': 'group_add',
            'prod': 'group_prod',
            'min': 'group_min',
            'max': 'group_max',
            'mean': 'group_mean',
            'median': {
                'name': 'group_median'
            },
            'var': 'group_var',
            'first': {
                'name': 'group_nth',
                'f': lambda func, a, b, c, d, e: func(a, b, c, d, 1, -1)
            },
            'last': 'group_last',
            'ohlc': 'group_ohlc',
        },
        
#Example 
df = pd.DataFrame({'Animal' : ['Falcon', 'Falcon','Parrot', 'Parrot'],
                       'Type' : ['fast', 'fast', 'slow', 'slow'],
                    'Max Speed' : [380., 370., 24., 26.]})

g = df.groupby('Animal')
dir(g)

#many methods 
g.mean()
#or 
g.agg('mean')
#or 
g.agg(np.mean)

#get SeriesGroupBy
g['Type'].size() 
g['Type'].agg(np.size)  #count for each , result Series 
g['Type'].agg(np.size).shape  #hence all Series methods can be used 
g['Type'].agg(np.size)['Falcon']
g.agg(np.size)  #results DF 
g.agg(np.size).iloc[0,0] #hence all DF methods can be used 

g.groups   #{'Falcon': Int64Index([0, 1], dtype='int64'), 'Parrot': Int64Index([2, 3], dtype='int64')}
g.groups['Falcon'].tolist() #[0,1] , rowindexes for this group
#same in ndarray 
g.indices #{'Falcon': array([0, 1], dtype=int64), 'Parrot': array([2, 3], dtype=int64)}
g.ngroups #2

#Axis=1 or with by as list 
df = pd.DataFrame([['a','a','b','b','c','d', 'c'],
        [1, 3, 5, 7, 9, 2, 4]], index=["alpha", "val"])
>>> df
       0  1  2  3  4  5  6
alpha  a  a  b  b  c  d  c
val    1  3  5  7  9  2  4

>>> df.T.groupby('alpha').val.sum()
alpha
a     4
b    12
c    13
d     2

#for axis=1, specy row by df.loc 
>>> df.groupby(df.loc['alpha'], axis=1).agg(np.sum)
alpha   a   b   c  d
alpha  aa  bb  cc  d
val     4  12  13  2

#with list/Series 
>>> df.loc['val'].groupby(df.loc['alpha']).sum()
alpha
a     4
b    12
c    13
d     2
Name: val, dtype: int64


#AGG Examples
df = pd.DataFrame({'A': [1, 1, 2, 2],
                    'B': [1, 2, 3, 4],
                    'C': np.random.randn(4)})
>>> df
   A  B         C
0  1  1  0.362838
1  1  2  0.227877
2  2  3  1.267767
3  2  4 -0.562860

#string function name, function must exist on Series 
>>> df.groupby('A').agg('min')
   B         C
A
1  1  0.227877
2  3 -0.562860
#function
>>> df.groupby('A').agg(np.min)
   B         C
A
1  1  0.789346
2  3 -1.127935

#List of string/function names , Column label is MultiIndex (B, min),...
df.groupby('A').agg(['min', 'max'])
>>> df.groupby('A').agg([np.min, np.max])
    B             C
  min max       min       max
A
1   1   2  0.227877  0.362838
2   3   4 -0.562860  1.267767

#.columnName gives SeriesGroupBy object, which has similar methods 
>>> df.groupby('A').B.agg(['min', 'max'])
   min  max
A
1    1    2
2    3    4

#dict of column names -> functions (or list of functions)      
>>> df.groupby('A').agg({'B': ['min', 'max'], 'C': 'sum'})
    B             C
  min max       sum
A
1   1   2  0.590716
2   3   4  0.704907




GroupBy.apply(func, *args, **kwargs)
    func takes grouped DF(including grouped column) and args, kwrgs 
    and return a dataframe, a series or a scalar. 
    Hence func can access other column for that dataframe 
#In the current implementation apply calls func twice on the first group to decide 
#whether it can take a fast or slow code path. 

#Examples
df = pd.DataFrame({'A': 'a a b'.split(), 'B': [1,2,3], 'C': [4,6, 5]})
>>> df
   A  B  C
0  a  1  4
1  a  2  6
2  b  3  5

>>> df._get_numeric_data()
   B  C
0  1  4
1  2  6
2  3  5
#understand max 
>>> df[['B', 'C']]
   B  C
0  1  4
1  2  6
2  3  5
>>> df[['B', 'C']].max()  #columnwise 
B    3
C    6
dtype: int64

>>> df[['B', 'C']].max(axis=1) #rowwise 
0    4
1    6
2    5
dtype: int64

#Example 
g = df.groupby('A')
#fn takes full DF inc grouped columns , exclude A
>>> g.apply(lambda df: df._get_numeric_data() / df._get_numeric_data().sum())  #divided by full grouped DF sum 
          B    C
0  0.333333  0.4
1  0.666667  0.6
2  1.000000  1.0

#Returns Series , df.max() is each column's max 
>>> g.apply(lambda df: df._get_numeric_data().max() - df._get_numeric_data().min())
   B  C
A
a  1  2
b  0  0

#returns scalar 
>>> g.apply(lambda x: x.C.max() - x.B.min())
A
a    5
b    2
dtype: int64


GroupBy.transform(func, *args, **kwargs)
    func : callable, string, dictionary, or list of string/callables    
        Function would take each column (as Series) of each group one by one 
        (excluding grouped column), hence can not access other columns in function 
        Accepted Combinations are:
            •string function name
            •function
            •list of functions
            •dict of column names -> functions (or list of functions)
    
#Example 
df = pd.read_clipboard()
    A      B         C         D
0  foo    one  0.162003  0.087469
1  bar    one -1.156319 -1.526272
2  foo    two  0.833892 -1.666304
3  bar  three -2.026673 -0.322057
4  foo    two  0.411452 -0.954371
5  bar    two  0.765878 -0.095968
6  foo    one -0.654890  0.678091
7  foo  three -1.789842 -1.130922

#x is each column for that group 
zscore = lambda x: (x - x.mean()) / x.std() # Note that it does not reference anything outside of 'x' and for transform 'x' is one column.
#B is ignored 
>>> df.groupby('A').transform(zscore) #for each column of each group 
       C      D
0  0.989  0.128
1 -0.478  0.489
2  0.889 -0.589
3 -0.671 -1.150
4  0.034 -0.285
5  1.149  0.662
6 -1.404 -0.907
7 -0.509  1.653


#Create a column with sum of C for each group of A 
df['sum_C'] = df.groupby('A')['C'].transform(np.sum)
# to clearly see the scalar ('sum') applies to the whole column of the group
df.sort_values('A') 
#Output 
     A      B         C         D     sum_C
1  bar    one -1.156319 -1.526272 -2.417114
3  bar  three -2.026673 -0.322057 -2.417114
5  bar    two  0.765878 -0.095968 -2.417114
0  foo    one  0.162003  0.087469 -1.037385
2  foo    two  0.833892 -1.666304 -1.037385
4  foo    two  0.411452 -0.954371 -1.037385
6  foo    one -0.654890  0.678091 -1.037385
7  foo  three -1.789842 -1.130922 -1.037385



#HandsON- Example 
df = pd.read_excel("tobeShared/data/sales_transactions.xlsx")
>>> df.groupby('order').mean()
        account  quantity  unit price  ext price
order
10001  383080.0      7.00   30.266667   192.0400
10005  412290.0     31.60   53.264000  1637.0980
10006  218895.0     14.25   65.672500   931.1225
>>> df.groupby('order')["ext price"].mean() #returntype is Series
order
10001     192.0400
10005    1637.0980
10006     931.1225
Name: ext price, dtype: float64
>>> df.groupby('order')[["ext price"]].mean() #return type ise Dataframe 
       ext price
order
10001   192.0400
10005  1637.0980
10006   931.1225


#Q= "What percentage of the order total does each order represent?"
>>> df.groupby('order')["ext price"].transform('sum')
0      576.12
1      576.12
2      576.12
3     8185.49
4     8185.49
5     8185.49
6     8185.49
7     8185.49
8     3724.49
9     3724.49
10    3724.49
11    3724.49
Name: ext price, dtype: float64

df["Order_Total"] = df.groupby('order')["ext price"].transform('sum')
df["Percent_of_Order"] = df["ext price"] / df["Order_Total"]

##Another example 
import pyowm  #Weather API

owm = pyowm.OWM('d86ca3beb3c8bf8cce8409a0da74b4c9')  # You MUST provide a valid API key
#3hrs 5 days forecast(40 data points) - free 
fc = owm.three_hours_forecast('HYDERABAD,IN')
f = fc.get_forecast()
lst = f.get_weathers() #list of 'pyowm.weatherapi25.weather.Weather'
>>> lst[0].get_reference_time('iso')
'2019-03-27 18:00:00+00'
>>> lst[0].get_temperature()
{'temp_max': 300.17, 'temp_kf': 5.81, 'temp_min': 294.358, 'temp': 300.17}
>>> lst[0].get_detailed_status()
'clear sky'
>>> lst[0].to_JSON()  #temp in kelvin 
'{"pressure": {"press": 1013.11, "sea_level": 1013.11}, "reference_time": 1553709600, "humidity": 79, "humidex": null, "sunrise_time": 0, "clouds": 0, "status": "Clear", "detailed_status": "clear sky", "temperature": {"temp_max": 300.17, "temp_kf": 5.81, "temp_min": 294.358, "temp": 300.17}, "snow": {}, "sunset_time":0, "wind": {"speed": 1.21, "deg": 103.503}, "weather_icon_name": "01n", "heat_index": null, "weather_code": 800, "rain": {}, "dewpoint": null, "visibility_distance": null}'

pd_input= [ {'date': w.get_reference_time('iso'), 'text':w.get_detailed_status(), 'min_temp':w.get_temperature()['temp_min'], 'max_temp':w.get_temperature()['temp_max'],}      for w in lst]

import pandas as pd 
import numpy as np 

df = pd.DataFrame(pd_input)
df.index = pd.to_datetime(df.date)
from pandas.tseries.offsets import *
df.index.freq = Hour()*3
df = df.drop(['date'], axis=1)
dft_s = df.resample('D')
dft_s.agg({'min_temp':'min', 'max_temp':'max', 'text': 'first'})
#or apply may get Series for internal purpose , ignore those 
def apply_func(df):
    if type(df) is pandas.core.frame.DataFrame:
        min_temp = df.min_temp.min()
        max_temp = df.max_temp.max()
        text = ",".join(list(set(df.text.tolist())))
        return pd.DataFrame(dict(min_temp=min_temp, max_temp=max_temp,text=text))
    else :
        return df.max()

dft_s.apply(lambda df: (print(df,type(df)),df)[-1])
dft_s.apply(apply_func)
>>> dft.reset_index().to_json(orient='records', date_format='iso')
'[{"date":"2019-03-27T00:00:00.000Z","max_temp":300.17,"min_temp":294.358,"text":"clear sky"},{"date":"2019-03-28T00:00:00.000Z","max_temp":308.427,"min_temp":308.427,"text":"clear sky"},{"date":"2019-03-29T00:00:00.000Z","max_temp":309.645,"min_temp":309.645,"text":"light rain"},{"date":"2019-03-30T00:00:00.000Z","max_temp":310.223,"min_temp":310.223,"text":"clear sky"},{"date":"2019-03-31T00:00:00.000Z","max_temp":310.368,"min_temp":310.368,"text":"scattered clouds"},{"date":"2019-04-01T00:00:00.000Z","max_temp":310.413,"min_temp":310.413,"text":"scattered clouds"}]'
>>> dft.reset_index().to_dict(orient='records')
[{'min_temp': 294.358, 'max_temp': 300.17, 'date': Timestamp('2019-03-27 00:00:00'), 'text': 'clear sky'}, {'min_temp': 308.427, 'max_temp': 308.427, 'date': Timestamp('2019-03-28 00:00:00'), 'text': 'clear sky'}, {'min_temp': 309.645, 'max_temp': 309.645, 'date': Timestamp('2019-03-29 00:00:00'), 'text': 'light rain'}, {'min_temp': 310.223, 'max_temp': 310.223, 'date': Timestamp('2019-03-30 00:00:00'), 'text': 'clear sky'}, {'min_temp': 310.368, 'max_temp': 310.368, 'date':Timestamp('2019-03-31 00:00:00'), 'text': 'scattered clouds'}, {'min_temp': 310.413, 'max_temp': 310.413, 'date': Timestamp('2019-04-01 00:00:00'), 'text': 'scattered clouds'}]


#Other methods 
DataFrameGroupBy.filter(func, dropna=True, *args, **kwargs)
    Return a copy of a DataFrame excluding elements from groups 
    that do not satisfy the boolean criterion specified by func.
    Parameters:
        f : function
            Function to apply to each subframe. Should return True or False.
            f takes full DF including grouped column
        dropna : Drop groups that do not pass the filter. True by default;
            if False, groups that evaluate False are filled with NaNs.
    Returns:
    filtered : DataFrame 


#Example 
import pandas as pd
df = pd.DataFrame({'A' : ['foo', 'bar', 'foo', 'bar',
                          'foo', 'bar'],
                   'B' : [1, 2, 3, 4, 5, 6],
                   'C' : [2.0, 5., 8., 1., 2., 9.]})
grouped = df.groupby('A')
>>> grouped.filter(lambda df: df['B'].mean() > 3.)
     A  B    C
1  bar  2  5.0
3  bar  4  1.0
5  bar  6  9.0


GroupBy.pipe(func, *args, **kwargs)
    Apply a function with arguments to this GroupBy object,
    Parameters:
    func : callable 
    Note function gets full groupedBy dataframe with it's groupby column as index 
 
#Use .pipe when chaining together functions that expect Series, DataFrames or GroupBy objects. 
#Instead of writing
>>> f(g(h(df.groupby('group')), arg1=a), arg2=b, arg3=c)
#You can write
>>> (df
        .groupby('group')
        .pipe(f, arg1)
        .pipe(g, arg2)
        .pipe(h, arg3))
        
#Example 
df = pd.DataFrame({'A': 'a b a b'.split(), 'B': [1, 2, 3, 4]})
>>> df
   A  B
0  a  1
1  b  2
2  a  3
3  b  4


#To get the difference between each groups maximum and minimum value in one pass, you can do
>>> df.groupby('A').pipe(lambda g: g.max() - g.min()) #g is groupedFataframe 
   B
A
a  2
b  2



##Melt 
data = {'weekday': ["Monday", "Tuesday", "Wednesday", 
         "Thursday", "Friday", "Saturday", "Sunday"],
        'Person 1': [12, 6, 5, 8, 11, 6, 4],
        'Person 2': [10, 6, 11, 5, 8, 9, 12],
        'Person 3': [8, 5, 7, 3, 7, 11, 15]}
df = pd.DataFrame(data)
#output 
     weekday  Person 1  Person 2  Person 3
0     Monday        12        10         8
1    Tuesday         6         6         5
2  Wednesday         5        11         7

#How can you do group by on person 
#this is not normalized table 
#Melt data -long form - creating a generic form internally, which you can cast to specific shape

#each row is converted into id_vars versus other columns into 'variable'/var_name and 'value'/value_name
melt = pd.melt(df, id_vars=["weekday"], var_name="Person", value_name="Score")
#output 
     weekday    Person  Score
0     Monday  Person 1     12
1    Tuesday  Person 1      6
2  Wednesday  Person 1      5

#unpivot - wide form  
#pivot-unmelt - pivot(index=None, columns=None, values=None)
#'columns' columns name would be new DF's column labels 
#'values'= columnName  to use for populating new frame's cell values 
#'index'=Columnname for new frame's index

pm = melt.pivot(index='weekday', columns='Person', values='Score')
#output 
Person    Person 1  Person 2  Person 3
weekday
Friday          11         8         7
Monday          12        10         8
#reset_index()
pm2 = pm.reset_index()



##excel style pivot table 
#values=ColumnNames for aggfun , 
#index=ColumnsNames for row-groupby , 
#columns=ColumnNames on column-groupby , aggfunc=not string, but functions 
table = pd.pivot_table(melt, values=['Score'], 
    index=['weekday'], 
    columns=['Person'], 
    aggfunc=[np.sum, np.max, lambda x:x.size]) #no np method for count , we have np.count_nonzero 

#or to get all of those 
pd.pivot_table(melt, values=['Score'], 
    columns=['Person'], 
    aggfunc=[np.sum, np.max, lambda x:x.size])

    
    
##Stack and Unstack 
DataFrame.unstack(level=-1, fill_value=None)
DataFrame.stack(level=-1, dropna=True)
    level : int, string, or list of these, default -1 (last level)
        Level(s) of index to unstack, can pass level name
    fill_value : replace NaN with this value if the unstack produces missing values
    dropna : boolean, default True
        Whether to drop rows in the resulting Frame/Series with no valid values

#Meanings 
stack(column->row): Move last level(default) or 'level' of MultiIndex column labels 
       into last level of row labels
unstack(row->column): Move last level(default) or 'level' of MultiIndex row labels 
       into last level of column labels

#The stack function moves out a level in the DataFrame's columns 
#to produce either:
    •A Series, in the case of a simple column Index
    •A DataFrame, in the case of a MultiIndex in the columns

#Example 
tuples = list(zip(*[['bar', 'bar', 'baz', 'baz',
                    'foo', 'foo', 'qux', 'qux'],
                   ['one', 'two', 'one', 'two',
                    'one', 'two', 'one', 'two']]))
index = pd.MultiIndex.from_tuples(tuples, names=['first', 'second'])
df = pd.DataFrame(np.random.randn(8, 2), index=index, columns=['A', 'B'])
df2 = df[:4]
>>> df2
                     A         B
first second                    
bar   one     0.721555 -0.706771
      two    -1.039575  0.271860
baz   one    -0.424972  0.567020
      two     0.276232 -1.087401
      
stacked = df2.stack() #(column->row)
>>> stacked
first  second   
bar    one     A    0.721555
               B   -0.706771
       two     A   -1.039575
               B    0.271860
baz    one     A   -0.424972
               B    0.567020
       two     A    0.276232
               B   -1.087401
dtype: float64

>>> stacked.unstack() #(row->column)
                     A         B
first second                    
bar   one     0.721555 -0.706771
      two    -1.039575  0.271860
baz   one    -0.424972  0.567020
      two     0.276232 -1.087401

>>> stacked.unstack(1) #(row->column), level=1 (0-based) moved to column 
second        one       two
first                      
bar   A  0.721555 -1.039575
      B -0.706771  0.271860
baz   A -0.424972  0.276232
      B  0.567020 -1.087401

>>> stacked.unstack(0) #(row->column), level=0 (0-based)
first          bar       baz
second                      
one    A  0.721555 -0.424972
       B -0.706771  0.567020
two    A -1.039575  0.276232
       B  0.271860 -1.087401

#If the indexes have names
>>> stacked.unstack('second')#(row->column), level=1 (0-based)
second        one       two
first                      
bar   A  0.721555 -1.039575
      B -0.706771  0.271860
baz   A -0.424972  0.276232
      B  0.567020 -1.087401

##Combining stack/unstack with stats and GroupBy
columns = pd.MultiIndex.from_tuples([('A', 'cat'), ('B', 'dog'),
                                     ('B', 'cat'), ('A', 'dog')],
                                    names=['exp', 'animal'])
index = pd.MultiIndex.from_product([('bar', 'baz', 'foo', 'qux'),
                                    ('one', 'two')],
                                   names=['first', 'second'])
df = pd.DataFrame(np.random.randn(8, 4), index=index, columns=columns)
>>> df
exp                  A                  B                 
animal             cat       dog       cat       dog
first second                                        
bar   one     0.895717  0.805244 -1.206412  2.565646
      two     1.431256  1.340309 -1.170299 -0.226169
baz   one     0.410835  0.813850  0.132003 -0.827317
      two    -0.076467 -1.187678  1.130127 -1.436737
foo   one    -1.413681  1.607920  1.024180  0.569605
      two     0.875906 -2.211372  0.974466 -2.006747
qux   one    -0.410001 -0.078638  0.545952 -1.219217
      two    -1.226825  0.769804 -1.281247 -0.727707
      
#(column->row), then mean rowwise 
#here axis=0 means columnwise , =1 mean rowwise
>>> df.stack().mean(axis=1).unstack() 
animal             cat       dog
first second                    
bar   one    -0.155347  1.685445
      two     0.130479  0.557070
baz   one     0.271419 -0.006733
      two     0.526830 -1.312207
foo   one    -0.194750  1.088763
      two     0.925186 -2.109060
qux   one     0.067976 -0.648927
      two    -1.254036  0.021048

# same result, another way
#In Group By: axis : int, default 0, axis=0 split rows , =1 split column
#level : int, level name, or sequence of such, default None
#If the axis is a MultiIndex (hierarchical), group by a particular level or levels
>>> df.groupby(level=1, axis=1).mean() #ie on 'animal', keeping same index ie agg on 'A','B' of same cat 
animal             cat       dog
first second                    
bar   one    -0.155347  1.685445
      two     0.130479  0.557070
baz   one     0.271419 -0.006733
      two     0.526830 -1.312207
foo   one    -0.194750  1.088763
      two     0.925186 -2.109060
qux   one     0.067976 -0.648927
      two    -1.254036  0.021048
#(column->row),
>>> df.stack().groupby(level=1).mean() #axis=0 , split row ie on 'second' 
exp            A         B
second                    
one     0.071448  0.455513
two    -0.424186 -0.204486
#(row->column)
>>> df.mean()
exp  animal
A    cat      -0.024948
B    dog       0.458365
     cat      -0.322612
A    dog      -0.024222
>>> df.mean().unstack(0)  #mean axis=0, column wise  , then move 0 row to column 
exp            A         B
animal                    
cat     0.060843  0.018596
dog    -0.413580  0.232430



##Compute a simple cross-tabulation of two (or more) factors
pandas.crosstab(index, columns, values=None, rownames=None, colnames=None, 
        aggfunc=None, margins=False, margins_name='All', 
        dropna=True, normalize=False)
    index : array-like, Series, or list of arrays/Series
        Values to group by in the rows
    columns : array-like, Series, or list of arrays/Series
        Values to group by in the columns
    values : array-like, optional
        Array of values to aggregate according to the factors. 
        Requires aggfunc be specified.
    aggfunc : function, optional
        If specified, requires values be specified as well
    normalize : boolean, {'all', 'index', 'columns'}, or {0,1}, default False
        Normalize by dividing all values by the sum of values.
        •If passed 'all' or True, will normalize over all values.
        •If passed 'index' will normalize over each row.
        •If passed 'columns' will normalize over each column.
        •If margins is True, will also normalize margin values.

#Example 
df = pd.DataFrame({'A': [1, 2, 2, 2, 2], 'B': [3, 3, 4, 4, 4],
                   'C': [1, 1, np.nan, 1, 1]})
>>> df
   A  B    C
0  1  3  1.0
1  2  3  1.0
2  2  4  NaN
3  2  4  1.0
4  2  4  1.0
>>> pd.crosstab(df.A, df.B)
B  3  4
A      
1  1  0
2  1  3
>>> pd.crosstab(df.A, df.B, values=df.C, aggfunc=np.sum, normalize=True,margins=True)
B       3    4   All
A                   
1    0.25  0.0  0.25
2    0.25  0.5  0.75
All  0.50  0.5  1.00

foo = pd.Categorical(['a', 'b'], categories=['a', 'b', 'c'])
bar = pd.Categorical(['d', 'e'], categories=['d', 'e', 'f'])
>>> pd.crosstab(foo, bar)
col_0  d  e  f
row_0         
a      1  0  0
b      0  1  0
c      0  0  0
    
##Take Methods
#indices should be a 1d list or ndarray that specifies row or column positions.

frm = pd.DataFrame(np.random.randn(5, 3))

>>> frm
          0         1         2
0  0.818018 -0.108807 -1.076220
1  1.513445  1.606747  0.627268
2  0.674795 -0.255281  1.871350
3 -0.408397  0.174307 -0.392549
4  0.132381  0.232113 -2.922693

>>> frm.take([1, 4, 3])  #row indicess , axis=0 
          0         1         2
1  1.513445  1.606747  0.627268
4  0.132381  0.232113 -2.922693
3 -0.408397  0.174307 -0.392549

>>> frm.take([0, 2], axis=1)
          0         2
0  0.818018 -1.076220
1  1.513445  0.627268
2  0.674795  1.871350
3 -0.408397 -0.392549
4  0.132381 -2.922693


###CategoricalIndex
#category can be index 
#efficient indexing and storage of an index with a large number of duplicated elements.

from pandas.api.types import CategoricalDtype

df = pd.DataFrame({'A': np.arange(6),'B': list('aabbca')})
df['B'] = df['B'].astype(CategoricalDtype(list('cab')))
>>> df
   A  B
0  0  a
1  1  a
2  2  b
3  3  b
4  4  c
5  5  a

>>> df.dtypes
A       int64
B    category
dtype: object

df.B.cat.categories#Index(['c', 'a', 'b'], dtype='object')

#Setting the index will create a CategoricalIndex.
df2 = df.set_index('B')

df2.index

df2.loc['a']  #all 'a'

#The CategoricalIndex is preserved after indexing:
df2.loc['a'].index

df2.sort_index()  #based on categorical order 

#Groupby operations on the index will preserve the index nature as well.

>>> df2.groupby(level=0).sum() #axis=0, split rows 
   A
B   
c  4
a  6
b  5

df2.groupby(level=0).sum().index#CategoricalIndex(['c', 'a', 'b'], categories=['c', 'a', 'b'], ordered=False, name='B', dtype='category')

#Reindexing operations will return a resulting index based on the type of the passed indexer. 
>>> df2.reindex(['a', 'e'])
     A
B     
a  0.0
a  1.0
a  5.0
e  NaN



###iris example 
iris = pd.read_csv('data/iris.csv')
iris.head()
    
iris['sepalRatio'] = iris.SepalWidth / iris.SepalLength
iris.columns
       
     
#Any np.methods() can be used 
un = np.unique(iris.Name)
iris.Name.unique()

#.str methods 
iris.Name.str.lower()

#for integer index 
#apply for Series , each element 
np.unique(iris.Name.apply(lambda x: un.tolist().index(x)))
#or could be 
iris.Name.astype('categorical').cat.codes 


#Get the first five rows of a column by name
iris['SepalLength'][:5]                     #Series
iris[ [ 'SepalLength', 'SepalWidth'] ][:5]  #DF 
#or 
iris.iloc[:5, 0]

#Create categorical ranges for numerical data. 14 is number of bins
sl_bin = pd.cut(iris['SepalLength'], 14)
sl_bin[:5]

#Look at the frequencies in the ranges created above
pd.value_counts(sl_bin)
sl_bin.value_counts()


#Order the data by specified column
iris['SepalLength'].sort_values()[:5]

#Sort by a column and that obtain a cross-section of that data , multiple can be given
sorteddata = iris.sort_values(by=['SepalLength', 'PetalLength'])  #DF
sorteddata.ix[:,0:6].head(3)  

#Obtain the first three rows and first three columns of the sorted data
sorteddata.iloc[0:3,0:3]

#Obtain value counts of specific column
iris['PetalLength'].value_counts()


#Obtain True/False  values which could be used inside iloc, loc etc 
iris.ix[:,'Name'] == 'Iris-setosa'
#Can get any columns , use  | , &, ~ for boolean conjunction, disjunction and inverse 
iris.loc[iris['Name'] == 'Iris-setosa', 'SepalLength']  #Series
iris.ix[iris['Name'] == 'Iris-setosa', 0] #note .iloc with boolean not available 
iris.loc[iris['Name'] == 'Iris-setosa', ['SepalLength','PetalLength']] #DF

#Query the data
qry1 = iris.query('Name == "Iris-setosa"')  #returns DF of original only where cond is valid 
qry1.head(10)


#other methods of DATAFrame 
iris.values 	    #Return a Numpy representation of the DataFrame.
iris.get_values() 	#Return an ndarray after converting sparse values to dense.
iris.axes 	        #Return a list representing the axes of the DataFrame.
iris.ndim 	        #Return an int representing the number of axes / array dimensions.
iris.size 	        #Return an int representing the number of elements in this object.
iris.shape 	        #Return a tuple representing the dimensionality of the DataFrame.
iris.empty 	        #Indicator whether DataFrame is empty.

iris.iloc[:, 0:4].astype(np.float64) 	#Cast a pandas object to a specified dtype dtype.
iris.copy(deep=True) 	#Make a copy of this object’s indices and data.
iris.isna() 	        #Detect missing values.
iris.notna() 	        #Detect existing (non-missing) values.

#DataFrame.insert(loc, column, value[, …]) 	Insert column into DataFrame at specified location.
#0 <= loc <= len(columns), at that location , always inplace 
iris.insert(2, column= 'Square', value=iris.SepalLength **2)

#DataFrame.__iter__() 	Iterate over infor axis
for columnName in iris:
    print(columnName)
#DataFrame.keys() 	Get the ‘info axis’ (see Indexing for more)
for columnName in iris.keys():
    print(columnName)
    
#DataFrame.items() 	Iterator over (column name, Series) pairs.
for columnName,value in iris.items():
    print(columnName,type(value),value.get(0), value[0]) 

#DataFrame.iteritems() 	Iterator over (column name, Series) pairs.
for columnName,value in iris.iteritems():
    print(columnName,type(value),value.get(0), value[0]) 

#DataFrame.iterrows() 	Iterate over DataFrame rows as (index, Series) pairs.
for i,value in iris.iterrows():
    print(i,type(value),value.get(0), value[0]) 

#DataFrame.itertuples([index, name]) 	Iterate over DataFrame rows as namedtuples.
for t in iris.itertuples():
    print(t,type(t),t[0]) #SepalLength <class 'pandas.core.series.Series'> 5.1 5.1


#DataFrame.lookup(row_labels, col_labels) 	
#ie [0, 'SepalLength'], [30, 'Name'], [70, 'Name']
iris.lookup([0,30,70], ['SepalLength', 'Name', 'Name']) 
#array([5.1, 'Iris-setosa', 'Iris-versicolor'], dtype=object)


#DataFrame.pop(item) 	Return item and drop from frame.
iris.pop('SepalLength')
iris.columns #no SepalLength

#DataFrame.get(key[, default]) 	Get item from object for given key (DataFrame column, Panel slice, etc.).
iris.get('SepalWidth')


#DataFrame.isin(values) 	Whether each element in the DataFrame is contained in values.
#for series 
iris.loc[:, ['Name']].isin(['Iris-setosa', 'Iris-versicolor', 'Iris-virginica']).all()
iris.isin({'Name':['Iris-setosa', 'Iris-versicolor', 'Iris-virginica']}).all()
iris.Name.isin(['Iris-setosa', 'Iris-versicolor', 'Iris-virginica']).all()


#DataFrame.combine(other, func[, fill_value, …]) 	Perform column-wise combine with another DataFrame based on a passed function.
#Function that takes two series as inputs and return a Series or a scalar.
take_smaller = lambda s1, s2: s1 if s1.sum() < s2.sum() else s2
iris.iloc[:,0:3].combine(iris.iloc[:,0:3], take_smaller)


#DataFrame.combine_first(other) 	
#Update null elements in this with value in the same location of other.
iris.iloc[:,0:3].combine_first(iris.iloc[:,0:3])


#DataFrame.nlargest(n, columns[, keep]) 	Return the first n rows ordered by columns in descending order.
#df.sort_values(columns, ascending=False).head(n)
#DataFrame.nsmallest(n, columns[, keep])
iris.nlargest(3, 'SepalWidth') #returns full row 
iris.nsmallest(3, 'SepalWidth') #returns full row 

#Transpose 
iris.T 


#DataFrame.truncate([before, after, axis, copy]) 	Truncate a Series or DataFrame before and after some index value.
iris.truncate(before=2, after=4) #axis=0, rowise  , before 2 and after 4 are removed 
iris.sort_index(axis=1) #reposition Columns based on sort-order 
iris.sort_index(axis=1).truncate(after='PetalWidth', axis=1) #columnwise #Name  PetalLength  PetalWidth


#DataFrame.add_prefix(prefix) 	Prefix labels with string prefix.
#DataFrame.add_suffix(suffix) 	Suffix labels with string suffix.
iris.add_prefix("ori_")


#DataFrame.drop_duplicates([subset, keep, …]) 	Return DataFrame with duplicate rows removed, optionally only considering certain columns.
iris.append(iris).reset_index().drop_duplicates()


#DataFrame.duplicated([subset, keep]) 	Return boolean Series denoting duplicate rows, optionally only considering certain columns.
iris.append(iris).reset_index().duplicated().taiil(150).all() #True

#DataFrame.equals(other) 	Test whether two objects contain the same elements.
iris.equals(iris.copy())


#DataFrame.filter([items, like, regex, axis]) 	Subset rows or columns of dataframe according to labels in the specified index.
#List of axis to restrict to 
iris.filter(['Name', 'SepalWidth']) #Name  SepalWidth
iris.filter(like='Width') #SepalWidth  PetalWidth
iris.filter(regex=r'W\w{4}') #SepalWidth  PetalWidth


#DataFrame.idxmax([axis, skipna]) 	Return index of first occurrence of maximum over requested axis.
#DataFrame.idxmin([axis, skipna]) 	Return index of first occurrence of minimum over requested axis.
>>> iris.iloc[:, 0:4].idxmax() #row index where it happens #axis=0, columnwise 
SepalWidth      15
Square         131
PetalLength    118
PetalWidth     100
dtype: int64

iris.at[15, 'SepalWidth'] #is max 


#almost all these methods have axis
#axis=0, columnwise, axis=1, rowwise 

#Return whether any element is True, potentially over an axis.
(iris.ix[:,'SepalWidth'] > 4.3).any()
#Return whether all elements are True, potentially over an axis.
(iris.ix[:,'SepalWidth'] > 4.3).all()

iris.iloc[:, 0:4].abs() 	#Return a Series/DataFrame with absolute numeric value of each element.

#Count non-NA cells for each column or row.
>>> iris.iloc[:, 0:4].count() #columnwise, axis=1, for each row 
SepalWidth     150
Square         150
PetalLength    150
PetalWidth     150
dtype: int64

#default columnwise, axis=1, rowwise 
#default skipna=True
iris.iloc[:, 0:4].cummax() 	#Return cumulative maximum over a DataFrame or Series axis.
iris.iloc[:, 0:4].cummin() 	#Return cumulative minimum over a DataFrame or Series axis.
iris.iloc[:, 0:4].cumprod() 	#Return cumulative product over a DataFrame or Series axis.
iris.iloc[:, 0:4].cumsum() 	#Return cumulative sum over a DataFrame or Series axis.


#DataFrame.eval(expr[, inplace]) 	Evaluate a string describing operations on DataFrame columns.
iris.eval('newSepalWidth = 2 * SepalWidth') #inplace=True for inplace 

#DataFrame.max([axis, skipna, level, …]) 	Return the maximum of the values for the requested axis.
#DataFrame.min([axis, skipna, level, …]) 	Return the minimum of the values for the requested axis.
>>> iris.iloc[:, 0:4].max()
SepalWidth      4.40
Square         62.41
PetalLength     6.90
PetalWidth      2.50
dtype: float64

DataFrame.round([decimals]) 	Round a DataFrame to a variable number of decimal places.
iris.iloc[:, 0:4].round(2)

#DataFrame.sum([axis, skipna, level, …]) 	Return the sum of the values for the requested axis.
iris.iloc[:, 0:4].sum() #columnwise, axis=1, rowwise 

#DataFrame.nunique([axis, dropna]) 	Count distinct observations over requested axis.
iris.iloc[:, [4]].nunique() #number of unique 


#Group data and obtain the mean,
#group by col1 and then col2 and find mean of all other columns
grouped1 = iris.groupby('SepalLength') #single column 
grouped1 = iris.groupby(['SepalLength','PetalLength']) #pandas.core.groupby.DataFrameGroupBy
dir(grouped1)
grouped1.mean()  #DF
grouped1.agg(np.mean) #DF 
grouped1.mean().index #MultiIndex 
grouped1.agg({'SepalWidth':'count', 'PetalWidth':'mean'}) #DF 

#save to csv , there are many methods for other IO
grouped1.agg({'SepalWidth':'count', 'PetalWidth':'mean'}).to_csv("processec.csv") 	




##Visualization

#Plot counts of a specified column using Pand as
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns  #install it, pip install seaborn

iris.Name.value_counts().plot(kind='bar')
plt.show()
#with x and y 
iris.plot(x=None, y='SepalWidth', kind='line')
plt.show()
#full DF 
iris.plot( kind='line')
plt.show()
#for sub DF 
iris.iloc[:,0:4].plot(kind='line')
plt.show()
#with groupby 
iris.groupby('Name').plot(kind='line')
plt.show()
#as subplots 
iris.groupby('Name').plot(kind='line', subplots=True)
plt.show()
#for partial DF 
iris.iloc[:,0:5].groupby('Name')['SepalLength'].plot(kind='line', subplots=True)
plt.show()

#but in same plot 
fig, ax = plt.subplots(figsize=(8,6))
for label, df in iris.groupby('Name'):
    df.SepalLength.plot(kind="line", ax=ax, label=label)
plt.legend()
plt.show()


##Other Plots 
##scatter_matrix 
#https://pandas.pydata.org/pandas-docs/stable/visualization.html

from pandas.plotting import scatter_matrix
df = pd.DataFrame(np.random.randn(1000, 4), columns=['a', 'b', 'c', 'd'])
scatter_matrix(ver, alpha=0.2, figsize=(6, 6), diagonal='kde')
#only density plot 
df.a.plot.kde()

##lagplot -Lag plots are used to check if a data set or time series is random. 
#Random data should not exhibit any structure in the lag plot. 
#Non-random structure implies that the underlying data are not random.
from pandas.plotting import lag_plot
lag_plot(df.a)

##Autocorrelation plots are often used for checking randomness in time series
#If time series is random, such autocorrelations should be near zero for any and all time-lag separations
from pandas.plotting import autocorrelation_plot
autocorrelation_plot(df.a)

#Bootstrap plots are used to visually assess the uncertainty of a statistic, 
#such as mean, median, midrange, etc. 
#A random subset of a specified size is selected from a data set, 
#the statistic in question is computed for this subset 
#and the process is repeated a specified number of times. 
#Resulting plots and histograms are what constitutes the bootstrap plot.
from pandas.plotting import bootstrap_plot
bootstrap_plot(df.a, size=50, samples=500, color='grey')




###*EXCEl: xlrd is required for pandas.read_excel 
pandas.read_excel(io, sheet_name=0, header=0, skiprows=None, skip_footer=0, index_col=None, names=None, usecols=None, parse_dates=False, date_parser=None, na_values=None, thousands=None, conirist_float=True, coniristers=None, dtype=None, true_values=None, false_values=None, engine=None, squeeze=False, **kwds)
    df = pd.read_excel("file_name", 'Sheet1') #needs xlrd
    #for example setting correct index from one column, if datetime, use to_datetime
    df.index = pd.to_datetime(df.Date)
DataFrame.to_excel(excel_writer, sheet_name='Sheet1', na_rep='', float_format=None, columns=None, header=True, index=True, index_label=None, startrow=0, startcol=0, engine=None, merge_cells=True, encoding=None, inf_rep='inf', irisbose=True, freeze_panes=None)

pandas.to_datetime(arg, errors='raise', dayfirst=False, yearfirst=False, utc=None, box=True, format=None, exact=True, unit=None, infer_datetime_format=False, origin='unix')[source]
    Convert argument to datetime.
    arg : integer, float, string, datetime, list, tuple, 1-d array, Series
    #common format 
    %w  Weekday as a decimal number, where 0 is Sunday and 6 is Saturday. 0, 1, …, 6   
    %d  Day of the month as a zero-padded decimal number. 01, 02, …, 31 
    %b  Month as locale's abbreviated name. Jan, Feb, …, Dec (en_US);
    %B  Month as locale's full name. January, February, …, December (en_US);
    %m  Month as a zero-padded decimal number. 01, 02, …, 12   
    %y  Year without century as a zero-padded decimal number. 00, 01, …, 99   
    %Y  Year with century as a decimal number. 1970, 1988, 2001, 2013   
    %H  Hour (24-hour clock) as a zero-padded decimal number. 00, 01, …, 23   
    %I  Hour (12-hour clock) as a zero-padded decimal number. 01, 02, …, 12   
    %p  Locale's equivalent of either AM or PM. AM, PM (en_US);
    %M  Minute as a zero-padded decimal number. 00, 01, …, 59   
    %S  Second as a zero-padded decimal number. 00, 01, …, 59 
    %f  Microsecond as a decimal number, zero-padded on the left. 000000, 000001, …, 999999 
    %z  UTC offset in the form +HHMM or -HHMM (empty string if the the object is naive). (empty), +0000, -0400, +1030 
    %Z  Time zone name (empty string if the object is naive). (empty), UTC, EST, CST   
    %j  Day of the year as a zero-padded decimal number. 001, 002, …, 366   
    %U  Week number of the year (Sunday as the first day of the week) as a zero padded decimal number. All days in a new year preceding the first Sunday are considered to be in week 0. 00, 01, …, 53 
    %W  Week number of the year (Monday as the first day of the week) as a decimal number. All days in a new year preceding the first Monday are considered to be in week 0. 00, 01, …, 53 

#Example  
import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 
import statsmodels.api as sm 

dft = pd.read_excel(r"data\Nifty-17_Years_Data-V1.xlsx", 
    parseDates=True, index_col=0, header=0, 
    date_parser=lambda x: pd.to_datetime(x, format="%d-%b-%y"))
dft.index
>> df.head()

from pandas.tseries.offsets import *
dft.index.freq = Day() #set freq as D 

import datetime
#For specific exact index for DF , use .loc 
dft['2000-06-01'] #ERROR 
dft[datetime.date(2000, 6, 1)] #equivalent to exact  #ERROR #datetime.date(year, month, day)
#use below 
dft.loc['2000-06-01']
dft.iloc[0]
dft.loc[datetime.date(2000, 6, 1)] 
#for both DF and Series- any partial date string or slice of exact index works 
dft['2000-06-01']             #from 2013-01-01 00:00:00 till upto 2013-01-01 23:59:00
dft['2013']                 #Year based , from 2013-01-01 00:00:00 till upto 2013-03-11 10:39:00
dft['2013-1':'2013-2']      #slice, end inclusive 
dft['2013-1':'2013-2-28']   # stop time that includes all of the times on the last day
dft['2013-1':'2013-2-28 00:00:00'] #exact stop time     
dft[datetime.date(2013, 1, 1):datetime.date(2013,2,28)] #exact start and stop time 
dft[datetime.datetime(2013, 1, 1, 10, 12, 0):datetime.datetime(2013, 2, 28, 10, 12, 0)] #exact start and stop time 




#plot 
dft.plot(kind='line', subplots=True)
plt.show()
dft.Close.plot(kind='line')
plt.show()


#with subplots 
#multiple in one plot 
dft.plot(kind='line', y=['Open', 'Day Wise Variation ( points) '] )
#with subplots 
dft.plot(kind='line', y=['Open', 'Day Wise Variation ( points) '], subplots=True )


#complex plot 
#4x4 gridspecs, specification for 0,0 cell , row spanning 3 rows, column spanning 4 columns 
top = plt.subplot2grid((4,4), (0, 0), rowspan=3, colspan=4)
top.plot(dft.index, dft["Close"])
plt.title('Nifty close from 2000 - 2018')

#4x4 gridspecs, specification for 3,0 cell , row spanning 1 rows, column spanning 4 columns 
bottom = plt.subplot2grid((4,4), (3,0), rowspan=1, colspan=4)
bottom.bar(dft.index, dft['Day Wise Variation ( points) '])
plt.title('Nifty Day wise variations ')

plt.show()


##Groupby (for Time series, equivalent to aggregation)
#Calculate moving avarages 
#window : int,Size of the moving window. 
#This is the number of observations used for calculating the statistic.
dft_r = dft.rolling(30)  #rolling 30 samples 
dir(dft_r)
#plot rolling average 
dft_r.mean()['Open'] #DF 
dft_r.mean().dropna().plot(kind='line') #DF
plt.show()
#
dft_s = dft.ewm(com=0.5)#Returns Exponentially-weighted moving window(EWM) class ,com=decay in terms of center of mass
#
dft_s = dft.expanding(2) #Expanding window, Minimum number of observations in window required to have a value         (otherwise result is NA)
#or downsampling at month 
dft_s = dft.resample('M')
dir(dft_s)
#month value would be mean()
dft_s.mean() #DF 
dft_s['Open'].mean() #Series
dft_s['Open'].agg([np.sum, np.mean, np.std])
dft_s.agg({'Open':'mean', 'Close':'std'})
dft_s.agg({'Open':['mean',np.std], 'Close':['std','sum']})
#which year, stock market crashed
dfn = dft_s['Open'].agg(['max', 'min'])
dfn['diff'] = dfn['max']-dfn['min']
dfn['diff'].loc[dfn['diff'] == dfn['diff'].max()].index.year

#KDE plot
dft_s.Close.plot(kind='kde')

#lagplot -Lag plots are used to check if a data set or time series is random. 
#Random data should not exhibit any structure in the lag plot. 
#Non-random structure implies that the underlying data are not random.
from pandas.plotting import lag_plot
lag_plot(df.Close)
plt.show()


##Autocorrelation plots are often used for checking randomness in time series
#If time series is random, such autocorrelations should be near zero for  all time-lag separations(other than lag=0)
from pandas.plotting import autocorrelation_plot
autocorrelation_plot(df.Close)




###HandsOn
##Example  of Various operations possible in DataFrame, 
ver=pd.read_csv("data/ver.csv")  
#columns 
#index,year,day of the year,time,atmospheric pressure (mBar),rainfall (mm),wind speed (m/s),wind direction (degrees),surface temperature (C),relative humidity (%),wind_max (m/s),Tdew (C),wind_chill (C),uncalibrated solar flux (Kw/m2), calibrated solar flux (Kw/m2),battery (V),not used

#index 
ver.index 

#category 
ver['year'].astype('category')
ver['year'].astype('category').cat.categories
ver['year'].astype('category').cat.add_categories([2018])
ver['year'].astype('category').cat.rename_categories({2015:'a'})
ver['year'].astype('category').cat.rename_categories({2015:'a'}).astype(str)

#display few rows
pd.set_option('display.max_columns', 80)
ver.head(3)

#Determine the number of rows and columns in the dataset
ver.shape

#Find the number of rows in the dataset
len(ver)

#Get the names of the columns
ver.columns

#Get the first five rows of a column by name
ver['atmospheric pressure (mBar)'][:5]

#Create categorical ranges for numerical data. 14 is number of bins
atmospheric_pressure = pd.cut(ver['atmospheric pressure (mBar)'], 14)
atmospheric_pressure[:5]

#Look at the frequencies in the ranges created above
pd.value_counts(atmospheric_pressure)

#first six columns of the first row
#ix like .loc[row,column] , ie label based at first if not then iloc[row,column], index based
ver.ix[0,0:6]

#Order the data by specified column
ver['atmospheric pressure (mBar)'].sort_values()[:5]

#Sort by a column and that obtain a cross-section of that data , multiple can be given
sorteddata = ver.sort_values(by=['atmospheric pressure (mBar)', 'day of the year'])
sorteddata.ix[:,0:6].head(3)  

#Obtain the first three rows and first three columns of the sorted data
sorteddata.iloc[0:3,0:3]

#Obtain value counts of specific column
ver['atmospheric pressure (mBar)'].value_counts()

#to obtain the datatype for every colu mn
zip(ver.columns, [type(x) for x in ver.ix[0,:]])
#OR
ver.dtypes

#Get the unique values for a column by name.
ver['year'].unique()

#Get a count of the unique values of a column
len(ver['year'].unique())

#Index into a column and get the first four rows
ver.ix[0:3,'atmospheric pressure (mBar)']

#Obtain True/False  values
ver.ix[0:3,'atmospheric pressure (mBar)'] == 1025

#Return a subset of the data, >, >=, == and ~, |, &
atmsubset = ver[ (ver['atmospheric pressure (mBar)'] > 1010 ) & (ver['atmospheric pressure (mBar)'] < 1016) ]
atmsubset.head(5)
#Look at the shape of the dataset
atmsubset.shape

#Query the data
qry1 = ver.query('year == 2015')   #here column name must not contain any space etc
qry1.head(10)

#if column names contains space , use below to remove , required for even attribute access
originals = ver.columns[:]
ver.columns = [c.replace(' ', '_') for c in ver.columns]
ver.columns = [c.replace('(', '') for c in ver.columns]
ver.columns = [c.replace(')', '') for c in ver.columns]
qry1 = ver.query('atmospheric_pressure_mBar == 1016')
#Look at the shape of the data
qry1.shape

#Check a boolean condition
(ver.ix[:,'atmospheric_pressure_mBar'] > 1016).any()


#Crosstab(frequency) of the data by specified columns (of one column vs another)
pd.crosstab(ver['atmospheric pressure (mBar)'],ver['rainfall (mm)'])

#Get descriptive statistics for a specified column
ver.atmospheric_pressure_mBar.describe()

#Aggregate 
#aggregate(func, axis=0, *args, **kwargs), args, kargs are passed to func, axis=0, means columnwise, axis=1, rowwise 
ver.agg(['sum', 'min'])
ver.agg({'atmospheric_pressure_mBar' : ['sum', 'min'], 'rainfall_mm' : ['min', 'max']})
df.agg("mean", axis=1)


#Group data and obtain the mean,
#group by col1 and then col2 and find mean of all other columns
grouped1 = ver.groupby(['atmospheric_pressure_mBar','rainfall_mm']).mean()
grouped1

#Group data and obtain the mean/median/etc  values of all other colum ns
grpagg = ver.groupby('atmospheric_pressure_mBar').aggregate(np.median)
grpagg

#Group data and get the sums of all other colum ns
grpsum = ver.groupby('atmospheric_pressure_mBar').aggregate(['sum', 'count'])
grpsum

# add a new column which is string version of one colu mn
ver['applicant_race_name_1'] = pd.Series(np.array(map(str, ver['atmospheric_pressure_mBar'])), index=ver.index)
ver['applicant_race_name_1'][0]  #'1025'


#Return boolean values for a specified criteria
criterion = ver['applicant_race_name_1'].map(lambda x: x.endswith('5'))  #x= each elements 
>>> criterion.value_counts()  #single variable- frequency
False    40005
True      4995

##other 
#DataFrame.apply(func, axis=0, broadcast=None, raw=False, reduce=None, result_type=None, args=(), **kwds)
#apply func on axis(0, varying row ie columnwise, 1=rowwise), fun(Series):one_value
#DataFrame.applymap(func)  , apply func elementwise, func(each_element)
#DataFrame.aggregate(func, axis=0, *args, **kwargs)
#func is agg function or list of functions or dict(key columnName, value =agg funcs on ColumnName), could be strings eg mean, median, prod, sum, std, var,count 
#for List of functions strings, see pandas.DataFrame.GroupBy
#DataFrame.transform(func, *args, **kwargs), func(each_column):new_column
ver.apply(np.sum)
ver.applymap(lambda x:str(x))
ver.aggregate({'atmospheric pressure (mBar)':['mean','count','sum']})
ver.iloc[:,[3,4]].transform(lambda x: (x-x.mean())/x.std)



##excel styple pivot table 
#values=ColumnNames for aggfun , index=ColumnsNames for row-groupby , columns=ColumnNames on column-groupby , aggfunc=not string, but functions 
>>> table = pd.pivot_table(ver, 
    values=['atmospheric pressure (mBar)','rainfall (mm)'], 
    index=['year', 'day of the year'], 
    columns=['battery (V)'], 
    aggfunc=[np.sum, np.max, lambda x:x.size]) #no np method for count , we have np.count_nonzero 





    
## Using Pandas for Analyzing Data - Visualization

#Plot counts of a specified column using Pand as
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns  #install it, conda install seaborn

ver.atmospheric_pressure_mBar.value_counts().plot(kind='barh')
plt.show()

#note 
df.plot(kind='line') 
#is equivalent to 
df.plot.line()
#and similarly for others 

#Bar plot of median values
ver.groupby('atmospheric_pressure_mBar')['surface_temperature_C'].agg(np.median).plot(kind = 'bar')
plt.show()

#Box plot example - only for first 200 rows
g = sns.factorplot("atmospheric_pressure_mBar", "surface_temperature_C", "rainfall_mm" ,ver.loc[0:200], kind="box", palette="PRGn",aspect=2.25)
g.set(ylim=(0, 10))
plt.show()

#Bar plot example
g = sns.factorplot("atmospheric_pressure_mBar","rainfall_mm", data=ver.loc[0:200], hue="surface_temperature_C",size=3,aspect=2)
plt.show()















###Basic Statistics and essentials  



### Five number summary 
iris = pd.read_csv('toBeShared/data/iris.csv')
iris.iloc[:, 0:4].describe()
#default axis=0, columnwise, axis=1 rowwise 
iris.iloc[:, 0:4].mean()
iris.iloc[:, 0:4].std()
iris.iloc[:, 0:4].var()
iris.iloc[:, 0:4].median()
iris.iloc[:, 0:4].mode()
iris.iloc[:, 0:4].sem() 	    #Return unbiased standard error of the mean over requested axis.
iris.iloc[:, 0:4].mad() 	    #Return the mean absolute deviation of the values for the requested axis.

#The skewness for a normal distribution is zero, 
#and any symmetric data should have a skewness near zero. 
#Negative values for the skewness indicate data that are skewed left 
#and positive values for the skewness indicate data that are skewed right.
iris.iloc[:, 0:4].skew() 	    #Return unbiased skew over requested axis Normalized by N-1(kurtosis of skew == 0.0)

#Kurtosis is a measure of whether the data are heavy-tailed or light-tailed relative to a normal distribution. 
#That is, data sets with high kurtosis tend to have heavy tails, or outliers
iris.iloc[:, 0:4].kurt() 	    #Return unbiased kurtosis over requested axis using Fisher’s definition of kurtosis (kurtosis of normal == 0.0).
iris.iloc[:, 0:4].kurtosis() 	#Return unbiased kurtosis over requested axis using Fisher’s definition of kurtosis (kurtosis of normal == 0.0).

#covariance , + menas , both vary together, - means both vary inversely 
iris.iloc[:, 0:4].cov()
#correlation = covariance/stddev(x)*setdev(y)
#magnitude of how much both vary 
iris.iloc[:, 0:4].corr()
#parcentile 
np.percentile(iris.values[:, 0], [0, 25, 50, 75, 100]) 
iris.iloc[:, 0:4].quantile([0, .25, .50, .75, .100]) 	#Return values at the given quantile over requested axis.


###Box plots and outlier detection
#https://pandas.pydata.org/pandas-docs/version/0.22/visualization.html#box-plots
import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt 
plt.rcParams['figure.figsize'] = [10, 10]

iris = pd.read_csv('toBeShared/data/iris.csv')
iris.iloc[:, 0:4].plot.box()
iris.boxplot(by='Name')
## save 
plt.figure(figsize=(4,4))
iris.boxplot(by='Name')
plt.savefig("box.png")

#histogram 
#alpha = transparent
#superimposed 
iris.iloc[:, 0:4].plot.hist( alpha=0.5, bins=50)
#seperate 
iris.iloc[:, 0:4].hist( color='k', alpha=0.5, bins=50)


## violin plot 
import seaborn as sns
#x vs y and hue as 'by' like parameter , could be None 
#kind : {point, bar, count, box, violin, strip}
g = sns.factorplot(x="Name", y="PetalLength", hue="Name" ,data=iris.iloc[:,0:5], kind="violin", palette="PRGn",aspect=2.25)
g.set(ylim=(0, 10))


## Scatter plot 
iris.iloc[:, 0:4].plot.scatter(x='PetalLength', y='PetalWidth')
iris.iloc[:, 0:4].plot.line(x='PetalLength', y='PetalWidth')

## scatter matrix plot 
from pandas.plotting import scatter_matrix
scatter_matrix(iris, alpha=0.2, figsize=(2, 2), diagonal='kde')


## bar plot 
plt.figure();
#single row 
iris.iloc[5, 0:4].plot.bar(); plt.axhline(0, color='k'); plt.plt.axvline(0, color='k')
#many row s
iris.iloc[50:60,0:4].plot.bar()
iris.iloc[50:60,0:4].plot.bar(stacked=True)
iris.iloc[50:60,0:4].plot.barh(stacked=True)
#pie single row 
iris.iloc[50,0:4].plot.pie(subplots=True)

#DataFrame.plot.area([x, y]) 	Draw a stacked area plot.
df = pd.DataFrame(np.random.rand(10, 4), columns=['a', 'b', 'c', 'd'])
df.plot.area()

#DataFrame.plot.hexbin(x, y[, C, …]) 	Generate a hexagonal binning plot.
df = pd.DataFrame(np.random.randn(1000, 2), columns=['a', 'b'])
df['b'] = df['b'] + np.arange(1000)
df.plot.hexbin(x='a', y='b', gridsize=25)

#DataFrame.plot.density([bw_method, ind]) 	Generate Kernel Density Estimate plot using Gaussian kernels.
#DataFrame.plot.kde([bw_method, ind]) 	Generate Kernel Density Estimate plot using Gaussian kernels.
iris.iloc[:, 0:4].plot.density()
iris.iloc[:, 0:4].plot.kde()



##Plotting normal random numbers 
import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt 

x = np.linspace(0,100,100)
y = np.random.normal(size=(100,))
plt.plot(x,y, 'b-') # blue line plot 
plt.axhline(np.mean(y), linestyle='--', color='.5')
#x cordinate, y1 cordinate, y2 cordinate 
plt.fill_between(x, np.mean(y)+np.std(y),np.mean(y) - np.std(y),  color='r', alpha=.2)
plt.ylabel('Values')
plt.xlabel('Numbers')


##PDF and sampling 
fig, ax = plt.subplots(1, 1)

#Calculate a few first moments:
from scipy.stats import * 
mean, var, skew, kurt = norm.stats(moments='mvsk')

#Density (.pdf)				Returns probability Pr of a random variable X, ie Pr(x), 
#Distribution (.cdf)  		Returns cummulative Pr ie Pr(x <= q) or Pr(x >=q) with lower.tail = FALSE
#Quantile (.ppf)			Inverse of cdf, Given Probability p, returns x, value of X ie what is the value of x given p
#Random generation(.rvs)	Generates n random number based on this distribution 

#Display the probability density function (pdf):
x = np.linspace(norm.ppf(0.01), norm.ppf(0.99), 100)
ax.plot(x, norm.pdf(x),'r-', lw=5, alpha=0.6, label='norm pdf')

#Check accuracy of cdf and ppf:
vals = norm.ppf([0.001, 0.5, 0.999])
np.allclose([0.001, 0.5, 0.999], norm.cdf(vals)) #True

#Generate random numbers(sample)
r = norm.rvs(size=1000)
#And compare the histogram:
ax.hist(r, density=True, histtype='stepfilled', alpha=0.2)
ax.legend(loc='best', frameon=False)
plt.show()

##Example of estimating normal parameters 
import numpy as np
from scipy.stats import norm
import matplotlib.pyplot as plt

# Generate some data for this demonstration.
data = norm.rvs(10.0, 2.5, size=500) #loc,scale, size 

# Fit a normal distribution to the data:
>>> mu, std = norm.fit(data)  
(9.811694740931252, 2.6595778507346335)
# Plot the histogram.
plt.hist(data, bins=25, normed=True, alpha=0.6, color='g')

# Plot the PDF.
xmin, xmax = plt.xlim() #get xlimit 
x = np.linspace(xmin, xmax, 100)
p = norm.pdf(x, mu, std)
plt.plot(x, p, 'k', linewidth=2)
title = "Fit results: mu = %.2f,  std = %.2f" % (mu, std)
plt.title(title)

plt.show()


###Complete example 

#Normality is an important assumption for many statistical techniques

#Given Sample, how do we know visually, that this is a normal or not 
#If not normal, can you transform it into normal?

#A Box Cox transformation is a way to transform non-normal dependent variables into a normal shape


#boxcox: Transformation depends on lambda (λ), which varies from -5 to 5
#selects the best lambda 
#actula transformation is given by 
y = (x**lmbda - 1) / lmbda,  for lmbda > 0
    log(x),                  for lmbda = 0
#If alpha is not None, 
#return the 100 * (1-alpha)% confidence interval for lmbda 


#Example 
from scipy import stats
import matplotlib.pyplot as plt


#Generate some data and determine optimal lmbda in various ways:
x = stats.loggamma.rvs(5, size=30) + 5
y, lmax_mle = stats.boxcox(x)  #y is transformed of x

fig = plt.figure()
ax = fig.add_subplot(111)
prob = stats.boxcox_normplot(x, -10, 10, plot=ax)
ax.axvline(lmax_mle, color='r')
plt.show()



##stats.probplot
scipy.stats.probplot(x, sparams=(), dist='norm', fit=True, plot=None, rvalue=False)
#Generates a probability plot of sample data 
#against the quantiles of a specified theoretical distribution 
#(the normal distribution by default). 
#probplot generates a probability plot, 
#which should not be confused with a Q-Q or a P-P plot

 
#Example 
from scipy import stats
import matplotlib.pyplot as plt
nsample = 100
np.random.seed(7654321)

fig = plt.figure()
ax1 = fig.add_subplot(511)
x = stats.loggamma.rvs(5, size=500) + 5
prob = stats.probplot(x, dist=stats.norm, plot=ax1)
ax1.set_xlabel('')
ax1.set_title('Probplot against normal distribution')

#after transformation 
ax2 = fig.add_subplot(512)
xt, _ = stats.boxcox(x)
prob = stats.probplot(xt, dist=stats.norm, plot=ax2)
ax2.set_title('Probplot after Box-Cox transformation')

#Then QQ plot 
#qqplot(data, dist=<scipy.stats._continuous_distns.norm_gen object>, distargs=(), a=0, loc=0, scale=1, fit=False, line=None, ax=None)
#dist : A scipy.stats or statsmodels distribution
ax2 = fig.add_subplot(513)
import statsmodels.api as sm
sm.qqplot(xt, line='45', ax=ax2)
ax3.set_title('Q-Q after Box-Cox transformation')

#qqplot of the residuals against quantiles of t-distribution with 4 degrees of freedom:
import scipy.stats as stats
ax3 = fig.add_subplot(514)
fig = sm.qqplot(xt, stats.t, distargs=(4,), , ax=ax3)

#qqplot against same as above, but with mean 3 and std 10:
ax4 = fig.add_subplot(515)
fig = sm.qqplot(xt, stats.t, distargs=(4,), loc=3, scale=10, , ax=ax4)
plt.show()








##Hypothesis testing 
H0 = base assumptions, Each test has one H0 
#understanding 
If p value > .10    -> 'not significant'  #reject H0
If p value <= .10   -> 'marginally significant'
If p value <= .05   -> 'significant'
If p value <= .01   -> 'highly significant.'  #accept H0



### Scipy - statistical tests - Kolmogorov-Smirnov test for goodness of fit
#(non-parametric)(for continuous dist)
#non-parameteric - no assumption of pdf (parameteric means normal dist)
scipy.stats.kstest(rvs, cdf, args=(), N=20, alternative='two-sided', mode='approx')
#H0:rvs is drawn from cdf
#cdf: If a string, it should be the name of a distribution in scipy.stats
#or a python callable which gives the cdf
#Returns: (D, p-value)

 

#Example 
from scipy import stats
x = np.linspace(-15, 15, 9)
>>> stats.kstest(x, 'norm')
(0.44435602715924361, 0.038850142705171065)  #<0.05, reject H0

>>> stats.kstest(stats.norm.rvs(size=100), 'norm')  
(0.058352892479417884, 0.88531190944151261)  #>0.05, dont reject H0



### Scipy - statistical tests - Kolmogorov-Smirnov statistic on 2 samples 
#(non parametric test)(continuous distribution)
scipy.stats.ks_2samp(data1, data2)
#non-parameteric - no assumption of pdf (parameteric means normal dist)
#H0: data1,data2 are drawn from the same continuous distribution.
#Returns (statistic, pvalue)

#Example 
from scipy import stats

rvs1 = stats.norm.rvs(size=200, loc=0., scale=1)
rvs2 = stats.norm.rvs(size=300, loc=0.5, scale=1.5)
>>> stats.ks_2samp(rvs1, rvs2)
(0.20833333333333337, 4.6674975515806989e-005)  #<0.05, reject H0 

>>> stats.ks_2samp(rvs1, rvs1)
Ks_2sampResult(statistic=0.0, pvalue=1.0)

### Scipy - statistical tests - Ansari-Bradley test for equal scale parameters
#(A non-parametric test for the equality of 2 variances, exact for n<55, else approx)
scipy.stats.ansari(x, y)
#H0: x,y have equal scale parameter (similar in shape ie variances)
#Returns (statistic, p-value)
>>> stats.ansari(rvs1, rvs2)
AnsariResult(statistic=29304.0, pvalue=1.0818589053932786e-07) #reject H0
>>> stats.ansari(rvs1, rvs1)
AnsariResult(statistic=20100.0, pvalue=1.0)  #Accept H0 


### Scipy - statistical tests - Kruskal-Wallis H-test 
#(non-parametric, like anova,Analysis of variance , n>5)
scipy.stats.kruskal(sample1, sample2,... )
#H0: population median of all of the groups are equal.
#returns (statistics, p-value)

#Example 
from scipy import stats
x = [1, 3, 5, 7, 9]
y = [2, 4, 6, 8, 10]
>>> stats.kruskal(x, y)
KruskalResult(statistic=0.27272727272727337, pvalue=0.60150813444058948) #>0.05, dont reject H0

### Scipy - statistical tests - Chi-square test of independence of variables in a contingency table.
scipy.stats.chi2_contingency(contingency_table, correction=True, lambda_=None)
#(non-parameteric, n>5)
#H0:observed frequencies in the contingency table are independent
#lambda_ as same as from power_divergence
#contingency_table could be RxC in 2 dimensions or higher dimensions
#Returns:
    chi2 : float,The test statistic.
    p : float,The p-value of the test
    dof : int,Degrees of freedom
    expected : ndarray, same shape as observed,
              The expected frequencies, based on the marginal sums of the table
 
#Example of contigency table 
#Suppose that we have two variables, 
#sex (male or female) and handedness (right or left handed). 
#Further suppose that 100 individuals are randomly sampled 
#from a very large population as part of a study of sex differences in handedness
        Handedness
Gender  Right handed    Left handed     Total
Male        43          9               52
Female      44          4               48 
Total       87          13              100 

#H0: male-female's  right or left handed are independent 

obs = np.array([[43,9], [44,4]])
>>> stats.chi2_contingency(obs)
(1.0724852071005921, 
0.300384770390566,  #>0.05, accept H0 
1, array([[45.24,  6.76],
       [41.76,  6.24]]))
       

### Scipy - statistical tests - Binomial test
scipy.stats.binom_test(x, n=None, p=0.5, alternative='two-sided')
#H0: probability of success given x out of n trials is p, for 'two-sided'
#probability of success given x out of n trials is <= p for 'greater'
#probability of success given x out of n trials is >= p for 'less'
#x: the number of successes, and give n 
#or if x has length 2, it is the number of successes and the number of failures, and ignore n 
#Returns p-value 

#Example 
#Problem - A soft drink company has invented a new drink, 
#and would like to find out if it will be as popular as the existing favorite drink. 
#For this purpose, its research department arranges 18 participants for taste testing. 
#Each participant tries both drinks in random order before giving his or her opinion. 

#It turns out that 5 of the participants like the new drink better, and the rest prefer the old one. 
#At .05 significance level, can we reject the notion that the two drinks are equally popular? 

#H0 : two drinks are equally popular ie p=0.5
> scipy.stats.binom_test(5, 18)              
0.096252441406249986             #>0.05, accept H0




### Scipy - statistical tests - Jarque-Bera goodness of fit test on sample data
#(parametric, n>2000)
scipy.stats.jarque_bera(x)
#H0: sample data has the skewness and kurtosis matching a normal distribution.
#returns (statistics, p-value)

#Example 
from scipy import stats

x = np.random.normal(0, 1, 100000)
y = np.random.rayleigh(1, 100000)

>>> stats.jarque_bera(x)
(4.7165707989581342, 0.09458225503041906)  #last one is p-value 
>>> stats.jarque_bera(y)
(6713.7098548143422, 0.0)


### Scipy - statistical tests - Shapiro-Wilk test for normality
scipy.stats.shapiro(x, a=None, reta=False)
#H0: x is from normal distribution
#returns (statistics, p-value)

from scipy import stats
np.random.seed(12345678)
x = stats.norm.rvs(loc=5, scale=3, size=100)
>>> stats.shapiro(x)
(0.9902572631835938, 0.685400664806366)  #last one is p-value, Accept H0 


### Scipy - statistical tests - Moods median test 
#(non-parametric)
scipy.stats.median_test(sample1, sample2, ..., lambda_ )
#H0: two or more samples come from populations with the same median
#By default, the statistic computed in this test is Pearson's chi-squared statistic. 

#Example 
#A biologist runs an experiment in which there are three groups of plants. 
#Group 1 has 16 plants, group 2 has 15 plants, and group 3 has 17 plants. 
#Each plant produces a number of seeds. The seed counts for each group are:
Group 1: 10 14 14 18 20 22 24 25 31 31 32 39 43 43 48 49
Group 2: 28 30 31 33 34 35 36 40 44 55 57 61 91 92 99
Group 3:  0  3  9 22 23 25 25 33 34 34 40 45 46 48 62 67 84
#Ho: g1, g2, g3 have same median 


g1 = [10, 14, 14, 18, 20, 22, 24, 25, 31, 31, 32, 39, 43, 43, 48, 49]
g2 = [28, 30, 31, 33, 34, 35, 36, 40, 44, 55, 57, 61, 91, 92, 99]
g3 = [0, 3, 9, 22, 23, 25, 25, 33, 34, 34, 40, 45, 46, 48, 62, 67, 84]
from scipy.stats import median_test
stat, p, med, tbl = median_test(g1, g2, g3)
#The median is
>>> med
34.0
>>> p
0.12609082774093244  #>0.5, don't reject H0 


