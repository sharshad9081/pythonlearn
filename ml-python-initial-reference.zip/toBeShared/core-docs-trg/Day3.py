###Let's undertand Covariance      and correlation again
#Consider two variables, x_0 and x_1, which correlate perfectly, but in opposite directions:

x = np.array([[0, 2], [1, 1], [2, 0]]).T
>>> x
array([[0, 1, 2],
       [2, 1, 0]])
#correlation between x_0 and x_1, is negative
>>> np.cov(x)
array([[ 1., -1.],
       [-1.,  1.]])
       

#note how x and y are combined:
x = [-2.1, -1,  4.3]
y = [3,  1.1,  0.12]
X = np.stack((x, y), axis=0) #row wise stack , axis=1, column wise stack 
>>> print(np.cov(X))
[[ 11.71        -4.286     ]
 [ -4.286        2.14413333]]
>>> print(np.cov(x, y))
[[ 11.71        -4.286     ]
 [ -4.286        2.14413333]]
>>> print(np.cov(x))
11.71
>>> np.corrcoef(x,y)   #standarized , cov/stdx*stdy
array([[ 1.        , -0.85535781],
       [-0.85535781,  1.        ]])

#Example with Pandas 
np.random.seed(42)
df = pd.DataFrame(np.random.randn(1000, 5),  columns=['a', 'b', 'c', 'd', 'e'])
>>> df.cov()
          a         b         c         d         e
a  0.998438 -0.020161  0.059277 -0.008943  0.014144
b -0.020161  1.059352 -0.008543 -0.024738  0.009826
c  0.059277 -0.008543  1.010670 -0.001486 -0.000271
d -0.008943 -0.024738 -0.001486  0.921297 -0.013692
e  0.014144  0.009826 -0.000271 -0.013692  0.977795


##HandsOn - 
Check in boston.csv
- RM       average number of rooms per dwelling
- MEDV     Median value of owner-occupied homes in $1000's
- LSTAT    % lower status of the population
- TAX      full-value property-tax rate per $10,000

Find the correlation between medv and LSTAT
Draw a scatter plot between medv and LSTAT
Find the correlation  between medv and RM

boston = pd.read_csv("toBeShared/data/boston.csv")
boston.head()
boston.columns


#Find the correlation between medv and LSTAT
boston[['medv', 'lstat']].corr()
boston[['medv', 'lstat']].cov()
np.corrcoef(boston.medv, boston.lstat) 
np.cov(boston.medv, boston.lstat)

#Draw a scatter plot between medv and LSTAT
boston.plot(x='medv', y= 'lstat', kind='scatter')
plt.show()

#Find the correlation  between medv and RM
boston[['medv', 'rm']].corr()



###Linear Regression and regression metrics 


Parameter for Lasso and Ridge Regression
    alpha = 0: Same coefficients as simple linear regression
    alpha = Inf: All coefficients zero 
    0 < alpha < Inf: coefficients between 0 and that of simple linear regression
                     called shrinkage of coefficients

Ridge
    It includes all of the features in the model and optimizes L2 cost function (Sum of square of error)
    used for overfitting, but not applicable of large no of features as selects all feature
    Works well with Highly Correlated Features

Lasso
    Optimizes L1 const function(sum of absolute error) 
    Along with shrinking coefficients, lasso performs feature selection as well. 
    ie Some of the coefficients become exactly zero, which is equivalent to the particular feature being excluded from the model.
    Very much  applicable for large no of features 
    Since it randomly chooses feature, does not work well with Highly Correlated Features
   
ElasticNet Model 
    Combination of L1 and L2 penalty 
    regParam , alpha
    elasticNetParam, l1_ratio
        corresponds to L1/L2 ratio,  in range [0, 1]. 
        For elasticParam = 0, the penalty is an L2 penalty(ridge). 
        For elasticParam = 1, it is an L1 penalty(lasso)
        
        
##Simple OLS 
boston = load_boston() #['DESCR', 'data', 'feature_names', 'target']

scaler = StandardScaler()
X = scaler.fit_transform(boston["data"])
Y = boston["target"]
X_train, X_test, y_train, y_test = train_test_split(X, Y, random_state=0)
m = LinearRegression().fit(X_train,y_train)
m.score(X_train,y_train)  #R^2 
m.score(X_test, y_test)
mean_squared_error(y_test, m.predict(X_test))


###Polynomial regression 

#create a function y = 3 - 2 * x + 3* x ** 2 - 5* x ** 3 

model = Pipeline([('poly', PolynomialFeatures(degree=3)),
                    ('linear', LinearRegression(fit_intercept=False))])

#without noise 
x = np.linspace(-1,1,51)
y = 3 - 2 * x + 3* x ** 2 - 5 * x ** 3 
model = model.fit(x[:, np.newaxis], y)
model.named_steps['linear'].coef_
#array([ 3., -2.,  3., -5.])                   
                    
#With noise                    
x = np.linspace(-1,1,51)
y = 3 - 2 * x + 3* x ** 2 - 5 * x ** 3 + np.random.randn(len(x))

model = model.fit(x[:, np.newaxis], y) #train sample
model.named_steps['linear'].coef_
#array([ 2.75883575, -2.91076068,  3.62235363, -3.88841027])

plt.plot(x,y, "bo", x, model.predict(x[:, np.newaxis]), "r-")
plt.show()

#With test score 
x = np.linspace(-1,1,51)
y = 3 - 2 * x + 3* x ** 2 - 5 * x ** 3 + np.random.randn(len(x))
X = x[:, np.newaxis]
model = model.fit(X[:45,:], y[:45]) #train sample
>>> model.score(X[:45,:], y[:45]) #.94
0.9086389883585138
>>> model.score(X[45:,:], y[45:])
-0.7750190601711837
#so what happened ????



###Example - boston - With alpha and Lasso , coefficients are sparse 


boston = load_boston() #['DESCR', 'data', 'feature_names', 'target']

scaler = StandardScaler()
X = scaler.fit_transform(boston["data"])
Y = boston["target"]



# Create a function called lasso,
def process(model, modelCV, alphas, names, X=X,y=Y, **kwargs):
    df = pd.DataFrame(index=names)    
    for alpha in alphas:
        m = model(alpha=alpha, **kwargs)        
        m.fit(X,y)        
        column_name = 'Alpha = %f' % alpha
        df[column_name] = m.coef_
    #Optimized alpha 
    lcv = modelCV(**kwargs)
    lcv.fit(X,y)  
    try:
        column_name = 'Best Alpha = %f(%f)' % (lcv.alpha_, lcv.l1_ratio_)
    except:
        column_name = 'Best Alpha = %f' % (lcv.alpha_, )
    df[column_name] = lcv.coef_
    return (df, lcv)

#Note with increasing alpha, coefficients are zero 
process(Lasso, LassoCV, [.0001, .5, 10], boston["feature_names"])   #coeff is zero 
process(Ridge, RidgeCV, [.0001, .5, 10], boston["feature_names"])   
process(ElasticNet, ElasticNetCV, [.0001, .5, 10], boston["feature_names"], l1_ratio=0.5) 


X_train, X_test, y_train, y_test = train_test_split(X, Y, random_state=0)
df, model = process(Lasso, LassoCV, [.0001, .5, 10], boston["feature_names"], X_train,y_train )   #coeff is zero 
model.score(X_train, y_train)
model.score(X_test, y_test)
#other metrics 
mean_squared_error(y_test, model.predict(X_test)) 	 #y_true, y_pred


df, model = process(Ridge, RidgeCV, [.0001, .5, 10], boston["feature_names"], X_train,y_train)   
model.score(X_train, y_train)
model.score(X_test, y_test)
#other metrics 
mean_squared_error(y_test, model.predict(X_test)) 	 #y_true, y_pred


df, model = process(ElasticNet, ElasticNetCV, [.0001, .5, 10], boston["feature_names"], X_train,y_train, l1_ratio=0.5) 
model.score(X_train, y_train)
model.score(X_test, y_test)
#other metrics 
mean_squared_error(y_test, model.predict(X_test)) 	 #y_true, y_pred

##First regression diagnostic 
from pandas.plotting import scatter_matrix
scatter_matrix(pd.DataFrame(X, columns=boston.feature_names), alpha=0.2, figsize=(6, 6), diagonal='kde')
plt.show()


##Residuals Plot
#Residuals are the difference between  target variable (y) and the predicted value (y), 
#to analyze the variance of the error of the regressor. 
#If the points are randomly dispersed around the horizontal axis, 
#a linear regression model is usually appropriate for the data; 
#otherwise(eg funnel data), a non-linear model(eg GLM, use statsmodels, SVC(nonlinear kernel), Boosting) is more appropriate. 

from yellowbrick.regressor import *

# Instantiate the linear model and visualizer

visualizer = ResidualsPlot(model)

visualizer.fit(X_train, y_train)  # Fit the training data to the model
visualizer.score(X_test, y_test)  # Evaluate the model on the test data
visualizer.poof()                 # Draw/show/poof the data
#visualizer.poof(outpath="pcoords.png") #sve to file, ext determines file type 

#Note that if the histogram is not desired, it can be turned off with the hist=False flag
visualizer = ResidualsPlot(ridge, hist=False)



##Prediction Error Plot
#A prediction error plot shows the actual targets from the dataset against the predicted values 

#Data scientists can diagnose regression models using this plot by comparing against the 45 degree line, 
#where the prediction exactly matches the model.


visualizer = PredictionError(model)

visualizer.fit(X_train, y_train)  # Fit the training data to the visualizer
visualizer.score(X_test, y_test)  # Evaluate the model on the test data
g = visualizer.poof()             # Draw/show/poof the data


##Alpha Selection in Regularization

# Create a list of alphas to cross-validate against
alphas = np.logspace(-10, 1, 400) #logspace(start, stop, num=50, endpoint=True, base=10.0, dtype=None)

visualizer = AlphaSelection(model)

visualizer.fit(X, Y)
g = visualizer.poof()


##A Q-Q plot is a scatterplot created by plotting two sets of quantiles against one another. 
#If both sets of quantiles came from the same distribution, we should see the points forming a line that's roughly straight. 

#In case of regression, error should come from normal (maches with 45 deg line 
#If there is exponential part in the plot, do a log transform of y 
#Example - qqplot
import statsmodels.api as sm

res = y_train - model.predict(X_train)
fig = sm.qqplot(res)
plt.show()

#log transforms 
#log1p(x) Calculates log(1 + x).
#expm1 exp(x) - 1, the inverse of log1p.


y_train_1 = np.log1p(y_train)
model = model.fit(X_train, y_train_1)
res = y_train_1 - model.predict(X_train)
fig = sm.qqplot(res)
plt.show()
#model 
model.score(X_train, y_train_1)
model.score(X_test, np.log1p(y_test))
y_pred = np.expm1(model.predict(X_test))
mean_squared_error(y_test, y_pred) 



###Handling  Multicollinearity

#Imports
import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor
from patsy import dmatrices

df = pd.read_csv('tobeShared/data/loan.csv')
df = df._get_numeric_data() #drop non-numeric cols
#drop columns where all NaN 
df = df.dropna(how='all',axis=1) #axis=0, rowwise, axis=1 columnswise 
df.index = df.id
df.head()

#Get subset 
df = df[['annual_inc','loan_amnt', 'funded_amnt','dti']].dropna() 

#run the cell, capturing stdout, stderr, and IPython’s rich display() calls.
#and discard 
%%capture
#gather features
features = "+".join(set(df.columns) - {'annual_inc'})

#Construct a single design matrix given a formula_like and data.
y, X = dmatrices('annual_inc ~' + features, df, return_type='dataframe')


#Calculate VIF Factors
# For each X, calculate VIF and save in dataframe
vif = pd.DataFrame()
vif["VIF Factor"] = [variance_inflation_factor(X.values, i) for i in range(X.shape[1])]
vif["features"] = X.columns
>>> vif.round(1)
   VIF Factor     features
0         7.7    Intercept
1         1.0          dti
2        60.0  funded_amnt
3        60.0    loan_amnt






##More Regression diagnostic Using statsmodel, as it gives various stats 
#note statsmodel requires DF 
boston = load_boston()
>>> type(boston.data)
<class 'numpy.ndarray'>
>>> type(boston.target)
<class 'numpy.ndarray'>
>>> boston.feature_names
array(['CRIM', 'ZN', 'INDUS', 'CHAS', 'NOX', 'RM', 'AGE', 'DIS', 'RAD','TAX', 'PTRATIO', 'B', 'LSTAT'], dtype='<U7')
       
bostonDF = pd.DataFrame(boston.data, columns=boston.feature_names)
bostonDF['MEDV'] = boston.target



##Regression diagnostic 

import statsmodels.api as sm
import statsmodels.formula.api as smf

# Fit regression model (using the natural log of one of the regressors)
# + means add , - means remove the term 
#(does not exist in statsmodel). means all remaining ie CRIM + ZN ...
#can mention individually, each can be transformed eg np.log(CRIM)
# 1 + means include intercept (default) + -1  means exclude 
#* for including interaction, eg CRIM*ZN = CRIM + ZN + CRIM:ZN 
#: for only interaction CRIM:ZN 
#for categorical use C() eg C(chas)
#for including any operator use I(x), eg I(x1 + x2) inside a formula to represent the sum of x1 and x2  
#to quote variable Q(name) eg Q("weight.in.kg")  

results = smf.ols('MEDV ~ CRIM + ZN', data=bostonDF).fit()
# Inspect the results
>>> print(results.summary())
                            OLS Regression Results
==============================================================================
Dep. Variable:                   MEDV   R-squared:                       0.233
Model:                            OLS   Adj. R-squared:                  0.230
Method:                 Least Squares   F-statistic:                     76.21
Date:                Sat, 02 Feb 2019   Prob (F-statistic):           1.23e-29
Time:                        11:59:31   Log-Likelihood:                -1773.3
No. Observations:                 506   AIC:                             3553.
Df Residuals:                     503   BIC:                             3565.
Df Model:                           2
Covariance Type:            nonrobust
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
Intercept     22.4668      0.442     50.862      0.000      21.599      23.335
CRIM          -0.3498      0.043     -8.202      0.000      -0.434      -0.266
ZN             0.1164      0.016      7.406      0.000       0.086       0.147
==============================================================================
Omnibus:                      163.895   Durbin-Watson:                   0.756
Prob(Omnibus):                  0.000   Jarque-Bera (JB):              429.044
Skew:                           1.619   Prob(JB):                     6.83e-94
Kurtosis:                       6.140   Cond. No.                         31.9
==============================================================================

   
#Understanding 
Coef 
    the estimates of  mean values of the coefficients  
    
coefficientStandardErrors            
    = estimate of  standard deviation of parameter estimate 
    
[....]              
    95% CI        
   =  mean +/- 2* std err ie sd  
   = coef  +/-  2* coefficientStandardErrors     
  
Df Total            
    These are the degrees of freedom associated with the sources of variance
    ie no of observation 
    
Df Model            
    No of independent variables (excluding intercept)
    
residualDegreeOfFreedom, Df Residuals        
    Df total - Df Model 

R-squared           
     How model fits the data? Towards 1 is better 
     
Adj. R-squared      
    adjusts for the number of terms in a model. 
    If you add more and more useless variables to a model, 
    adjusted r-squared will decrease. 
    If you add more useful variables, adjusted r-squared will increase
                    
Prob (F-statistic)  
    <0.05, model is significant 
    
AIC, BIC            
    Akaike’s 'An Information Criterion'(AIC) for the fitted model
    lower the better. Used for comparing two models 
    Note  one model needs to be a subset of the other
    
Log-Likelihood   
    Value where model iteration is stopped, This is maximized
   
t   , tValues                
    These are the t-statistics used in testing 
    Dividing the coefficient by its standard error calculates a t-value
    
P>|t|   , pValues             
    < 0.05, coefficient is significant , H0= coefficinet is zero 
    
    
##Regression diagnostic 
from statsmodels.compat import lzip
import statsmodels.stats.api as sm

#https://www.statsmodels.org/dev/diagnostic.html
#Goal : Normality of the residuals, hence dont want to reject H0 in below 
Jarque-Bera     
    a goodness-of-fit test with normal distribution (normality test of data)
    HO: sample data have the skewness and kurtosis matching a normal distribution
    Samples from a normal distribution have an expected skewness of 0 
    and an expected  kurtosis of 3
    Prob < 0.05, reject H0 
Omnibus/Prob(Omnibus) 
    Omnibus - close to zero which would indicate normalcy. 
    The Prob (Omnibus) - H0 : residuals are normally distributed. 
    We hope to see something close to 1 here. 
    Prob < 0.05, reject H0 
       
#Jarque-Bera test:
name = ['Jarque-Bera', 'Chi^2 two-tail prob.', 'Skew', 'Kurtosis']
test = sm.jarque_bera(results.resid)
lzip(name, test)

[('Jarque-Bera', 429.044286915751), ('Chi^2 two-tail prob.', 6.826794818476696e-
94), ('Skew', 1.6194713938245782), ('Kurtosis', 6.139932526419318)]

#Omni test:
name = ['Chi^2', 'Two-tail probability']
test = sm.omni_normtest(results.resid)
lzip(name, test)
[('Chi^2', 163.89547216560533), ('Two-tail probability', 2.573655508107128e-36)]

##Multicollinearity
Condition Number 
    This test measures the sensitivity of a function’s output as compared to its input 
    When we have multicollinearity, we can expect much higher fluctuations 
    to small changes in the data, hence, we hope to see a relatively small number, 
    something below 30. 
    
#Condition number:
np.linalg.cond(results.model.exog)

31.942380775363098

##Linearity
#Harvey-Collier multiplier test for H0 
#the linear specification is correct: (<0.05, reject H0)
name = ['t value', 'p value']
test = sm.linear_harvey_collier(results)
lzip(name, test)

[('t value', 0.23182797490243118), ('p value', 0.8167660981271478)]

##AutoCorrelation 
Durbin-Watson   
    The Durbin Watson Test is a measure of autocorrelation (also called serial correlation) 
    in residuals from regression analysis. 
    Autocorrelation is the similarity of a time series over successive time intervals. 
    It can lead to underestimates of the standard error 
    and can cause you to think predictors are significant when they are not
    The Durbin Watson test reports a test statistic, with a value from 0 to 4, where:
        •2 is no autocorrelation.
        •0 to <2 is positive autocorrelation (common in time series data).
        •>2 to 4 is negative autocorrelation (less common in time series data).

#Breusch-Pagan test for Ho: no autocorrelation of residuals
    lm (float) – Lagrange multiplier test statistic
    lmpval (float) – p-value for Lagrange multiplier test
    fval (float) – fstatistic for F test, alternative version of the same test based on F test for the parameter restriction
    fpval (float) – pvalue for F test
    resstore (instance (optional)) – a class instance that holds intermediate results. Only returned if store=True
name = [ "Lagrange multiplier test statistic", "p-value Lagrange multiplier test",
"fstatistic for F test","pvalue for F test"]
test = sm.acorr_breusch_godfrey(results)
lzip(name, test)
[('Lagrange multiplier test statistic', 223.25530697201108), ('p-value Lagrange
multiplier test', 5.777392225033314e-38), ('fstatistic for F test', 22.573280431
985044), ('pvalue for F test', 5.413978968117236e-51)]

##Heteroskedasticity tests
#Ho = all observations have the same error variance, i.e. errors are homoscedastic.

#Breush-Pagan test:
name = ['Lagrange multiplier statistic', 'p-value',
        'f-value', 'f p-value']
test = sm.het_breuschpagan(results.resid, results.model.exog)
lzip(name, test)

[('Lagrange multiplier statistic', 0.7582500606996831), ('p-value', 0.6844600290
392309), ('f-value', 0.377442858372021), ('f p-value', 0.6858063946962477)]

Goldfeld-Quandt test

name = ['F statistic', 'p-value']
test = sm.het_goldfeldquandt(results.resid, results.model.exog)
lzip(name, test)

[('F statistic', 1.0960604120511421), ('p-value', 0.23444785752670075)]



##Influence tests
#Once created, an object of class OLSInfluence holds attributes and methods 
#that allow users to assess the influence of each observation. 

#For example, we can compute and extract the first few rows of DFbetas by:

from statsmodels.stats.outliers_influence import OLSInfluence
test_class = OLSInfluence(results)
test_class.dfbetas[:5,:]
array([[-0.00301154,  0.00290872,  0.00118179],
       [-0.06425662,  0.04043093,  0.06281609],
       [ 0.01554894, -0.03556038, -0.00905336],
       [ 0.17899858,  0.04098207, -0.18062352],
       [ 0.29679073,  0.21249207, -0.3213655 ]])

#Useful information on leverage can also be plotted:
Leverage is a measure of how far away the independent variable values of an observation are from those of the other observations.

High-leverage points are those observations, if any, made at extreme or outlying values of the independent variables such that the lack of neighboring observations means that the fitted regression model will pass close to that particular observation
    An outlier is a data point whose response y does not follow the general trend of the rest of the data.
    A data point has high leverage if it has "extreme" predictor x values. With a single predictor, an extreme x value is simply one that is particularly high or low. With multiple predictors, extreme x values may be particularly high or low for one or more predictors, or may be "unusual" combinations of predictor values (e.g., with two predictors that are positively correlated, an unusual combination of predictor values might be a high value of one predictor paired with a low value of the other predictor).

Note that — for our purposes — we consider a data point to be an outlier only if it is extreme with respect to the other y values, not the x values.

A data point is influential if it unduly influences any part of a regression analysis, such as the predicted responses, the estimated slope coefficients, or the hypothesis test results. Outliers and high leverage data points have the potential to be influential,

from statsmodels.graphics.regressionplots import *
fig, (ax1,ax2) = plt.subplots(1,2, figsize=(8,6))
plot_leverage_resid2(results, ax = ax1)
influence_plot(results, ax = ax2)
plt.show()


#Other methods of statsmodels.stats.outliers_influence.OLSInfluence
#when comparing take absolute values, 
#N = number of observations, p= number of parameters

cooks_distance()                Cooks distance , > 4/(N-p-1) outliers

cov_ratio()                     covariance ratio between LOOO and original                                
                                Uses leave-one-observation-out (LOOO) auxiliary regression                                
                                COVRATIO statistic measures the change in the determinant of the covariance matr ix                                
                                of the estimates by deleting the ith observation                                
                                Use if dataset is not large , >(1+3P/N) requires attiontion
                                
det_cov_params_not_obsi()       determinant of cov_params of all LOOO regressions
params_not_obsi()               parameter estimates for all LOOO regressions
sigma2_not_obsi()               error variance for all LOOO regressions

dfbetas()                       dfbetas , > 2/sqrt(N) outtliers
dffits()                        dffits measure for influence of an observation                                
                                > 2/sqrt(p/N) requires attention
                                
dffits_internal()               dffits measure for influence of an observation

resid_press()                   PRESS residuals
ess_press()                     predicted residual error sum of squares (PRESS) statistic                                
                                each observation in turn is removed and the model is refitted using the remaining observation s.                                
                                The out-of-sample predicted value is calculated for the omitted observation in each cas e,                                
                                and the PRESS statistic is calculated as the sum of the squares of all the resulting prediction errors                                
                                Lower PRESS statistic is better (can be used to compare two models)                                

get_resid_studentized_external([sigma])     calculate studentized residuals                                            
                                             >2 is outliers
                                             
resid_studentized_external()                studentized residuals using LOOO varian ce
resid_studentized_internal()                studentized residuals using variance from O LS

hat_diag_factor()               factor of diagonal of hat_matrix used in influence
hat_matrix_diag()               diagonal of the hat_matrix for OLS                                
                                Maps the vector of dependent variable values to the vector of  predicted value s.                                
                                It describes the influence each response value has on each fitted value.                                
                                The diagonal elements of the hat matrix are the leverages,                                
                                which describe the influence each response value has on the fitted val ue                                
                                for that same observation                                
                                ith diagonal > 1/N means ith observation has more levergae/influence on model                                

influence()                     influence measure

resid_std()                     estimate of standard deviation of the residua ls
resid_var()                     estimate of variance of the residuals                                
                                the variance of residuals must be constant, 
                                and they must have a mean of zero                                
                                Can be seen from plt.scatter(np.arange(i.resid_var.size),i.resid_var)                                
                                OR from scipy.stats.describe(i.resid_var)                                

summary_frame()                 Creates a DataFrame with all available influence results.
summary_table([float_fmt])      create a summary table with all influence and outlier measur es


##Using RANSAC for the data as it has some outliers 
#note R^2 would decrease, but estimation is robust 
boston = load_boston()

X_train, X_test, y_train, y_test = train_test_split(boston.data, boston.target, random_state=0)

# Fit line using all data
lr = LinearRegression()
lr.fit(X_train, y_train)
lr.score(X_train, y_train)
lr.score(X_test, y_test)

# Robustly fit linear model with RANSAC algorithm
ransac = RANSACRegressor()
ransac.fit(X_train, y_train)
ransac.score(X_train, y_train)
ransac.score(X_test, y_test)

#Find oulier 
inlier_mask = ransac.inlier_mask_
outlier_mask = np.logical_not(inlier_mask)
#y inliers 
y_train[inlier_mask]
#y outliers 
y_train[outlier_mask], X_train[outlier_mask]


# Compare estimated coefficients
print("Estimated coefficients (linear regression, RANSAC):")
df = pd.DataFrame(index=boston.feature_names)
df['linear regression'] = lr.coef_
df['RANSAC'] = ransac.estimator_.coef_
print(df)

##Scikits answer to anomaly detection 
#run plot_anomaly_comparison.py



##Check with Compare result with all 
all = " + ".join(boston.feature_names.tolist())
results2 = smf.ols('MEDV ~ %s' % (all,) , data=bostonDF).fit()
# Inspect the results

>>> print(results2.summary())
                            OLS Regression Results
==============================================================================
Dep. Variable:                   MEDV   R-squared:                       0.741
Model:                            OLS   Adj. R-squared:                  0.734
Method:                 Least Squares   F-statistic:                     108.1
Date:                Sat, 02 Feb 2019   Prob (F-statistic):          6.95e-135
Time:                        12:00:13   Log-Likelihood:                -1498.8
No. Observations:                 506   AIC:                             3026.
Df Residuals:                     492   BIC:                             3085.
Df Model:                          13
Covariance Type:            nonrobust
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
Intercept     36.4911      5.104      7.149      0.000      26.462      46.520
CRIM          -0.1072      0.033     -3.276      0.001      -0.171      -0.043
ZN             0.0464      0.014      3.380      0.001       0.019       0.073
INDUS          0.0209      0.061      0.339      0.735      -0.100       0.142
CHAS           2.6886      0.862      3.120      0.002       0.996       4.381
NOX          -17.7958      3.821     -4.658      0.000     -25.302     -10.289
RM             3.8048      0.418      9.102      0.000       2.983       4.626
AGE            0.0008      0.013      0.057      0.955      -0.025       0.027
DIS           -1.4758      0.199     -7.398      0.000      -1.868      -1.084
RAD            0.3057      0.066      4.608      0.000       0.175       0.436
TAX           -0.0123      0.004     -3.278      0.001      -0.020      -0.005
PTRATIO       -0.9535      0.131     -7.287      0.000      -1.211      -0.696
B              0.0094      0.003      3.500      0.001       0.004       0.015
LSTAT         -0.5255      0.051    -10.366      0.000      -0.625      -0.426
==============================================================================
Omnibus:                      178.029   Durbin-Watson:                   1.078
Prob(Omnibus):                  0.000   Jarque-Bera (JB):              782.015
Skew:                           1.521   Prob(JB):                    1.54e-170
Kurtosis:                       8.276   Cond. No.                     1.51e+04
==============================================================================

Warnings:
[1] Standard Errors assume that the covariance matrix of the errors is correctly
 specified.
[2] The condition number is large, 1.51e+04. This might indicate that there are
strong multicollinearity or other numerical problems.



           















###Logistic Regression 
#Check 
#https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html

#Note l2 penalty 
#good for overfitting (Ridge) and highly correlated data(as coef shrinkage)
#l1 penalty
#many coef is zero, so feature selection , good for large selection

#solver 
solver : str, {‘newton-cg’, ‘lbfgs’, ‘liblinear’, ‘sag’, ‘saga’}, default: ‘liblinear’.
For small datasets, ‘liblinear’ is a good choice, whereas ‘sag’ and ‘saga’ are faster for large ones.
For multiclass problems, only ‘newton-cg’, ‘sag’, ‘saga’ and ‘lbfgs’ handle multinomial loss; ‘liblinear’ is limited to one-versus-rest schemes.
‘newton-cg’, ‘lbfgs’ and ‘sag’ only handle L2 penalty, whereas ‘liblinear’ and ‘saga’ handle L1 penalty.
Note that ‘sag’ and ‘saga’ fast convergence is only guaranteed on features with approximately the same scale. You can preprocess the data with a scaler from sklearn.preprocessing
#C : float, default: 1.0
#Inverse of regularization strength; must be a positive float. 
#Like in support vector machines, smaller values specify stronger regularization.
#penalty : str, ‘l1’ or ‘l2’, default: ‘l2’


X, y = load_iris(return_X_y=True)
scaler = StandardScaler()
X = scaler.fit_transform(X)
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)

clf = LogisticRegression(random_state=0, solver='lbfgs',multi_class='multinomial').fit(X_train, y_train)

clf.predict(X_test)
clf.predict_proba(X_test)  #predicted prob in each class 
clf.score(X_train, y_train)
clf.score(X_test, y_test)


#Or SGDClassifier with loss=log 
#loss : str, default: ‘hinge’
#The loss function to be used. Defaults to ‘hinge’, which gives a linear SVM.
#The possible options are ‘hinge’, ‘log’, ‘modified_huber’, ‘squared_hinge’, ‘perceptron’, or a regression loss: ‘squared_loss’, ‘huber’, ‘epsilon_insensitive’, or ‘squared_epsilon_insensitive’.
#penalty : str, ‘none’, ‘l2’, ‘l1’, or ‘elasticnet’
#https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.SGDClassifier.html

sgd = SGDClassifier(loss='log').fit(X_train, y_train)
sgd.predict(X_test)
sgd.predict_proba(X_test)  #predicted prob in each class 
sgd.score(X_train, y_train)
sgd.score(X_test, y_test)






###Example of Multiclass with Iris 

from sklearn.multiclass import *
ovo = OneVsOneClassifier(LogisticRegression()).fit(X_train, y_train)
ovo.predict(X_test)


###Example of multiclass learning using OvR for iris:
from sklearn.multiclass import *
ovr = OneVsRestClassifier(LogisticRegression()).fit(X_train, y_train)
ovr.predict(X_test)


###X variable importance 
#z values of the each X, variable 
#Look at their absolute values, Highest are most important , Remove those near to zero
#OR do a waldtest


#There is no way to switch off regularization in scikit-learn, 
#but you can make it ineffective by setting the tuning parameter C to a large number.

#binary.csv : School admissions
#admit: Yes, no ,variables:  gre, gpa and rank(categorical)
#Institutions with a rank of 1 have the highest prestige, 

# module imports
from patsy import dmatrices
import pandas as pd
from sklearn.linear_model import LogisticRegression
import statsmodels.api as sm

# read in the data & create matrices
df = pd.read_csv("https://stats.idre.ucla.edu/stat/data/binary.csv")
y, X = dmatrices('admit ~ gre + gpa + C(rank)', df, return_type = 'dataframe')

# sklearn output
model = LogisticRegression(fit_intercept = False, C = 1e9)
mdl = model.fit(X, y)
model.coef_

# sm
logit = sm.Logit(y, X)
logit.fit().params
print(logit.fit().summary2())
Optimization terminated successfully.
         Current function value: 0.573147
         Iterations 6
                        Results: Logit
===============================================================
Model:              Logit            No. Iterations:   6.0000
Dependent Variable: admit            Pseudo R-squared: 0.083
Date:               2019-02-02 19:16 AIC:              470.5175
No. Observations:   400              BIC:              494.4663
Df Model:           5                Log-Likelihood:   -229.26
Df Residuals:       394              LL-Null:          -249.99
Converged:          1.0000           Scale:            1.0000
---------------------------------------------------------------
                 Coef.  Std.Err.    z    P>|z|   [0.025  0.975]
---------------------------------------------------------------
Intercept       -3.9900   1.1400 -3.5001 0.0005 -6.2242 -1.7557
C(rank)[T.2]    -0.6754   0.3165 -2.1342 0.0328 -1.2958 -0.0551
C(rank)[T.3]    -1.3402   0.3453 -3.8812 0.0001 -2.0170 -0.6634
C(rank)[T.4]    -1.5515   0.4178 -3.7131 0.0002 -2.3704 -0.7325
gre              0.0023   0.0011  2.0699 0.0385  0.0001  0.0044
gpa              0.8040   0.3318  2.4231 0.0154  0.1537  1.4544
===============================================================

#Wald_test 
#an overall effect of rank using the wald.test 
#A linear hypothesis has the form 
R params = q 
#where R is restriction the matrix that defines the linear combination of parameters 
#and q is the hypothesized value.

#To test whether some parameters are zero, 
#the R matrix has a 1 in the column corresponding to the position of the parameter 
#and zeros everywhere else, and q is zero, which is the default. 

#Each row specifies a linear combination of parameters, 
#which defines a hypothesis as part of the overall or joint hypothesis.

In this case, the simplest way to get the restriction matrix is by using the corresponding rows of an identity matrix

#To test whether some parameters are zero, 
logit = sm.Logit(y, X)
results = logit.fit()

R = np.eye(len(results.params))[1:6] #remove intercepts and rest in order as given in summary

#lm.wald_test(R) will provide the test for the joint hypothesis 
#that the 5 parameters are zero.

>>> results.wald_test(R)  #reject H0 
<class 'statsmodels.stats.contrast.ContrastResults'>
<Wald test: statistic=[[20.89532374]], p-value=0.00011067929127474455>

#to check gpa is gero,
#reject H0 
>>> results.wald_test([0., 0., 0., 0., 0., 1.])
<class 'statsmodels.stats.contrast.ContrastResults'>
<Wald test: statistic=[[5.87150405]], p-value=0.015387899401486294>
    
    


#GLM: Logistic regression, Probit regression.
#Probit analysis will produce results similar logistic regression. 
#The choice of probit versus logit depends largely on individual preferences. 
dir(sm.families) 
#GLM is class, glm is formula based 
logit_model = smf.glm('admit ~ gre + gpa + C(rank)', data=df, family=sm.families.Binomial())
print(logit_model.fit().summary2())
>>> print(logit_model.fit().summary2())
               Results: Generalized linear model
===============================================================
Model:              GLM              AIC:            470.5175
Link Function:      logit            BIC:            -1902.1195
Dependent Variable: admit            Log-Likelihood: -229.26
Date:               2019-02-02 19:19 LL-Null:        -249.99
No. Observations:   400              Deviance:       458.52
Df Model:           5                Pearson chi2:   397.
Df Residuals:       394              Scale:          1.0000
Method:             IRLS
---------------------------------------------------------------
                 Coef.  Std.Err.    z    P>|z|   [0.025  0.975]
---------------------------------------------------------------
Intercept       -3.9900   1.1400 -3.5001 0.0005 -6.2242 -1.7557
C(rank)[T.2]    -0.6754   0.3165 -2.1342 0.0328 -1.2958 -0.0551
C(rank)[T.3]    -1.3402   0.3453 -3.8812 0.0001 -2.0170 -0.6634
C(rank)[T.4]    -1.5515   0.4178 -3.7131 0.0002 -2.3704 -0.7325
gre              0.0023   0.0011  2.0699 0.0385  0.0001  0.0044
gpa              0.8040   0.3318  2.4231 0.0154  0.1537  1.4544
===============================================================




##Clasification metrics 
'''
precision
    for all instances classified positive, what percent was correct?
recall
    for all instances that were actually positive, what percent was classified correctly? ”
f1 score
    harmonic mean of precision and recall 
    the weighted average of F1 should be used to compare classifier models, not global accuracy.
support
    The support is the number of occurrences of each class in y_true.
    Support is the number of actual occurrences of the class in the specified dataset. 
    Imbalanced support in the training data may indicate structural weaknesses 
    in the reported scores of the classifier 
    and could indicate the need for stratified sampling or rebalancing. 
    Support doesn’t change between models but instead diagnoses the evaluation process. 
'''
#check meaning of average 
#https://scikit-learn.org/stable/modules/model_evaluation.html#from-binary-to-multiclass-and-multilabel 
#use weighted 

y_pred = clf.predict(X_test)
accuracy_score(y_test, y_pred)
confusion_matrix(y_test, y_pred)
precision_recall_fscore_support(y_test, y_pred, average='weighted')
precision_score(y_test, y_pred, average='weighted') 	
recall_score(y_test, y_pred, average='weighted') 	
f1_score(y_test, y_pred, average='weighted')
#It is possible to compute per-label precisions, recalls, F1-scores and supports 
#instead of averaging:
precision_recall_fscore_support(y_test, y_pred, average=None)

##Confusion_matric plot 
import seaborn as sns
sns.heatmap(confusion_matrix(y_test,y_pred),annot=True)
           
           
           
##Visual Model Evaluation-ClassificationReport
#Poisonous mushroom model 
#Display for each class, precision, recall and f1 



from yellowbrick.classifier import *
from sklearn_pandas import *
def model_selection(X, y, estimator, return_model=False):
    #transformer for each column 
    feature_def = gen_features(
        columns=features,
        classes=[LabelEncoder]  #scikit_pandas can not handle OneHotEncoder after LabelEncoder as LabelEncoder expects 1D, oneHotEncoder expects 2D 
    )                           #Can use LabelBinarizer which is same as LabelEncoder, then OneHotEncoder
    X_mapper = DataFrameMapper(feature_def)
    y = LabelEncoder().fit_transform(y.values.ravel())
    #Note features categorical, so, convert them to OneHotEncoding 
    model = Pipeline([
        ('mapper', X_mapper),
        ('hotencoder', OneHotEncoder()), #OneHotEncoder requires numerical categorical 
        ('estimator', estimator)
    ])
    #
    model.fit(X, y)
    expected  = y
    predicted = model.predict(X)
    # Compute and return the F1 score (the harmonic mean of precision and recall)
    if not return_model:
        return (f1_score(expected, predicted))
    else:
        return model

def visual_model_selection(X, y, estimator):
    model = model_selection(X, y, estimator, return_model=True)
    # Create a new figure to draw the classification report on
    _, ax = plt.subplots()
    # Instantiate the classification model and visualizer
    visualizer = ClassificationReport( model, ax=ax, classes=['edible', 'poisonous'] )
    visualizer.fit(X, y)
    visualizer.score(X, y)
    visualizer.poof()

dataset = pd.read_csv('tobeShared/data/mushroom.csv')
names = [
    'class',
    'cap-shape',
    'cap-surface',
    'cap-color'
]
dataset.columns = names
>>> dataset.head()
       class cap-shape cap-surface cap-color
0     edible    convex      smooth    yellow
1     edible      bell      smooth     white
2  poisonous    convex       scaly     white
3     edible    convex      smooth      gray
4     edible    convex       scaly    yellow

features = ['cap-shape', 'cap-surface', 'cap-color']
target   = ['class']

X = dataset[features]
y = dataset[target]  
visual_model_selection(X, y, LinearSVC())
visual_model_selection(X, y, NuSVC())
visual_model_selection(X, y, SVC())
visual_model_selection(X, y, SGDClassifier())
visual_model_selection(X, y, KNeighborsClassifier())
visual_model_selection(X, y, LogisticRegressionCV())
visual_model_selection(X, y, LogisticRegression())
visual_model_selection(X, y, BaggingClassifier())
visual_model_selection(X, y, ExtraTreesClassifier())
visual_model_selection(X, y, RandomForestClassifier())

    
    
##ROCAUC
#A ROCAUC (Receiver Operating Characteristic/Area Under the Curve) plot allows the user 
#to visualize the tradeoff between the classifier’s sensitivity and specificity.
#true curve would be full square in graph such that area under the curve is  1 

#ROC curves are typically used in binary classification


#Lets take breastCancer 
#https://archive.ics.uci.edu/ml/datasets/Breast+Cancer+Wisconsin+(Diagnostic)
#check breast_cancer.csv 
#Diagnosis (M = malignant,1, B = benign,0) 
1) ID number
2) Diagnosis (M = malignant, B = benign)
3-32)Ten real-valued features are computed for each cell nucleus:
a) radius (mean of distances from center to points on the perimeter)
b) texture (standard deviation of gray-scale values)
c) perimeter
d) area
e) smoothness (local variation in radius lengths)
f) compactness (perimeter^2 / area - 1.0)
g) concavity (severity of concave portions of the contour)
h) concave points (number of concave portions of the contour)
i) symmetry
j) fractal dimension ("coastline approximation" - 1)


data = load_breast_cancer()
X = data['data']
y = data['target']
X_train, X_test, y_train, y_test = train_test_split(X, y)
viz = ROCAUC(LogisticRegression())
viz.fit(X_train, y_train)
viz.score(X_test, y_test)
viz.poof() # GOOD 





     
         
 
    
    
    
    
    
    
    
    
    
    
    
    
    

















###Decision Trees 

#Simple to understand and to interpret. Trees can be visualised.
#Does not require preprocessing 
#cons: prone to overfitting 
#Solution- Consider performing dimensionality reduction (PCA, ICA, or Feature selection) 
#beforehand to give tree a better chance of finding features that are discriminative

#https://scikit-learn.org/stable/modules/generated/sklearn.tree.DecisionTreeClassifier.html

#criterion : string,  (default=”gini”) or entropy

#splitter : “best” to choose the best split and “random” to choose the best random split.

#Use max_depth=3 as an initial tree depth , then increase the depth.

#min_samples_leaf=5(or float as %) as an initial value.(low value-overfit, large value-underfit)
#The minimum number of samples required to be at a leaf node.
#(alternative parameter is min_samples_split)
#The minimum number of samples required to split an internal node:

#balance the data , If not balanced, use  class_weight=“balanced”, auto balancing
#class_weight : {class_label: weight, ..}   


#Main attributes 
#feature_importances_  :    Return the feature importances/Gini importance.
#  The higher, the more important the feature [n_features]

#tree_ : Tree object
#max_features_ : int,  The inferred value of max_features.

#DecisionTreeClassifier is capable of both binary 
#(where the labels are [-1, 1]) classification 
#and multiclass (where the labels are [0, …, K-1]) classification.


iris = load_iris()
X_train, X_test, y_train, y_test = train_test_split(iris.data, iris.target, random_state=0)

clf = DecisionTreeClassifier()
clf.get_params()  # check default value of all params 
clf = clf.fit(X_train, y_train)

clf.predict(X_test)

#the probability of each class can be predicted
clf.predict_proba(X_test)

#feature importance 
clf.feature_importances_
array([0.02014872, 0.02014872, 0.90597266, 0.05372991])

>>> iris.feature_names
['sepal length (cm)', 'sepal width (cm)', 'petal length (cm)', 'petal width (cm)']

cross_val_score(clf, iris.data, iris.target, cv=10)

clf.score(X_train, y_train)
clf.score(X_test, y_test)

#other classification metrics 
precision_recall_fscore_support(y_test, clf.predict(X_test), average='weighted')
#(0.9763157894736842, 0.9736842105263158, 0.9739522830846216, None)

#check the decision Tree visualization 
#install graphvz from https://graphviz.gitlab.io/_pages/Download/Download_windows.html
#and 
$ pip install graphviz
#example 
import graphviz 
dot_data = export_graphviz(clf, out_file=None, 
                         feature_names=iris.feature_names,  
                         class_names=iris.target_names,  
                         filled=True, rounded=True,  
                         special_characters=True)  
graph = graphviz.Source(dot_data)  
graph.render('iris') #'iris.pdf'

#In jupyter 
import pydotplus, io
from IPython.display import Image
dot_data = io.StringIO()
tree.export_graphviz(clf,
                     out_file = dot_data,
                     feature_names = features,
                     filled=True, rounded=True,
                     impurity=False)
graph = pydotplus.graph_from_dot_data(dot_data.getvalue())
Image(graph.create_png())




##HandsON - Boston data with DecisionTreeRegressor 
boston = load_boston()
regressor = DecisionTreeRegressor(random_state=0)
cross_val_score(regressor, boston.data, boston.target, cv=10)
array([ 0.61..., 0.57..., -0.34..., 0.41..., 0.75...,
        0.07..., 0.29..., 0.33..., -1.42..., -1.77...])



##Features with Categorical 
#Note sklearn can not handle categorical string directly (y or feature)
#Use LabelEncoder to get numeric categorical 
#for Feature, it should be one-hot encoded as well 
#(OneHotEncoder after LabelEncoder     or LabelBinarizer)

#Note: Only using LabelEncoder -converts to integers 
#which the DecisionTreeClassifier() will treat as numeric. 
#If your categorical data is not ordinal, this is not good 
#- you'll end up with splits that do not make sense. 
#Using a OneHotEncoder is the only current valid way, but is computationally expensive.

#note Ordinal Data- data having natural order 
#eg 
#Like 	Like Somewhat 	Neutral 	Dislike Somewhat 	Dislike
#1 	    2 	            3 	        4 	                5 



#OPTION-1 , in place of LabelEncoder 
df = pd.read_csv('toBeShared/data/surveys.csv')
df.rename(columns={'Order Quantity':'Order_Quantity', 
    'Improvement Area' :'Improvement_Area',
    'Customer type' : 'Customer_Type',
    'Overall Satisfaction': 'Overall_Satisfaction'}, inplace=True)
    
df['Region'] = df['Region'].map( {'EAST': 1, 'WEST': 2, 'NORTH': 3, 'SOUTH':4} ).astype(int)
df['Customer_Type'] = df['Customer_Type'].map({'Prime': 1, 'NonPrime': 0}).astype(int)
df['Improvement_Area'] = df['Improvement_Area'].map({'Website UI':1, 'Packing & Shipping':2, 'Product Quality':3,}).astype(int)
df['Overall_Satisfaction'] = df['Overall_Satisfaction'].map( {'Dissatisfied': 0, 'Satisfied': 1} ).astype(int)

        
#OPTION-2 
df = pd.read_csv('toBeShared/data/surveys.csv')
df.rename(columns={'Order Quantity':'Order_Quantity', 
    'Improvement Area' :'Improvement_Area',
    'Customer type' : 'Customer_Type',
    'Overall Satisfaction': 'Overall_Satisfaction'}, inplace=True)

    
#'drop_first = True' could help to avoid multicolinearity problems.
#first one is deleted 
one_hot_data = pd.get_dummies(df[['Region','Customer_Type','Improvement_Area', 'Overall_Satisfaction']],drop_first=True)
final_df = pd.concat([df, one_hot_data],axis=1)

#Option-3
#Using pipeline 
from sklearn_pandas import * 
df = pd.read_csv('toBeShared/data/surveys.csv')
#Overall_Satisfaction ~ Order_Quantity,Total_Purchased,Months_Customer,Customer_Type,Improvement_Area,Region
df.rename(columns={'Order Quantity':'Order_Quantity', 
    'Improvement Area' :'Improvement_Area',
    'Customer type' : 'Customer_Type',
    'Overall Satisfaction': 'Overall_Satisfaction',
    'Total Purchased': 'Total_Purchased',
    'Months Customer':'Months_Customer'}, inplace=True)
    
y = LabelEncoder().fit_transform(df['Overall_Satisfaction'])
#Dissatisfied- 0, Satisfied-1
X = df[['Order_Quantity','Total_Purchased','Months_Customer','Customer_Type','Improvement_Area','Region']]
           
cat_features = gen_features(
        columns=['Region','Customer_Type','Improvement_Area'],
        classes=[LabelEncoder]  
    )    
no_trans = gen_features(
        columns=['Order_Quantity','Total_Purchased','Months_Customer'],
        classes=[None]  
    )   
    
cat_pipe = Pipeline([('cat_enc', DataFrameMapper(cat_features)),('cat_hot', OneHotEncoder())])
union  = FeatureUnion([('cat', cat_pipe),('other', DataFrameMapper(no_trans))])
pipe = Pipeline([('union', union), ('clf', DecisionTreeClassifier())])            
model = pipe.fit(X,y)

model.named_steps['clf'].n_features_ #12 = 3 + 4(region) + 2(customertype) + 3(improvement_area)
model.named_steps['union'].transformer_list[0][1].named_steps['cat_hot'].feature_indices_
#array([0, 4, 6, 9], dtype=int32)

###Understanding Feature Importances 
#Using LabelBinarizer
df = pd.read_csv('toBeShared/data/surveys.csv')
#Overall_Satisfaction ~ Order_Quantity,Total_Purchased,Months_Customer,Customer_Type,Improvement_Area,Region
df.rename(columns={'Order Quantity':'Order_Quantity', 
    'Improvement Area' :'Improvement_Area',
    'Customer type' : 'Customer_Type',
    'Overall Satisfaction': 'Overall_Satisfaction',
    'Total Purchased': 'Total_Purchased',
    'Months Customer':'Months_Customer'}, inplace=True)
    
y = LabelEncoder().fit_transform(df['Overall_Satisfaction'])
#Dissatisfied- 0, Satisfied-1
X = df[['Order_Quantity','Total_Purchased','Months_Customer','Customer_Type','Improvement_Area','Region']]
 
from sklearn_pandas import *  
cat_features = gen_features(
        columns=['Region','Customer_Type','Improvement_Area'],
        classes=[LabelBinarizer]  
    )    
no_trans = gen_features(
        columns=['Order_Quantity','Total_Purchased','Months_Customer'],
        classes=[None]  
    )   

pipe = Pipeline([('enc', DataFrameMapper(cat_features+no_trans)), ('clf', DecisionTreeClassifier())])            
model = pipe.fit(X,y)
model.score(X,y)
>>> pipe.named_steps['clf'].feature_importances_
array([0., 0., 0., 0., 1., 0., 0., 0., 0., 0., 0.])
pipe.named_steps['enc'].transformed_names_
['Region_EAST', 'Region_NORTH', 'Region_SOUTH', 'Region_WEST', 'Customer_Type','Improvement_Area_Packing & Shipping', 'Improvement_Area_Product Quality', 'Improvement_Area_Website UI', 'Order_Quantity', 'Total_Purchased', 'Months_Customer']
 
#ie 
d = dict(zip(pipe.named_steps['enc'].transformed_names_,  pipe.named_steps['clf'].feature_importances_))
dict([(k,v)  for k,v in d.items() if v !=0])
{'Customer_Type': 1.0}
#plot
import graphviz 
dot_data = export_graphviz(pipe.named_steps['clf'], out_file=None, 
                         feature_names=pipe.named_steps['enc'].transformed_names_, 
                         class_names=['Dissatisfied','Satisfied'],   #use lenc.classes_
                         filled=True, rounded=True,  
                         special_characters=True)  
graph = graphviz.Source(dot_data)  
graph.render('customer_survey') #'iris.pdf'      
#Decision- If customer type is Prime, then he is satishfied !!!

#Validation
>>> confusion_matrix(y,   pipe.predict(X))
array([[15,  0],
       [ 0, 15]], dtype=int64)
            
         

##Overfiiting and pruning the Tree 


boston = load_boston()
X_train, X_test, y_train, y_test = train_test_split(boston.data, boston.target, random_state=0)

model = DecisionTreeRegressor()
model.fit(X_train, y_train)
>>> model.score(X_train, y_train)
1.0
>>> model.score(X_test, y_test)
0.6735183624496861
>>> model.tree_.max_depth
18
>>> model.tree_.node_count
715
#prune - sk learn by default generate very dense tree 
#prunning meanins removing unnecessary branch which does not add any decision making
#post prunning is yet to be implemented 
#For classification with few classes, min_samples_leaf=1 is often the best choice.
#Try min_samples_leaf=5 as an initial value for regression 
#Use max_depth=3 as an initial tree depth , Overfitting happens if value is too high 
#Use splitter='random' 
            
model2 = DecisionTreeRegressor(splitter = 'random',  min_samples_leaf = 5, max_depth= 10)
model2.fit(X_train, y_train)
>>> model2.score(X_train, y_train)
0.7535758657497109
>>> model2.score(X_test, y_test)
0.6468720785088085

>>> model2.tree_.max_depth
10
>>> model2.tree_.node_count
97 

#But now underfit

#Search in hyperspace to get good number 
#this would take us to Model Selection and cross validation 
#note sklearn_pandas 's cross_validation should not be in path 

param_grid = dict(min_samples_leaf=list(range(2,40,5)), max_depth=range(3,15,2))
model3 = DecisionTreeRegressor(splitter = 'random')

#Based on MSE 
grid_search = GridSearchCV(model3, param_grid, cv=KFold(n_splits=5,shuffle=True))
grid_search.fit(X_train, y_train)

>>> grid_search.score(X_train, y_train)
0.8353931293500889
>>> grid_search.score(X_test, y_test)
0.7121702356050497

best_pipeline = grid_search.best_estimator_
grid_search.best_params_
#{'min_samples_leaf': 7, 'max_depth': 7}


##additionally - experiment in next chapter 
param_grid = dict(min_samples_leaf=list(range(1,40,1)), max_depth=range(3,15,1))
model3 = DecisionTreeRegressor(splitter = 'random')
grid_search = GridSearchCV(model3, param_grid, cv=KFold(n_splits=5,shuffle=True))
grid_search.fit(X_train, y_train)
>>> grid_search.score(X_train, y_train)
0.9637676797436858
>>> grid_search.score(X_test, y_test)
0.6147015552105142
>>> grid_search.best_params_
{'min_samples_leaf': 2, 'max_depth': 10}


param_grid = dict(min_samples_leaf=list(range(1,40,2)), max_depth=range(3,15,2))
model3 = DecisionTreeRegressor(splitter = 'random')
grid_search = GridSearchCV(model3, param_grid, cv=KFold(n_splits=5,shuffle=True))
grid_search.fit(X_train, y_train)
>>> grid_search.score(X_train, y_train)
0.8858133217545981
>>> grid_search.score(X_test, y_test)
0.7016641273517075
>>> grid_search.best_params_
{'min_samples_leaf': 3, 'max_depth': 7}





            
###Model Selection and Cross validation 
fiber_df = pd.read_csv("toBeshared/Data/Fiberbits.csv", header=0)

#Defining Features and lables
features = list(set(fiber_df.columns.tolist())- {'active_cust'}) 

X = fiber_df[features]
y = fiber_df['active_cust']
#split 80:20 
X_train, X_test, y_train, y_test = train_test_split(X,y, train_size = 0.8)

clf1 = DecisionTreeClassifier()
clf1.fit(X_train,y_train)
#Model with low Bias= 100%-train_error , high variance = train_error-test_error
clf1.score(X_train,y_train)
#0.996975
clf1.score(X_test,y_test)
#0.847

#Or use cross_validation score 
#default is StratifiedKFold(classifier)/KFold(regressor), with folds cv 
clf1 = DecisionTreeClassifier()  #fit is not required, 
scores = cross_val_score(clf1, X, y, cv=5) 
#Note the value is less because 
#manual train_test_split was doing the same thing as KFold(shuffle = True)
#but here by default shuffle = False
print(scores) #[0.6760662  0.52755    0.52525    0.746      0.55477774]
print("Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))
#Accuracy: 0.61 (+/- 0.18)  #bad

#With shuffle=True 
clf1 = DecisionTreeClassifier()  #fit is not required, 
scores = cross_val_score(clf1, X, y, cv=KFold(n_splits=5,shuffle=True)) 
print(scores) #[0.8475  0.84265 0.84445 0.8433  0.8494 ]
print("Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))
#Accuracy: 0.85 (+/- 0.01)

#Or with scoring 
clf1 = DecisionTreeClassifier()
cross_val_score(clf1,  X, y, cv=KFold(n_splits=5,shuffle=True), scoring='f1_weighted')
#array([0.84092567, 0.84281367, 0.84136786, 0.84813336, 0.84328858])

#Or with another CV class 
clf1 = DecisionTreeClassifier()
rkf = RepeatedKFold(n_splits=2, n_repeats=2) #no shuffle arg 
cross_val_score(clf1,  X, y, cv=rkf) #4 results 
#array([0.84116, 0.84188, 0.84122, 0.84064])


#Or with Pipeline 
clf = Pipeline([('t',StandardScaler()), ('clf',DecisionTreeClassifier())])
cross_val_score(clf, X, y, cv=KFold(n_splits=5,shuffle=True))
array([0.8458 , 0.8439 , 0.84555, 0.8431 , 0.8458 ])


##Boostraping or Shufflesplit 
cv = ShuffleSplit(n_splits=5, test_size=0.3)
clf1 = DecisionTreeClassifier()
>>> cross_val_score(clf1, X, y, cv=cv)  
array([0.8465    , 0.8426    , 0.8393    , 0.84496667, 0.84556667])




##Bias and Variance trade-off 

#prune 
#For classification with few classes, min_samples_leaf=1 is often the best choice.
#Try min_samples_leaf=5 as an initial value for regression 
#Use max_depth=3 as an initial tree depth , Overfitting happens if value is too high 
#Use splitter='random' 

#Model with low Bias= 100%-train_error , high variance = train_error-test_error
#Complex model(high max_depth) is low Bias , high variance 
#Simple model (low max_depth) is high bias and low variance 

#complex model - low Bias= 100%-train_error , high variance = train_error-test_error
low_bias = DecisionTreeClassifier(criterion='gini', 
                                              splitter='random', 
                                              max_depth=50, 
                                              min_samples_leaf=1)
#returns validation set accuracy 
scores = cross_val_score(low_bias, X, y, cv=KFold(n_splits=5,shuffle=True))
print("Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))
#Accuracy: 0.86 (+/- 0.01)  #high variance 
low_bias.fit(X_train,y_train).score(X_train,y_train)
#0.9972875   - low bias 


##Simple model - high bias and low variance 
#prune the tree by changing the parameters 
#Flat the tree , decrease max_depth
high_bias = DecisionTreeClassifier(criterion='gini', 
                                              splitter='random', 
                                              max_depth=7, 
                                              min_samples_leaf=30)

scores = cross_val_score(high_bias, X, y, cv=KFold(n_splits=5,shuffle=True))
print("Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))
#Accuracy: 0.79 (+/- 0.04)#low variance = train_error-test_error
high_bias.fit(X_train,y_train).score(X_train,y_train)
#0.841625   - high bias 



#Lets prune/oversimply the tree 
high_bias1 = DecisionTreeClassifier(criterion='gini', 
                                              splitter='random', 
                                              max_depth=1, 
                                              min_samples_leaf=100)
                                              
scores = cross_val_score(high_bias1, X, y, cv=KFold(n_splits=5,shuffle=True))
print("Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))
#Accuracy: 0.68 (+/- 0.01)#very low variance = train_error-test_error
high_bias1.fit(X_train,y_train).score(X_train,y_train)
#0.681625  - high variance 


##Hypertuning , cv = StratifiedKFold(n_splits, shuffle=True) for classifier 
#KFold(n_splits, shuffle=True) for regressor 

fiber_df = pd.read_csv("toBeshared/Data/Fiberbits.csv", header=0)

#Defining Features and lables
features = list(set(fiber_df.columns.tolist())- {'active_cust'}) 

X = fiber_df[features]
y = fiber_df['active_cust']
#split 80:20 
X_train, X_test, y_train, y_test = train_test_split(X,y, train_size = 0.8)

clf = DecisionTreeClassifier(criterion='gini', splitter='random')

params = dict(min_samples_leaf=list(range(1,40,2)), max_depth=range(3,15,2))
gr = GridSearchCV(clf, params, cv=StratifiedKFold(5, shuffle=True))
#takes long time 
gr.fit(X_train, y_train)
#best_params_ : Parameter setting that gave the best results on the hold out data.
gr.best_params_  #{'min_samples_leaf': 7, 'max_depth': 13}
gr.score(X_train, y_train) #0.875675
gr.score(X_test, y_test) #0.87175
#best_estimator_ : Estimator that was chosen by the search
model = gr.best_estimator_
#best_score_ : Mean cross-validated score of the best_estimator
sc = gr.best_score_

grr = RandomizedSearchCV(clf, params, cv=StratifiedKFold(5, shuffle=True))
#faster
grr.fit(X_train, y_train)
grr.best_params_ #{'min_samples_leaf': 9, 'max_depth': 13}
grr.score(X_train, y_train)#0.8801375
grr.score(X_test, y_test) #0.877

#cv_results_ : A dict with keys as column headers and values as columns, convert to DF 
pd.DataFrame(gr.cv_results_)

#best_index_ : The index (of the cv_results_ arrays) which corresponds to the best candidate parameter setting.
#The dict at search.cv_results_['params'][search.best_index_] gives the parameter setting for the best model, that gives the highest mean score (search.best_score_).
gr.cv_results_['params'][gr.best_index_]
#{'min_samples_leaf': 7, 'max_depth': 13}


##With multiple metrics , scoring = [...], refit= final model metric
#https://scikit-learn.org/stable/modules/model_evaluation.html#common-cases-predefined-values
params = dict(min_samples_leaf=list(range(1,40,1)), max_depth=range(1,15,1))
grrm = RandomizedSearchCV(clf, params, scoring=['roc_auc', 'f1_weighted'],
        refit='f1_weighted', cv=StratifiedKFold(5, shuffle=True))

grrm.fit(X_train, y_train)
grrm.best_params_  #{'min_samples_leaf': 17, 'max_depth': 12}
#f1_weighted
grrm.score(X_train, y_train) #0.8702914451386414
grrm.score(X_test, y_test) #0.8693873558619117


##With return_train_score=True 
#If False, the cv_results_ attribute will not include training scores.
grrt = RandomizedSearchCV(clf, params, cv=StratifiedKFold(5, shuffle=True), return_train_score=True)
grrt.fit(X_train, y_train)
grrt.best_params_  #{'min_samples_leaf': 7, 'max_depth': 13}
#f1_weighted
grrt.score(X_train, y_train) #0.875675
grrt.score(X_test, y_test) #0.87175



##Validation curve 
#plot the influence of a single hyperparameter on the training score 
#and the validation score to find out whether the estimator is overfitting or underfitting 
#for some hyperparameter values
train_scores, test_scores  = validation_curve(estimator, X, y, param_name, param_range,cv=,scoring=..)
#train_scores : array, shape (n_ticks, n_cv_folds)    Scores on training sets.
#test_scores : array, shape (n_ticks, n_cv_folds)    Scores on test set.


#Example 
digits = load_digits()
X, y = digits.data, digits.target
#gamma needs to be in log space 
param_range = np.logspace(-6, -1, 5)
train_scores, test_scores = validation_curve(
    SVC(), X, y, param_name="gamma", param_range=param_range,
    cv=10, scoring="accuracy", n_jobs=1)
train_scores_mean = np.mean(train_scores, axis=1) #n_ticks(row) wise 
train_scores_std = np.std(train_scores, axis=1)
test_scores_mean = np.mean(test_scores, axis=1)
test_scores_std = np.std(test_scores, axis=1)

plt.title("Validation Curve with SVM")
plt.xlabel("$\gamma$")
plt.ylabel("Score")
plt.ylim(0.0, 1.1)
lw = 2
plt.semilogx(param_range, train_scores_mean, label="Training score",color="darkorange", lw=lw)
plt.fill_between(param_range, train_scores_mean - train_scores_std,train_scores_mean + train_scores_std, alpha=0.2,color="darkorange", lw=lw)
plt.semilogx(param_range, test_scores_mean, label="Cross-validation score",color="navy", lw=lw)
plt.fill_between(param_range, test_scores_mean - test_scores_std,test_scores_mean + test_scores_std, alpha=0.2,color="navy", lw=lw)
plt.legend(loc="best")
plt.show()

#For fiber , plot max_depth 
fiber_df = pd.read_csv("toBeshared/Data/Fiberbits.csv", header=0)

#Defining Features and lables
features = list(set(fiber_df.columns.tolist())- {'active_cust'}) 

X = fiber_df[features]
y = fiber_df['active_cust']

clf = DecisionTreeClassifier(criterion='gini', splitter='random')
param_range = list(range(1,30,1))  
train_scores, test_scores = validation_curve(
    clf, X, y, param_name="max_depth", param_range=param_range,
    cv=StratifiedKFold(5, shuffle=True), scoring="accuracy", n_jobs=-1)
train_scores_mean = np.mean(train_scores, axis=1) #n_ticks(row) wise 
train_scores_std = np.std(train_scores, axis=1)
test_scores_mean = np.mean(test_scores, axis=1)
test_scores_std = np.std(test_scores, axis=1)

plt.title("Validation Curve with DecisionTreeClassifier")
plt.xlabel("max_depth")
plt.ylabel("Score")
plt.ylim(0.0, 1.1)
lw = 2
plt.plot(param_range, train_scores_mean, linestyle="-", label="Training score",color="darkorange", lw=lw)
plt.fill_between(param_range, train_scores_mean - train_scores_std,train_scores_mean + train_scores_std, alpha=0.2,color="darkorange", lw=lw)
plt.plot(param_range, test_scores_mean, linestyle="-", label="Cross-validation score",color="navy", lw=lw)
plt.fill_between(param_range, test_scores_mean - test_scores_std,test_scores_mean + test_scores_std, alpha=0.2,color="navy", lw=lw)
plt.legend(loc="best")
plt.show()
#Found max_depth=14


##learning curve 
#A learning curve shows the validation and training score of an estimator for varying numbers of training samples. 
#It is a tool to find out how much we benefit from adding more training data 
#and whether the estimator suffers more from a variance error or a bias error. 

#If both the validation score and the training score converge to a value that is too low 
#with increasing size of the training set, we will not benefit much from more training data. 
#We will probably have to use an estimator or a parametrization of the current estimator 
#that can learn more complex concepts (i.e. has a lower bias).

#If the training score is much greater than the validation score for the maximum number of training samples, 
#adding more training samples will most likely increase generalization.
train_sizes, train_scores, valid_scores = learning_curve(estimator,
    X, y, train_sizes=[50, 80, 110], scoring=.., cv=...)
#training sizes could be list of fractions 
#rain_sizes_abs : array, shape (n_unique_ticks,), dtype int
#Numbers of training examples that has been used to generate the learning curve. Note that the number of ticks might be less than n_ticks because duplicate entries will be removed.
#train_scores : array, shape (n_ticks, n_cv_folds)  Scores on training sets.
#test_scores : array, shape (n_ticks, n_cv_folds)  Scores on test set.

def plot_learning_curve(estimator, title, X, y, ylim=None, cv=None,
                        n_jobs=None, train_sizes=np.linspace(.1, 1.0, 5)):
    plt.figure()
    plt.title(title)
    if ylim is not None:
        plt.ylim(*ylim)
    plt.xlabel("Training examples")
    plt.ylabel("Score")
    train_sizes, train_scores, test_scores = learning_curve(
        estimator, X, y, cv=cv, n_jobs=n_jobs, train_sizes=train_sizes)
    train_scores_mean = np.mean(train_scores, axis=1)
    train_scores_std = np.std(train_scores, axis=1)
    test_scores_mean = np.mean(test_scores, axis=1)
    test_scores_std = np.std(test_scores, axis=1)
    plt.grid()
    plt.fill_between(train_sizes, train_scores_mean - train_scores_std,
                     train_scores_mean + train_scores_std, alpha=0.1,
                     color="r")
    plt.fill_between(train_sizes, test_scores_mean - test_scores_std,
                     test_scores_mean + test_scores_std, alpha=0.1, color="g")
    plt.plot(train_sizes, train_scores_mean, 'o-', color="r",
             label="Training score")
    plt.plot(train_sizes, test_scores_mean, 'o-', color="g",
             label="Cross-validation score")
    plt.legend(loc="best")
    return plt


digits = load_digits()
X, y = digits.data, digits.target


title = "Learning Curves (Naive Bayes)"
# Cross validation with 100 iterations to get smoother mean test and train
# score curves, each time with 20% data randomly selected as a validation set.
cv = ShuffleSplit(n_splits=100, test_size=0.2, random_state=0)

estimator = GaussianNB()
plot_learning_curve(estimator, title, X, y, ylim=(0.7, 1.01), cv=cv, n_jobs=4)

title = "Learning Curves (SVM, RBF kernel, $\gamma=0.001$)"
# SVC is more expensive so we do a lower number of CV iterations:
cv = ShuffleSplit(n_splits=10, test_size=0.2, random_state=0)
estimator = SVC(gamma=0.001)
plot_learning_curve(estimator, title, X, y, (0.7, 1.01), cv=cv, n_jobs=4)

plt.show()

#for fiber data 
#For fiber , plot max_depth 
fiber_df = pd.read_csv("toBeshared/Data/Fiberbits.csv", header=0)

#Defining Features and lables
features = list(set(fiber_df.columns.tolist())- {'active_cust'}) 

X = fiber_df[features]
y = fiber_df['active_cust']

title = "Learning Curves DecisionTreeClassifier"

cv = ShuffleSplit(n_splits=100, test_size=0.2, random_state=0)
clf = DecisionTreeClassifier(criterion='gini', splitter='random')

plot_learning_curve(clf, title, X, y, ylim=(0.1, 1.01), cv=cv, n_jobs=4)
plt.show()

#if training score is low at max sample size, use other estimator 
#if training score is high and  > validation_score at sample size, add more data 
#here add more data 