import warnings
from sklearn.exceptions import * 
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=DataConversionWarning)
warnings.simplefilter(action='ignore', category=ConvergenceWarning)

import pandas as pd
import numpy as np
from sklearn.preprocessing import *
from  sklearn.decomposition import * 
import matplotlib.pyplot as plt 
from sklearn.model_selection import * 
from sklearn.metrics import *
from sklearn.pipeline import *
from sklearn import datasets
from sklearn_pandas import DataFrameMapper
from sklearn.model_selection import * 
from sklearn.ensemble import *  
from sklearn.tree import *

print("""
Model Selection and Cross validation with DT
(example Fiberbits.csv)
(dump of OFC users)
active_cust(target)- 0 and 1 
income
months_on_network
Num_complaints
number_plan_changes
relocated
monthly_bill
technical_issues_per_month,
Speed_test_result
""")


fiber_df = pd.read_csv("data/Fiberbits.csv", header=0)

#Defining Features and lables
features = list(set(fiber_df.columns.tolist())- {'active_cust'}) 

X = fiber_df[features]
y = fiber_df['active_cust']
#split 80:20 
X_train, X_test, y_train, y_test = train_test_split(X,y, train_size = 0.8)

print("-----------Bias and Variance-------------")
clf1 = DecisionTreeClassifier()
clf1.fit(X_train,y_train)
print("Train error(bias)",
clf1.score(X_train,y_train))
#0.996975
print("Test error(bias)", clf1.score(X_test,y_test))
#0.847

print("Or use cross_validation score using KFold")
#With shuffle=True 
clf1 = DecisionTreeClassifier()  #fit is not required, 
scores = cross_val_score(clf1, X, y, cv=KFold(n_splits=5,shuffle=True)) 
print(scores) #[0.8475  0.84265 0.84445 0.8433  0.8494 ]
print("Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))
#Accuracy: 0.85 (+/- 0.01)


print("Or with scoring as f1_weighted")
clf1 = DecisionTreeClassifier()
scores = cross_val_score(clf1,  X, y, cv=KFold(n_splits=5,shuffle=True), scoring='f1_weighted')
#array([0.84092567, 0.84281367, 0.84136786, 0.84813336, 0.84328858])
print(scores) #[0.8475  0.84265 0.84445 0.8433  0.8494 ]
print("f1_weighted: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))

print("Or with another CV class eg RepeatedKFold ")
clf1 = DecisionTreeClassifier()
rkf = RepeatedKFold(n_splits=2, n_repeats=2) #no shuffle arg 
scores = cross_val_score(clf1,  X, y, cv=rkf) #4 results 
#array([0.84116, 0.84188, 0.84122, 0.84064])
print(scores) #[0.8475  0.84265 0.84445 0.8433  0.8494 ]
print("Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))


print("Or with Pipeline with preprocessing StandardScaler ")
clf = Pipeline([('t',StandardScaler()), ('clf',DecisionTreeClassifier())])
scores = cross_val_score(clf, X, y, cv=KFold(n_splits=5,shuffle=True))
#array([0.8458 , 0.8439 , 0.84555, 0.8431 , 0.8458 ])
print(scores) #[0.8475  0.84265 0.84445 0.8433  0.8494 ]
print("Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))



print("-----------Bias and Variance trade-off-------------")

#prune 
#For classification with few classes, min_samples_leaf=1 is often the best choice.
#Try min_samples_leaf=5 as an initial value for regression 
#Use max_depth=3 as an initial tree depth , Overfitting happens if value is too high 
#Use splitter='random' 

#Model with low Bias= 100%-train_error , high variance = train_error-test_error
#Complex model(high max_depth) is low Bias , high variance 
#Simple model (low max_depth) is high bias and low variance 

#complex model - low Bias= 100%-train_error , high variance = train_error-test_error
low_bias = DecisionTreeClassifier(criterion='gini', 
                                  splitter='random', 
                                  max_depth=50, 
                                  min_samples_leaf=1)
print("""
complex model - low Bias= 100%-train_error , high variance
Overfitting
    max_depth=50, 
    min_samples_leaf=1
""")                                           
low_bias.fit(X_train,y_train)                                          
print("Train error(bias)",
low_bias.score(X_train,y_train))
#0.996975
print("Test error(bias)", low_bias.score(X_test,y_test))
#0.847


print(
"""
Simple model - high bias 
prune the tree by changing the parameters 
Flat the tree , decrease max_depth
    max_depth=7, 
    min_samples_leaf=30
""")

high_bias = DecisionTreeClassifier(criterion='gini', 
                                              splitter='random', 
                                              max_depth=7, 
                                              min_samples_leaf=30)

high_bias.fit(X_train,y_train)                                          
print("Train error(bias)",
high_bias.score(X_train,y_train))
#0.837925
print("Test error(bias)", high_bias.score(X_test,y_test))
#0.84225



print("""
Lets prune/oversimply the tree 
Underfitting
    max_depth=1, 
    min_samples_leaf=100
""")
high_bias1 = DecisionTreeClassifier(criterion='gini', 
                                              splitter='random', 
                                              max_depth=1, 
                                              min_samples_leaf=100)
                                              
high_bias1.fit(X_train,y_train)                                          
print("Train error(bias)",
high_bias1.score(X_train,y_train))
print("Test error(bias)", high_bias1.score(X_test,y_test))
#Train error(bias) 0.682825
#Test error(bias) 0.68365

print("""\n\nHyper tunning
Find the bias-variance tradeoff """)
##Hypertuning , cv = StratifiedKFold(n_splits, shuffle=True) for classifier 
#KFold(n_splits, shuffle=True) for regressor 


clf = DecisionTreeClassifier(criterion='gini', splitter='random')

params = dict(min_samples_leaf=list(range(1,40,2)), max_depth=range(3,15,2))
gr = RandomizedSearchCV(clf, params, cv=StratifiedKFold(5, shuffle=True))
#takes long time 
gr.fit(X_train, y_train)
#best_params_ : Parameter setting that gave the best results on the hold out data.
print("best params", gr.best_params_ ) #{'min_samples_leaf': 7, 'max_depth': 13}
print("Train error(bias)",
gr.score(X_train,y_train))
print("Test error(bias)", gr.score(X_test,y_test))
#Train error(bias) 0.8697
#Test error(bias) 0.8684

print("""best_estimator_ : Estimator that was chosen by the search""")
model = gr.best_estimator_
print(model)
print("""best_score_ : Mean cross-validated score of the best_estimator""")
sc = gr.best_score_
print(sc)


print("cv_results_ : A dict with keys as column headers and values as columns")
print(pd.DataFrame(gr.cv_results_))

print("best_index_ : The index (of the cv_results_ arrays) which corresponds to the best candidate parameter setting.")
#The dict at search.cv_results_['params'][search.best_index_] gives the parameter setting for the best model, that gives the highest mean score (search.best_score_).
print(gr.cv_results_['params'][gr.best_index_])
#{'min_samples_leaf': 7, 'max_depth': 13}
