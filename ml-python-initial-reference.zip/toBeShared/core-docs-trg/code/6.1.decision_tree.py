import warnings
from sklearn.exceptions import * 
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=DataConversionWarning)
warnings.simplefilter(action='ignore', category=ConvergenceWarning)

import pandas as pd
import numpy as np
from sklearn.preprocessing import *
from  sklearn.decomposition import * 
import matplotlib.pyplot as plt 
from sklearn.model_selection import * 
from sklearn.metrics import *
from sklearn.pipeline import Pipeline
from sklearn import datasets

from sklearn.ensemble import *  
from sklearn.tree import *

print("------------------------ iris data DecisionTreeClassifier ---------")
iris = datasets.load_iris()
X_train, X_test, y_train, y_test = train_test_split(iris.data, iris.target, random_state=0)

print("With entropy")
clf = DecisionTreeClassifier(criterion='entropy')
print("check default value of all params") 
print(clf.get_params()  )

clf = clf.fit(X_train, y_train)
predicted = clf.predict(X_test)


print("Training Accuracy",accuracy_score(y_train, clf.predict(X_train)))
print("Test data Accuracy",accuracy_score(y_test, predicted))

print("Predicted class for test data ...") 
print(predicted)

print("the probability of each class can be predicted(test data)")
print(clf.predict_proba(X_test))

print("We can get feature importance from DT algorithm")
[print(i,":", j) for i,j in zip(iris.feature_names,clf.feature_importances_) ]


vals = cross_val_score(clf, iris.data, iris.target, cv=10)
print("cross validated score %3.2f +/- %3.2f" % (vals.mean(),vals.std()) )


import graphviz 
dot_data = export_graphviz(clf, out_file=None, 
                         feature_names=iris.feature_names,  
                         class_names=iris.target_names,  
                         filled=True, rounded=True,  
                         special_characters=True)  
graph = graphviz.Source(dot_data)  
print("Generated iris.pdf for visualization for entropy")
print(""" 
Each node 
    Condition on One feature 
    entropy/gini = value at this node 
    samples = How many samples(or subsamples) is used for this condition
    value = ndarray([[class_1_count, class_2_count, ....]])
    whereas class_X_count = no of samples for that class 
    with that condition ie samples = SUM of value
    class = class from Majority 

Left Node = True of node condition 
    Another feature condition and it's data 
Right node = False of node condition 
    Another feature condition and it's data

Objective is to go down the tree by decreasing entropy/gini 
(entropy/gini is highest if all class_X_count = equal)
such that only one class is seen at leaf node 

How the spliting is done ?
Supported strategies for 'splitter' are 
    'best' to choose the best split 
    and 'random' to choose the best random split
among no of features give by max_features = 
        If int, then consider max_features features at each split.
        If float, int(max_features * n_features) features 
        If 'auto', then max_features=sqrt(n_features).
        If 'sqrt', then max_features=sqrt(n_features).
        If 'log2', then max_features=log2(n_features).
        If None(default), then max_features=n_features.

Sometimes pruning is done to remove reduntant splits 
(for controlling overfitting and for less memory consumption)
eg remove all children of the nodes with class_X_count < 5
such that 'class = class from Majority' is final class 
OR 
remove children  if both children are leaves now  
and make the same decision
OR some other criteria 
Eg builtin DT has below parameters
min_samples_split 
    The minimum number of samples required to split an internal node:
min_samples_leaf 
    The minimum number of samples required to be at a leaf node. 
    A split point at any depth will only be considered if it leaves 
    at least min_samples_leaf training samples in each of the left 
    and right branches. 
min_weight_fraction_leaf 
    The minimum weighted fraction of the sum total of weights 
    (of all the input samples) required to be at a leaf node. 
    Samples have equal weight when sample_weight is not provided.
max_depth 
    The maximum depth of the tree. 
    If None, then nodes are expanded until all leaves are pure 
    or until all leaves contain less than min_samples_split samples.
min_impurity_decrease 
    A node will be split if this split induces a decrease 
    of the impurity greater than or equal to this value.
""")
graph.render('iris_entropy') #'iris.pdf'


print("with gini")
clf = DecisionTreeClassifier(criterion='gini')


clf = clf.fit(X_train, y_train)
print("Training Accuracy",accuracy_score(y_train, clf.predict(X_train)))
print("Test data Accuracy",accuracy_score(y_test, clf.predict(X_test)))


dot_data = export_graphviz(clf, out_file=None, 
                         feature_names=iris.feature_names,  
                         class_names=iris.target_names,  
                         filled=True, rounded=True,  
                         special_characters=True)  
graph = graphviz.Source(dot_data)  
print("Generated iris.pdf for visualization for gini")
graph.render('iris_gini') #'iris.pdf'