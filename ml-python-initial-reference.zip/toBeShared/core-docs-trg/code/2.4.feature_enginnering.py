from sklearn.decomposition import *  
from sklearn.feature_extraction import *  
from sklearn.feature_extraction.text import *  
from sklearn.feature_selection import *  
from sklearn.preprocessing import *  
from sklearn.impute import *

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt


print("""
1.Imputation
2.Handling Outliers
3.Binning
4.Log Transform
5.One-Hot Encoding
6.Grouping Operations
7.Feature Split
8.Scaling
9.Extracting Date
""")

print('''
1.Imputation - handling missing values 

Simple solution is to drop the rows or the entire column based on some threshold 
''')

data = pd.DataFrame([[1, 2], [np.nan, 3], [7, 6]], columns=['A','B'])
threshold = 0.7

print('''
>>> data 
     A  B
0  1.0  2
1  NaN  3
2  7.0  6
>>> data.isnull()
       A      B
0  False  False
1   True  False
2  False  False
>>> data.isnull().mean()
A    0.333333
B    0.000000
dtype: float64
>>> data.isnull().mean() < threshold
A    True
B    True
dtype: bool

>>> data.isnull().mean(axis=1)
0    0.0
1    0.5
2    0.0
dtype: float64

#Dropping columns with missing value rate higher than threshold
#note by default  mean is columnwise, hence 
#data.isnull().mean() < threshold dimension is no of columns 
data = data[data.columns[data.isnull().mean() < threshold]]

#Dropping rows with missing value rate higher than threshold
data = data.loc[data.isnull().mean(axis=1) < threshold]
''')

#Dropping columns with missing value rate higher than threshold
data = data[data.columns[data.isnull().mean() < threshold]]

#Dropping rows with missing value rate higher than threshold
data = data.loc[data.isnull().mean(axis=1) < threshold]

print('''
Numerical Imputation

#Filling all missing values with 0
data = data.fillna(0)

#Filling missing values with medians of the columns
data = data.fillna(data.median())


Categorical Imputation
Replacing the missing values with the maximum occurred value 
But if there is not a dominant value, imputing a category like 'Other'

#Max fill function for categorical columns
data['column_name'].fillna(data['column_name'].value_counts().idxmax(), inplace=True)

#'Other' fill function for categorical columns
data['column_name'].fillna('Other', inplace=True)
''')
#Filling all missing values with 0
data = data.fillna(0)

#Filling missing values with medians of the columns
data = data.fillna(data.median())

print('''
Using sklearn SimpleImputer
strategy= mean/median/most_frequent/constant 

import numpy as np
from sklearn.impute import SimpleImputer
imp = SimpleImputer(missing_values=np.nan, strategy='mean')
imp.fit(data)  

print(imp.transform(data)) 
#[[1. 2.]
# [4. 3.]
# [7. 6.]]

The SimpleImputer class also supports categorical data 
represented as string values or pandas categoricals 
when using the 'most_frequent' or 'constant' strategy:

>>> df
     0    1
0    a    x
1  NaN    y
2    a  NaN
3    b    y
>>> df.dtypes
0    category
1    category
dtype: object

imp = SimpleImputer(strategy="most_frequent")
print(imp.fit_transform(df))      
# [['a' 'x']
#  ['a' 'y']
#  ['a' 'y']
#  ['b' 'y']]

''')

data = pd.DataFrame([[1, 2], [np.nan, 3], [7, 6]], columns=['A','B'])
imp = SimpleImputer(missing_values=np.nan, strategy='mean')
imp.fit(data)  

print(imp.transform(data)) 

df = pd.DataFrame([["a", "x"],
                   [np.nan, "y"],
                   ["a", np.nan],
                   ["b", "y"]], dtype="category")

imp = SimpleImputer(strategy="most_frequent")
print(imp.fit_transform(df))      

 
print('''
2.Handling Outliers
Visualize data and drop that data point , eg 
data.drop(data.index[[2,3]])


Outlier Detection with Standard Deviation
If a column value has a distance to the average higher than x * standard deviation, 
drop entire row 
There is no trivial solution for x, but usually, a value between 2 and 4 seems practical.

#Dropping the outlier rows with standard deviation
factor = 3
upper_lim = data['column'].mean () + data['column'].std () * factor
lower_lim = data['column'].mean () - data['column'].std () * factor
data = data[(data['column'] < upper_lim) & (data['column'] > lower_lim)]


Outlier Detection with Percentiles
A common mistake is using the percentiles according to the range of the data. 
In other words, if data ranges from 0 to 100, 
top 5% is not the values between 96 and 100. 
Top 5% means here the values that are out of the 95th percentile of data.

#Dropping the outlier rows with Percentiles
upper_lim = data['column'].quantile(.95)
lower_lim = data['column'].quantile(.05)

data = pd.DataFrame([[1, 2], [np.nan, 3], [7, 6]], columns=['A','B'])
data['column'] = data.A + data.B
>>> data
     A  B  column
0  1.0  2     3.0
1  NaN  3     NaN
2  7.0  6    13.0

>>> (data['column'] < upper_lim)
0     True
1    False
2    False
Name: column, dtype: bool

>>> data[(data['column'] < upper_lim)]
     A  B  column
0  1.0  2     3.0

data = data[(data['column'] < upper_lim) & (data['column'] > lower_lim)]


Another option for handling outliers is to cap them instead of dropping. 
capping can affect the distribution of the data, thus it better not to exaggerate it.

#Capping the outlier rows with Percentiles
upper_lim = data['column'].quantile(.95)
lower_lim = data['column'].quantile(.05)

data.loc[(df[column] > upper_lim),column] = upper_lim
data.loc[(df[column] < lower_lim),column] = lower_lim

''')

print('''
3.Binning
Binning can be applied on both categorical and numerical data:

#Numerical Binning Example
Value      Bin       
0-30   ->  Low       
31-70  ->  Mid       
71-100 ->  High

#Categorical Binning Example
Value      Bin       
Spain  ->  Europe      
Italy  ->  Europe       
Chile  ->  South America
Brazil ->  South America

The main motivation of binning is to make the model more robust and prevent overfitting, 
however, it has a cost to the performance. 
Every time you bin something, you sacrifice information 
and make your data more regularized.

For categorical columns, the labels with low frequencies probably 
affect the robustness of statistical models negatively. 
Thus, assigning a general category to these less frequent values helps 
to keep the robustness of the model. 


#Numerical Binning Example
data['bin'] = pd.cut(data['value'], bins=[0,30,70,100], labels=["Low", "Mid", "High"])
   value   bin
0      2   Low
1     45   Mid
2      7   Low
3     85  High
4     28   Low

#Categorical Binning Example
     Country
0      Spain
1      Chile
2  Australia
3      Italy
4     Brazil

conditions = [
    data['Country'].str.contains('Spain'),
    data['Country'].str.contains('Italy'),
    data['Country'].str.contains('Chile'),
    data['Country'].str.contains('Brazil')]

>>> conditions
[0     True
1    False
2    False
3    False
4    False
Name: Country, dtype: bool, 0    False
1    False
2    False
3     True
4    False
Name: Country, dtype: bool, 0    False
1     True
2    False
3    False
4    False
Name: Country, dtype: bool, 0    False
1    False
2    False
3    False
4     True
Name: Country, dtype: bool]

choices = ['Europe', 'Europe', 'South America', 'South America']
#select: Return an array drawn from elements in choicelist, depending on conditions
data['Continent'] = np.select(conditions, choices, default='Other')
     Country      Continent
0      Spain         Europe
1      Chile  South America
2  Australia          Other
3      Italy         Europe
4     Brazil  South America



Using Sklearn K-bins discretization
KBinsDiscretizer discretizes features into k bins:

#By default the output is one-hot encoded( which is required as outputs becomes categorical)
#or keep it ordinal attributes which can be further used in a sklearn.pipeline.Pipeline.

#The 'uniform' strategy uses constant-width bins. 
#The 'quantile' strategy uses the quantiles values 
#to have equally populated bins in each feature. 
#The 'kmeans' strategy defines bins based on a k-means clustering procedure 
#performed on each feature independently.

X = np.array([[ -3., 5., 15 ],
              [  0., 6., 14 ],
              [  6., 3., 11 ]])
#feature1-3 bins , feature2-2 bins , feature3-2 bins 
est = KBinsDiscretizer(n_bins=[3, 2, 2], encode='ordinal').fit(X)

>>> est.bin_edges_
array([array([-3., -1.,  2.,  6.]), array([3., 5., 6.]),
       array([11., 14., 15.])], dtype=object)

est.transform(X)                      
array([[ 0., 1., 1.],
       [ 1., 1., 1.],
       [ 2., 0., 0.]])


Feature binarization
Feature binarization is the process of thresholding numerical features to get boolean values. 
This can be useful for downstream probabilistic estimators 
that make assumption that the input data is distributed 
according to a multi-variate Bernoulli distribution. 
For instance, this is the case for the sklearn.neural_network.BernoulliRBM.
Note that the Binarizer is similar to the KBinsDiscretizer when k = 2

X = [[ 1., -1.,  2.],
     [ 2.,  0.,  0.],
     [ 0.,  1., -1.]]
binarizer = preprocessing.Binarizer().fit(X)  # fit does nothing
>>> binarizer
Binarizer(copy=True, threshold=0.0)

>>> binarizer.transform(X)
array([[1., 0., 1.],
       [1., 0., 0.],
       [0., 1., 0.]])

#adjust the threshold of the binarizer:
binarizer = preprocessing.Binarizer(threshold=1.1)
>>> binarizer.transform(X)
array([[0., 0., 1.],
       [1., 0., 0.],
       [0., 0., 0.]])

''')

print('''
4.Log Transform
A.It helps to handle skewed data and after transformation, 
  the distribution becomes more approximate to normal.
B.In most of the cases the magnitude order of the data changes 
  within the range of the data. 
  For instance, the difference between ages 15 and 20 is not equal to the ages 65 and 70. 
  In terms of years, yes, they are identical, 
  but for all other aspects, 5 years of difference in young ages 
  mean a higher magnitude difference. 
  This type of data comes from a multiplicative process 
  and log transform normalizes the magnitude differences like that.
C.It also decreases the effect of the outliers,
  due to the normalization of magnitude differences 
  and the model become more robust.

A critical note: The data you apply log transform must have only positive values, 
otherwise you receive an error. 
Also, you can add 1 to your data before transform it.,  Log(x+1)
Thus, you ensure the output of the transformation to be positive.
as log(fraction) is < 0 

   

#Log Transform Example
data = pd.DataFrame({'value':[2,45, -23, 85, 28, 2, 35, -12]})

data['log+1'] = (data['value']+1).transform(np.log)

#Negative Values Handling
#Note that the values are different
data['log'] = (data['value']-data['value'].min()+1) .transform(np.log)

   value  log(x+1)  log(x-min(x)+1)
0      2   1.09861          3.25810
1     45   3.82864          4.23411
2    -23       nan          0.00000
3     85   4.45435          4.69135
4     28   3.36730          3.95124
5      2   1.09861          3.25810
6     35   3.58352          4.07754
7    -12       nan          2.48491


Using sklearn PowerTransformer
PowerTransformer currently provides two such power transformations, 
the Yeo-Johnson transform and the Box-Cox transform.
Box-Cox can only be applied to strictly positive data
PowerTransformer will apply zero-mean, unit-variance normalization 
to the transformed output by default or make standardize option to False


pt = PowerTransformer(method='box-cox', standardize=False)
X_lognormal = np.random.RandomState(616).lognormal(size=(3, 3))
>>> X_lognormal                                         
array([[1.28..., 1.18..., 0.84...],
       [0.94..., 1.60..., 0.38...],
       [1.35..., 0.21..., 1.09...]])
>>> pt.fit_transform(X_lognormal)                   
array([[ 0.49...,  0.17..., -0.15...],
       [-0.05...,  0.58..., -0.57...],
       [ 0.69..., -0.84...,  0.10...]])

''')


print('''
5.One-hot encoding
For categorical data 
Why One-Hot?: 
If you have N distinct values in the column, 
it is enough to map them to N-1 binary columns, 
because the missing value can be deducted from other columns. 
If all the columns in our hand are equal to 0, the missing value must be equal to 1. 
This is the reason why it is called as one-hot encoding. 


Using pandas.get_dummies function of Pandas. 
This function maps all values in a column to multiple columns.

encoded_columns = pd.get_dummies(data['column'])
data = data.join(encoded_columns).drop('column', axis=1)


Using  sklearn OneHotEncoder(now can handle string categorical)
By default, the encoder derives the categories based on the unique values
in each feature. Alternatively, you can also specify the `categories`
manually.

enc = OneHotEncoder()
X = [['male', 'from US', 'uses Safari'], ['female', 'from Europe', 'uses Firefox']]
>>> enc.fit(X)  
OneHotEncoder(categorical_features=None, categories=None, drop=None,
       dtype=<'numpy.float64'>, handle_unknown='error',
       n_values=None, sparse=True)
>>> enc.transform(X).toarray()
array([[1., 0., 0., 1., 0., 1.],
       [0., 1., 1., 0., 0., 1.]])

>>>enc.categories_
[array(['female', 'male'], dtype=object), array(['from Europe', 'from US'], dtype=object), array(['uses Firefox', 'uses Safari'], dtype=object)]

#Or specify using 
genders = ['female', 'male']
locations = ['from Africa', 'from Asia', 'from Europe', 'from US']
browsers = ['uses Chrome', 'uses Firefox', 'uses IE', 'uses Safari']
enc = OneHotEncoder(categories=[genders, locations, browsers])
# Note that for there are missing categorical values for the 2nd and 3rd feature
enc.fit(X) 
>>> enc.transform([['female', 'from Asia', 'uses Chrome']]).toarray()
array([[1., 0., 0., 1., 0., 0., 1., 0., 0., 0.]])

If  the training data might have missing categorical features, 
it can often be better to specify handle_unknown='ignore' 
instead of setting the categories manually as above. 

When handle_unknown='ignore' is specified and unknown categories 
are encountered during transform, no error will be raised 
but the resulting one-hot encoded columns for this feature will be all zeros 
(handle_unknown='ignore' is only supported for one-hot encoding):

enc = OneHotEncoder(handle_unknown='ignore')
X = [['male', 'from US', 'uses Safari'], ['female', 'from Europe', 'uses Firefox']]
enc.fit(X) 
>>> enc.transform([['female', 'from Asia', 'uses Chrome']]).toarray()
array([[1., 0., 0., 0., 0., 0.]])

To encode each column into n_categories - 1 columns instead of n_categories columns 

X = [['male', 'from US', 'uses Safari'], ['female', 'from Europe', 'uses Firefox']]
drop_enc = OneHotEncoder(drop='first').fit(X)
>>> drop_enc.categories_
[array(['female', 'male'], dtype=object), array(['from Europe', 'from US'], dtype=object), array(['uses Firefox', 'uses Safari'], dtype=object)]
>>> drop_enc.transform(X).toarray()
array([[1., 1., 1.],
       [0., 0., 0.]])

''')

print('''
6.Grouping Operations

Generally every instance is represented by a row in the training dataset, 
where every column show a different feature of the instance. 
This kind of data called "Tidy".


Datasets such as transactions rarely fit the definition of tidy data above, 
because of the multiple rows of an instance. 
In such a case, we group the data by the instances 
and then every instance is represented by only one row.

The key point of group by operations is to decide the aggregation functions of the features.
For numerical features, average and sum functions are usually convenient options, 
whereas for categorical features it more complicated.


Categorical Column Grouping
The first option is to select the label with the highest frequency. 
In other words, this is the max operation for categorical columns, 
but ordinary max functions generally do not return this value, 
you need to use a lambda function for this purpose.

data.groupby('id').agg(lambda x: x.value_counts().index[0])

Second option is to make a pivot table. 
This approach resembles the encoding method in the preceding step with a difference. 
Instead of binary notation, it can be defined as aggregated functions 
for the values between grouped and encoded columns.

data.pivot_table(index='column_to_group', columns='column_to_encode', 
    values='aggregation_column', aggfunc=np.sum, fill_value = 0)

Last categorical grouping option is to apply a group by function 
after applying one-hot encoding. 
This method preserves all the data -in the first option you lose some-, 
and in addition, you transform the encoded column from categorical to numerical in the meantime. 


    
Numerical Column Grouping

#sum_cols: List of columns to sum
#mean_cols: List of columns to average

grouped = data.groupby('column_to_group')

sums = grouped[sum_cols].sum().add_suffix('_sum')
avgs = grouped[mean_cols].mean().add_suffix('_avg')

new_df = pd.concat([sums, avgs], axis=1)


''')

print('''
7.Feature Split
Splitting features is a good way to make them useful in terms of machine learning. 
    We enable machine learning algorithms to comprehend them.
    Make possible to bin and group them.
    Improve model performance by uncovering potential information.

But Split function depends on the characteristics of the column, how to split it. 

>>> data.name
0  Luther N. Gonzalez
1    Charles M. Young
2        Terry Lawson
3       Kristen White
4      Thomas Logsdon

#Extracting first names
>>> data.name.str.split(" ").map(lambda x: x[0])
0     Luther
1    Charles
2      Terry
3    Kristen
4     Thomas

#Extracting last names
>>> data.name.str.split(" ").map(lambda x: x[-1])
0    Gonzalez
1       Young
2      Lawson
3       White
4     Logsdon

#String extraction example
>>> data.title.head()
0                      Toy Story (1995)
1                        Jumanji (1995)
2               Grumpier Old Men (1995)
3              Waiting to Exhale (1995)
4    Father of the Bride Part II (1995)

>>> data.title.str.split("(", n=1, expand=True)[1].str.split(")", n=1, expand=True)[0]
0    1995
1    1995
2    1995
3    1995
4    1995

''')


print('''
8.Scaling
In most cases, the numerical features of the dataset do not have a certain range and they differ from each other. 
In real life, it is nonsense to expect age and income columns to have the same range. 
But from the machine learning point of view, how these two columns can be compared?

Scaling solves this problem. 
The continuous features become identical in terms of the range, after a scaling process. 
This process is not mandatory for many algorithms, but it might be still nice to apply. 
However, the algorithms based on distance calculations such as k-NN or k-Means or SVM 
need to have scaled continuous features as model input.

MinMax Normalization
Scales all values in a fixed range between 0 and 1. 
This transformation does not change the distribution of the feature 
and due to the decreased standard deviations, the effects of the outliers increases. 
Therefore, before normalization, it is recommended to handle the outliers.

data = pd.DataFrame({'value':[2,45, -23, 85, 28, 2, 35, -12]})
data['normalized'] = (data['value'] - data['value'].min()) / (data['value'].max() - data['value'].min())
   value  normalized
0      2        0.23
1     45        0.63
2    -23        0.00
3     85        1.00
4     28        0.47
5      2        0.23
6     35        0.54
7    -12        0.10


Standardization
Standardization (or z-score normalization) scales the values while taking 
into account standard deviation. 
If the standard deviation of features is different, 
their range also would differ from each other. 
This reduces the effect of the outliers in the features.

data = pd.DataFrame({'value':[2,45, -23, 85, 28, 2, 35, -12]})
data['standardized'] = (data['value'] - data['value'].mean()) / data['value'].std()
   value  standardized
0      2         -0.52
1     45          0.70
2    -23         -1.23
3     85          1.84
4     28          0.22
5      2         -0.52
6     35          0.42
7    -12         -0.92

Using sklearn StandardScaler

scaler = StandardScaler().fit(X_train)
>>> scaler
StandardScaler(copy=True, with_mean=True, with_std=True)

>>> scaler.mean_                                      
array([1. ..., 0. ..., 0.33...])

>>> scaler.scale_                                       
array([0.81..., 0.81..., 1.24...])

>>> scaler.transform(X_train)                           
array([[ 0.  ..., -1.22...,  1.33...],
       [ 1.22...,  0.  ..., -0.26...],
       [-1.22...,  1.22..., -1.06...]])


Using sklearn  MinMaxScaler
to the [0, 1] range by default 
If MinMaxScaler is given an explicit feature_range=(min, max) the full formula is:
X_std = (X - X.min(axis=0)) / (X.max(axis=0) - X.min(axis=0))
X_scaled = X_std * (max - min) + min


#Example 
X_train = np.array([[ 1., -1.,  2.],
                    [ 2.,  0.,  0.],
                    [ 0.,  1., -1.]])
...
min_max_scaler = MinMaxScaler()
X_train_minmax = min_max_scaler.fit_transform(X_train)
>>> X_train_minmax
array([[0.5       , 0.        , 1.        ],
       [1.        , 0.5       , 0.33333333],
       [0.        , 1.        , 0.        ]])

>>> min_max_scaler.scale_                             
array([0.5       , 0.5       , 0.33...])

>>> min_max_scaler.min_                               
array([0.        , 0.5       , 0.33...])



MaxAbsScaler for range [-1, 1] by dividing through the largest maximum value 
in each feature. It is meant for data that is already centered at zero or sparse data.

X_train = np.array([[ 1., -1.,  2.],
                    [ 2.,  0.,  0.],
                    [ 0.,  1., -1.]])

max_abs_scaler = .MaxAbsScaler()
X_train_maxabs = max_abs_scaler.fit_transform(X_train)
>>> X_train_maxabs               
array([[ 0.5, -1. ,  1. ],
       [ 1. ,  0. ,  0. ],
       [ 0. ,  1. , -0.5]])

>>> max_abs_scaler.scale_         
array([2.,  1.,  2.])



Scaling sparse data
Centering sparse data would destroy the sparseness structure in the data, 
and thus rarely is a sensible thing to do. 
However, it can make sense to scale sparse inputs, 
especially if features are on different scales.

MaxAbsScaler is specifically designed for scaling sparse data, 
and are the recommended way to go about this. 
However, scale and StandardScaler can accept scipy.sparse matrices as input, 
as long as with_mean=False is explicitly passed to the constructor. 



Scaling data with outliers
Scaling using the mean and variance of the data is likely to not work very well. 
In these cases, you can use RobustScaler as drop-in replacements instead. 
They use more robust estimates for the center and range of your data.


from sklearn.preprocessing import RobustScaler
X = [[ 1., -2.,  2.],
      [ -2.,  1.,  3.],
      [ 4.,  1., -2.]]
transformer = RobustScaler().fit(X)
>>> transformer  
RobustScaler(copy=True, quantile_range=(25.0, 75.0), with_centering=True,
       with_scaling=True)
>>> transformer.transform(X)
array([[ 0. , -2. ,  0. ],
       [-1. ,  0. ,  0.4],
       [ 1. ,  0. , -1.6]])
       

       
QuantileTransformer transform provide a non-parametric transformation to map the data 
to a uniform distribution with values between 0 and 1:


from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
iris = load_iris()
X, y = iris.data, iris.target
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)
quantile_transformer = QuantileTransformer(random_state=0)
X_train_trans = quantile_transformer.fit_transform(X_train)
X_test_trans = quantile_transformer.transform(X_test)
>>> np.percentile(X_train[:, 0], [0, 25, 50, 75, 100]) 
array([ 4.3,  5.1,  5.8,  6.5,  7.9])
''')

print('''
9.Extracting Date
Extracting the parts of the date into different columns: Year, month, day, etc.
Extracting the time period between the current date and columns in terms of years, months, days, etc.
Extracting some specific features from the date: Name of the weekday, Weekend or not, holiday or not, etc.


from datetime import date

data = pd.DataFrame({'date':
        ['01-01-2017',
        '04-12-2008',
        '23-06-1988',
        '25-08-1999',
        '20-02-1993',
        ]})

#Transform string to date
data['date'] = pd.to_datetime(data.date, format="%d-%m-%Y")

#Extracting Year
data['year'] = data['date'].dt.year

#Extracting Month
data['month'] = data['date'].dt.month

#Extracting passed years since the date
data['passed_years'] = date.today().year - data['date'].dt.year

#Extracting passed months since the date
data['passed_months'] = (date.today().year - data['date'].dt.year) * 12 + date.today().month - data['date'].dt.month

#Extracting the weekday name of the date
data['day_name'] = data['date'].dt.day_name()
#output 
        date  year  month  passed_years  passed_months   day_name
0 2017-01-01  2017      1             2             26     Sunday
1 2008-12-04  2008     12            11            123   Thursday
2 1988-06-23  1988      6            31            369   Thursday
3 1999-08-25  1999      8            20            235  Wednesday
4 1993-02-20  1993      2            26            313   Saturday


''')


print('''
Using sklearn Feature selection

Removing features with low variance, VarianceThreshold
It removes all features whose variance doesn't meet some threshold. 
By default, it removes all zero-variance features, i.e. features that have the same value in all samples.

For example to remove all features that are either one or zero (on or off) 
in more than 80% of the samples. 
Boolean features are Bernoulli random variables, 
so we can select using the threshold .8 * (1 - .8):


from sklearn.feature_selection import VarianceThreshold
X = [[0, 0, 1], [0, 1, 0], [1, 0, 0], [0, 1, 1], [0, 1, 0], [0, 1, 1]]
sel = VarianceThreshold(threshold=(.8 * (1 - .8)))
#As expected, VarianceThreshold has removed the first column
>>> sel.fit_transform(X)
array([[0, 1],
       [1, 0],
       [0, 0],
       [1, 1],
       [1, 0],
       [1, 1]])

       
Univariate feature selection
Univariate feature selection works by selecting the best features  based on univariate statistical tests. 

SelectKBest removes all but the k highest scoring features
SelectPercentile removes all but a user-specified highest scoring percentage of features
using common univariate statistical tests for each feature: 
    false positive rate SelectFpr, false discovery rate SelectFdr, 
    or family wise error SelectFwe.
GenericUnivariateSelect allows to perform univariate feature selection 
with a configurable strategy.
This allows to select the best univariate selection strategy 
with hyper-parameter search estimator.


from sklearn.datasets import load_iris
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2
iris = load_iris()
X, y = iris.data, iris.target
>>> X.shape
(150, 4)
X_new = SelectKBest(chi2, k=2).fit_transform(X, y)
>>> X_new.shape
(150, 2)

#These objects take as input a scoring function that returns univariate scores 
#and p-values (or only scores for SelectKBest and SelectPercentile):
For regression: f_regression, mutual_info_regression
For classification: chi2, f_classif, mutual_info_classif


Recursive feature elimination, RFECV
Given a external estimator that assigns weights to features 
(e.g., the coefficients of a linear model), 
recursive feature elimination (RFE) is to select features 
by recursively considering smaller and smaller sets of features. 

First, the estimator is trained on the initial set of features 
and the importance of each feature is obtained either through a coef_ attribute 
or through a feature_importances_ attribute. 
Then, the least important features are pruned from current set of features.
That procedure is recursively repeated on the pruned set 
until the desired number of features to select is eventually reached.

RFECV performs RFE in a cross-validation loop to find the optimal number of features.


Feature selection using SelectFromModel
SelectFromModel is a meta-transformer that can be used along 
with any estimator that has a coef_ or feature_importances_ attribute after fitting. 
The features are considered unimportant and removed, 
if the corresponding coef_ or feature_importances_ values are below the provided threshold parameter. 



L1-based feature selection
Linear models penalized with the L1 norm have sparse solutions:
many of their estimated coefficients are zero. 
With SVMs and logistic-regression, the parameter C controls the sparsity:
the smaller C the fewer features selected. 
With Lasso, the higher the alpha parameter, the fewer features selected.

from sklearn.svm import LinearSVC
from sklearn.datasets import load_iris
from sklearn.feature_selection import SelectFromModel
iris = load_iris()
X, y = iris.data, iris.target
>>> X.shape
(150, 4)
lsvc = LinearSVC(C=0.01, penalty="l1", dual=False).fit(X, y)
model = SelectFromModel(lsvc, prefit=True)
X_new = model.transform(X)
>>> X_new.shape
(150, 3)



Tree-based feature selection
Tree-based estimators  can be used to compute feature importances, 
which in turn can be used to discard irrelevant features
(when coupled with the sklearn.feature_selection.SelectFromModel meta-transformer):


from sklearn.ensemble import ExtraTreesClassifier
from sklearn.datasets import load_iris
from sklearn.feature_selection import SelectFromModel
iris = load_iris()
X, y = iris.data, iris.target
>>> X.shape
(150, 4)
clf = ExtraTreesClassifier(n_estimators=50)
clf = clf.fit(X, y)
clf.feature_importances_  
array([ 0.04...,  0.05...,  0.4...,  0.4...])
model = SelectFromModel(clf, prefit=True)
X_new = model.transform(X)
>>> X_new.shape               
(150, 2)


Feature selection as part of a pipeline
clf = Pipeline([
  ('feature_selection', SelectFromModel(LinearSVC(penalty="l1"))),
  ('classification', RandomForestClassifier())
])
clf.fit(X, y)


''')

print('''
Generating polynomial features
Often its useful to add complexity to the model by considering nonlinear features of the input data. 
A simple and common method to use is polynomial features, 
which can get features' high-order and interaction terms. 
import numpy as np
from sklearn.preprocessing import PolynomialFeatures
X = np.arange(6).reshape(3, 2)
>>> X                                                 
array([[0, 1],
       [2, 3],
       [4, 5]])
poly = PolynomialFeatures(2)
>>> poly.fit_transform(X)                             
array([[ 1.,  0.,  1.,  0.,  0.,  1.],
       [ 1.,  2.,  3.,  4.,  6.,  9.],
       [ 1.,  4.,  5., 16., 20., 25.]])


In some cases, only interaction terms among features are required, 
and it can be gotten with the setting interaction_only=True:


X = np.arange(9).reshape(3, 3)
>>> X                                                 
array([[0, 1, 2],
       [3, 4, 5],
       [6, 7, 8]])
poly = PolynomialFeatures(degree=3, interaction_only=True)
>>> poly.fit_transform(X)                             
array([[  1.,   0.,   1.,   2.,   0.,   0.,   2.,   0.],
       [  1.,   3.,   4.,   5.,  12.,  15.,  20.,  60.],
       [  1.,   6.,   7.,   8.,  42.,  48.,  56., 336.]])
''')
