import warnings
from sklearn.exceptions import * 
warnings.simplefilter(action='ignore', category=UserWarning)

print("""
====================================================================
Normal and Shrinkage Linear Discriminant Analysis for classification
====================================================================
Shows how shrinkage improves classification in Linear Discriminant Analysis

Linear Discriminant Analysis and Quadratic Discriminant Analysis 
are two classic classifiers, with a linear and a quadratic decision surface, 
respectively.

These classifiers are attractive because they have closed-form solutions 
, are inherently multiclass, have proven to work well in practice, 
and have no hyperparameters to tune.

Linear and quadratic discriminant analysis, is modeled 
as a multivariate Gaussian distribution with normal probaility density 
(having Covariance matrix ( in place of variance as this is multivariate case)
In the case of LDA, the Gaussians for each class are assumed to share the same covariance matrix
This leads to linear decision surfaces
In the case of QDA, there are no assumptions on the covariance matrices of the Gaussians,
leading to quadratic decision surface

Hence when the covariance matrices are different, 
LDA leads to bad performance as its assumption becomes invalid, 
while QDA performs classification much better.

If in the QDA model one assumes that the covariance matrices are diagonal, 
then the inputs are assumed to be conditionally independent in each class, 
and the resulting classifier is equivalent to the Gaussian Naive Bayes classifier

Shrinkage(for LDA) is a tool to improve estimation of covariance matrices in situations 
where the number of training samples is small compared to the number of features
(LDA with solver parameter to 'lsqr' or 'eigen' and shrinkage parameter to 'auto'
(or between 0(no shrinkage) and 1(100% shrinkage))
ie 1 means that the diagonal matrix of variances will be used as an 
estimate for the covariance matrix 

The default solver is 'svd'. 
It can perform both classification and transform, 
and it does not rely on the calculation of the covariance matrix. 
This can be an advantage in situations where the number of features is large. 
However, the 'svd' solver cannot be used with shrinkage.
 
""")
import numpy as np
import matplotlib.pyplot as plt

from sklearn.datasets import make_blobs
from sklearn.discriminant_analysis import *


n_train = 20  # samples for training
n_test = 200  # samples for testing
n_averages = 50  # how often to repeat classification
n_features_max = 75  # maximum number of features
step = 4  # step size for the calculation


def generate_data(n_samples, n_features):
    """Generate random blob-ish data with noisy features.

    This returns an array of input data with shape `(n_samples, n_features)`
    and an array of `n_samples` target labels.

    Only one feature contains discriminative information, the other features
    contain only noise.
    """
    X, y = make_blobs(n_samples=n_samples, n_features=1, centers=[[-2], [2]])

    # add non-discriminative features
    if n_features > 1:
        X = np.hstack([X, np.random.randn(n_samples, n_features - 1)])
    return X, y

acc_clf1, acc_clf2, acc_clf3, acc_clf4, acc_clf5 = [], [], [], [], []
n_features_range = range(1, n_features_max + 1, step)
for n_features in n_features_range:
    score_clf1, score_clf2,score_clf3, score_clf4,score_clf5 = 0, 0, 0, 0, 0
    for _ in range(n_averages):
        X, y = generate_data(n_train, n_features)

        clf1 = LinearDiscriminantAnalysis(solver='lsqr', shrinkage='auto').fit(X, y)
        clf2 = LinearDiscriminantAnalysis(solver='lsqr', shrinkage=None).fit(X, y)
        clf3 = LinearDiscriminantAnalysis(solver='svd').fit(X, y)
        clf4 = QuadraticDiscriminantAnalysis().fit(X, y)
        clf5 = QuadraticDiscriminantAnalysis(reg_param=0.1).fit(X, y)
        
        X, y = generate_data(n_test, n_features)
        score_clf1 += clf1.score(X, y)
        score_clf2 += clf2.score(X, y)
        score_clf3 += clf3.score(X, y)
        score_clf4 += clf4.score(X, y)
        score_clf5 += clf5.score(X, y)


    acc_clf1.append(score_clf1 / n_averages)
    acc_clf2.append(score_clf2 / n_averages)
    acc_clf3.append(score_clf3 / n_averages)
    acc_clf4.append(score_clf4 / n_averages)
    acc_clf5.append(score_clf5 / n_averages)

features_samples_ratio = np.array(n_features_range) / n_train

plt.plot(features_samples_ratio, acc_clf1, linewidth=2,
         label="Linear Discriminant Analysis with shrinkage", color='navy')
plt.plot(features_samples_ratio, acc_clf2, linewidth=2,
         label="Linear Discriminant Analysis", color='gold')
plt.plot(features_samples_ratio, acc_clf3, linewidth=2,
         label="Linear Discriminant Analysis with svd solver", color='black')
plt.plot(features_samples_ratio, acc_clf4, linewidth=2,
         label="Quadratic Discriminant Analysis", color='red')
plt.plot(features_samples_ratio, acc_clf5, linewidth=2,
         label="Quadratic Discriminant Analysis with reg_param=0.1", color='green')


plt.xlabel('n_features / n_samples')
plt.ylabel('Classification accuracy')

plt.legend(loc=1, prop={'size': 12})
plt.suptitle('Linear and Quadratic Discriminant Analysis')
plt.show()
