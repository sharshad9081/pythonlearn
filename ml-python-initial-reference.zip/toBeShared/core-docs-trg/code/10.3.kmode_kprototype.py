import numpy as np
from sklearn import datasets

print("""
k-modes is used for clustering categorical variables. 
It defines clusters based on the number of matching categories between data points. 
(This is in contrast to the more well-known k-means algorithm, 
which clusters numerical data based on Euclidean distance.) 

The k-prototypes algorithm combines k-modes and k-means and is able to cluster mixed 
numerical / categorical data.

""")

print("--KPrototypes of iris data(4 columns + categorical, Name) n_clusters=3-----------------")
from kmodes.kprototypes import KPrototypes

iris = datasets.load_iris()

data = np.c_[iris['data'], iris['target']]

kp = KPrototypes(n_clusters=3, init='Huang', n_init=1)
kp.fit_predict(data, categorical=[4])

print("cluster centroids - continuous and categorical features, [n_clusters, n_features]=\n", kp.cluster_centroids_)
print("labels for each sample=\n", kp.labels_)



print("--KPrototypes of stocks.csv(3 Categorical+ Value), n_clusters=4-----------------")
import numpy as np
from kmodes.kprototypes import KPrototypes

# stocks with their market caps, sectors and countries
syms = np.genfromtxt('data/stocks.csv', dtype=str, delimiter=',')[:, 0]
X = np.genfromtxt('data/stocks.csv', dtype=object, delimiter=',')[:, 1:]
X[:, 0] = X[:, 0].astype(float)

kproto = KPrototypes(n_clusters=4, init='Cao')
clusters = kproto.fit_predict(X, categorical=[1, 2])

# Print cluster centroids of the trained model.
print("cluster centroids - continuous and categorical features, [n_clusters, n_features]=\n", kproto.cluster_centroids_)
print("Print training statistics")
print("cost", kproto.cost_)
print("iter", kproto.n_iter_)

for s, c in zip(syms, clusters):
    print("Symbol: {}, cluster index:{}".format(s, c))

    
print("--KModes of soybean.csv, n_clusters=4-----------------")

import numpy as np
from kmodes.kmodes import KModes

# reproduce results on small soybean data set
x = np.genfromtxt('data/soybean.csv', dtype=int, delimiter=',')[:, :-1]
y = np.genfromtxt('data/soybean.csv', dtype=str, delimiter=',', usecols=(35, ))

kmodes_huang = KModes(n_clusters=4, init='Huang')
kmodes_huang.fit(x)

# Print cluster centroids of the trained model.
print('k-modes (Huang) centroids:')
print("cluster centroids - categorical features, [n_clusters, n_features]=\n", kmodes_huang.cluster_centroids_)
# Print training statistics
print('Final training cost: {}'.format(kmodes_huang.cost_))
print('Training iterations: {}'.format(kmodes_huang.n_iter_))

kmodes_cao = KModes(n_clusters=4, init='Cao')
kmodes_cao.fit(x)

# Print cluster centroids of the trained model.
print('k-modes (Cao) centroids:')
print("cluster centroids - categorical features, [n_clusters, n_features]=\n", kmodes_cao.cluster_centroids_)
# Print training statistics
print('Final training cost: {}'.format(kmodes_cao.cost_))
print('Training iterations: {}'.format(kmodes_cao.n_iter_))

print('Results tables(1st table:huang, 2nd table:cao) :')
print("D1,D2,D3,D4 are soybean types, C1.N are clusters")
print("depicts how many data points in each cluster, Cao is more distinct")
for result in (kmodes_huang, kmodes_cao):
    classtable = np.zeros((4, 4), dtype=int)
    for ii, _ in enumerate(y):
        classtable[int(y[ii][-1]) - 1, result.labels_[ii]] += 1

    print("\n")
    print("    | Cl. 1 | Cl. 2 | Cl. 3 | Cl. 4 |")
    print("----|-------|-------|-------|-------|")
    for ii in range(4):
        prargs = tuple([ii + 1] + list(classtable[ii, :]))
        print(" D{0} |    {1:>2} |    {2:>2} |    {3:>2} |    {4:>2} |".format(*prargs))
