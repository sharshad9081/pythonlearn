import warnings
from sklearn.exceptions import * 
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=DataConversionWarning)
warnings.simplefilter(action='ignore', category=ConvergenceWarning)
warnings.simplefilter(action='ignore', category=DeprecationWarning)



import pandas as pd
import numpy as np
from sklearn.preprocessing import *
from  sklearn.decomposition import * 
import matplotlib.pyplot as plt 
from sklearn.model_selection import * 
from sklearn.metrics import *
from sklearn.pipeline import Pipeline
from sklearn import datasets

from sklearn.ensemble import *  
from sklearn.tree import *
import time 
from auto_ml import Predictor





if __name__=='__main__':

    print("----------------- GBM vs CatBoost vs. Light GBM vs. XGBoost on flights.csv ----------------")
    PAUSE='Y'
    def pause_d():
        if PAUSE == 'Y':
            print("pausing...")
            input()

    print("""

    flights.csv 
    MONTH, DAY, DAY_OF_WEEK: data type int
    AIRLINE and FLIGHT_NUMBER: data type int
    ORIGIN_AIRPORT and DESTINATION_AIRPORT: data type string
    DEPARTURE_TIME: data type float
    ARRIVAL_DELAY: this will be the target and is transformed into boolean variable 
    indicating delay of more than 10 minutes
    DISTANCE and AIR_TIME: data type float
    """)

    data = pd.read_csv("data/flights.csv")

    data = data[["MONTH","DAY","DAY_OF_WEEK","AIRLINE","FLIGHT_NUMBER","DESTINATION_AIRPORT",
                     "ORIGIN_AIRPORT","AIR_TIME", "DEPARTURE_TIME","DISTANCE","ARRIVAL_DELAY"]]
    data.dropna(inplace=True)

    data["ARRIVAL_DELAY"] = (data["ARRIVAL_DELAY"]>10)*1

    cols = ["AIRLINE","FLIGHT_NUMBER","DESTINATION_AIRPORT","ORIGIN_AIRPORT"]
    #convert to numeric categorical , 0- size_of_cat
    for item in cols:
        data[item] = data[item].astype("category").cat.codes +1

    #axis=0, row, axis=1, column 
    X = data.drop(["ARRIVAL_DELAY"], axis=1)
    y = data["ARRIVAL_DELAY"]
    train, test, y_train, y_test = train_test_split(data.drop(["ARRIVAL_DELAY"], axis=1),
        data["ARRIVAL_DELAY"],random_state=10, test_size=0.25)
        
    column_descriptions = { 'ARRIVAL_DELAY': 'output'  , 'MONTH': 'categorical',
        'DAY': 'categorical', 'DAY_OF_WEEK': 'categorical'}

    print("\n\nusing auto_ml to compare all models")
    print(""" below are most useful configurabke parameter
    compare_all_models - [default=False]
        True means many scikit Models would be compared 
        If False, by default uses GradientBoostingRegressor or GradientBoostingClassifier
           
    take_log_of_y (Boolean) - [default- None] 
        For regression problems, 
        accuracy is sometimes improved by taking the natural log of y values during training, 
        so they all exist on a comparable scale.

    model_names (list of strings) 
        [default- relevant 'GradientBoosting'] Which model(s) to try. 
        from scikit-learn are ['ARDRegression', 'AdaBoostClassifier', 'AdaBoostRegressor', 'BayesianRidge', 'ElasticNet', 'ExtraTreesClassifier', 'ExtraTreesRegressor', 'GradientBoostingClassifier', 'GradientBoostingRegressor', 'Lasso', 'LassoLars', 'LinearRegression', 'LogisticRegression', 'MiniBatchKMeans', 'OrthogonalMatchingPursuit', 'PassiveAggressiveClassifier', 'PassiveAggressiveRegressor', 'Perceptron', 'RANSACRegressor', 'RandomForestClassifier', 'RandomForestRegressor', 'Ridge', 'RidgeClassifier', 'SGDClassifier', 'SGDRegressor']. 
        Other options : eg model_names=['DeepLearningClassifier']
            DeepLearningClassifier and DeepLearningRegressor(tensorflow,keras)
            XGBClassifier and XGBRegressor
            LGBMClassifer and LGBMRegressor
            CatBoostClassifier and CatBoostRegressor
    optimize_final_model (Boolean) - [default- False] 
        Whether or not to perform GridSearchCV on the final model. 
        True increases computation time significantly, 
        but will likely increase accuracy.  
    """)
    #Example 
    from auto_ml import Predictor

    #comment out calc_feature_importance parameter 

    # File "c:\python35\lib\site-packages\auto_ml\utils_models.py", line 176, in get model_from_name
    # model_map['CatBoostRegressor'] = CatBoostRegressor(calc_feature_importance=True)
    # TypeError: __init__() got an unexpected keyword argument 'calc_feature_importanc
    #comment out 1149 pre_dispatch in predictor.py
    #must use python35\deep module which is modified version of pypi

    # Load data
    #train, test, y_train, y_test   #from earlier example 

    #tell only numeric categorical 
    #string categorical is automatic 
    column_descriptions = { 'ARRIVAL_DELAY': 'output'  , 'MONTH': 'categorical',
        'DAY': 'categorical', 'DAY_OF_WEEK': 'categorical'}

    #sklearn models , 
    ml1 = Predictor(type_of_estimator='classifier', 
            column_descriptions=column_descriptions)
    st = time.time()
    #optimize_final_model=True has a problems, hence dont use 
    #to use optimize_final_model=True, must use python35\deep module which is modified version of pypi
    m11 = ml1.train(pd.concat([train, y_train], axis=1) , optimize_final_model=True) 
    predictions = ml1.predict(pd.concat([test, y_test], axis=1))
    print("\nScikit models")
    print(m11.trained_final_model.model) #model 
    #m11.trained_pipeline  #this is the Pipeline
    #Note internally it uses internal scoring method, hence use below methods 
    print("AUC(train,test) in ",(time.time()-st)," secs ", 
        roc_auc_score(y_train, ml1.predict(pd.concat([train, y_train], axis=1))),#0.859883236030025
        roc_auc_score(y_test, predictions) #0.8181818181818182
        )

    pause_d()

    st = time.time()
    print("\nXGBClassifier")
    #XGBClassifier and XGBRegressor
    ml3 = Predictor(type_of_estimator='classifier', column_descriptions=column_descriptions)
    ml3 = ml3.train(pd.concat([train, y_train], axis=1), model_names=['XGBClassifier'], optimize_final_model=True)  #, verbose=10) 
    predictions = ml3.predict(pd.concat([test, y_test], axis=1))
    print("AUC(train,test) in ",(time.time()-st)," secs ", 
            roc_auc_score(y_train, ml3.predict(pd.concat([train, y_train], axis=1))),#0.8137336669446761
            roc_auc_score(y_test, predictions) #0.8194328607172644
         )
         
    pause_d()

    st = time.time()
    #LGBMClassifer and LGBMRegressor
    print("\nLGBMClassifer")
    ml4 = Predictor(type_of_estimator='classifier', column_descriptions=column_descriptions)
    ml4 = ml4.train(pd.concat([train, y_train], axis=1), model_names=['LGBMClassifier'], optimize_final_model=True) #, verbose=10) 
    predictions = ml4.predict(pd.concat([test, y_test], axis=1))
    print("AUC(train,test) in ",(time.time()-st)," secs ", 
            roc_auc_score(y_train, ml4.predict(pd.concat([train, y_train], axis=1))), #0.8412566027244927
            roc_auc_score(y_test, predictions) #0.817347789824854
        )
    pause_d()

    st = time.time()
    #CatBoostClassifier and CatBoostRegressor
    print("\nCatBoostClassifier")
    ml5 = Predictor(type_of_estimator='classifier', column_descriptions=column_descriptions)
    ml5 = ml5.train(pd.concat([train, y_train], axis=1), model_names=['CatBoostClassifier'], optimize_final_model=True)  #, verbose=10) 
    predictions = ml5.predict(pd.concat([test, y_test], axis=1))
    print("AUC(train,test) in ",(time.time()-st)," secs ", 
        roc_auc_score(y_train, ml5.predict(pd.concat([train, y_train], axis=1))), #0.8262440922991382
        roc_auc_score(y_test, predictions)#0.8148457047539617
        )



