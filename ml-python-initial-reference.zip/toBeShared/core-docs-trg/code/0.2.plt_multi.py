import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 

print("""
Working with multiple figures and axes
Plots may contain many Figure, 
each figure is one display window
each Figure may contain many Axes
Figure contains set/get of figure related attributes 
eg get_figheight(),get_figwidth()
Axes contains plot() and set/get of xlabel, ylabel etc


#https://matplotlib.org/api/_as_gen/matplotlib.pyplot.subplots.html 
##Option-1 
plt.subplots(nrows=1, ncols=1, sharex=False, sharey=False, squeeze=True, 
    subplot_kw=None, gridspec_kw=None, **fig_kw)

sharex=True, means only one X ticks value printing , similarly for sharey
figsize : (float, float), optional, default: None
width, height in inches. 
If not provided, defaults to rcParams["figure.figsize"] = [6.4, 4.8].

note subplots(..) returns (figure,axes)
where axes is numpy.ndarray, hence access like axes[0,0], axes[0,1],... for complex subplots 
for simple , can destructure immediately

squeeze : bool, optional, default: True
If True, extra dimensions are squeezed out from the returned array of Axes:
    if only one subplot is constructed (nrows=ncols=1), 
    the resulting single Axes object is returned as a scalar.
    for Nx1 or 1xM subplots, the returned object is a 1D numpy object array 
    of Axes objects.
    for NxM, subplots with N>1 and M>1 are returned as a 2D array.
If False, no squeezing at all is done: the returned Axes object is always 
a 2D array containing Axes instances, even if it ends up being 1x1.

Using 
figure, (ax1, ax2) = plt.subplots(nrows=1, ncols=2)
ax1.plot(x,y,fmt, ...) 

""")

t = np.arange(0., 5., 0.2)
figure, (ax1, ax2) = plt.subplots(nrows=1, ncols=2, sharex=True, sharey=False, figsize=(15,15))
figure.suptitle('multiplot', fontsize=16) #called suptitle instead of title 
ax1.plot(t, t, 'r-')  
ax1.set_title('Straight line')
ax2.scatter(t, t**2, color='b')
ax2.set_xlabel('x axis label')
ax2.set_ylabel('y axis label')
ax2.set_title('Simple plot')
ax2.legend(['Square',])

ax2.axis([0, 5, 0,25]) #Set the axis, [xmin, xmax, ymin, ymax] or 'off' or 'equal' or 'scaled' or 'tight' etc 
ax2.set_axis_off() #Turn off the axis. 
ax2.set_axis_on()  # Turn on the axis.
#or 
ax2.set_ylim(0,25)
ax2.set_xlim(0, 5) 

#in data cordinates 
ax2.text(2, 4, r'$\mu=100,\ \sigma=15$')  #Any text 
ax2.annotate('local max', xy=(2, 1), xytext=(3, 1.5),arrowprops=dict(facecolor='black', shrink=0.05),) #xytext=location of text, xy=location for annotation
ax2.arrow(4,4,1,1)  #(x, y, dx, dy, **kwargs)    #Add an arrow to the axes.
ax2.grid(b=True, color='r', linestyle='-', linewidth=.5)
#ax2.set_label(s)       #Set the label to s for auto legend.
 

ax2.set_yscale('linear') #log, symlog, logit
ax2.set_xscale('linear')
ax2.set_visible(True)     #Set the artist's visibility.
#ax2.set_zorder(level)  #Set the zorder for the artist. Artists with lower zorder values are drawn first.

# ax2.set_xticks(ticks, minor=False)     #Set the x ticks with list of ticks(List of tick locations.)
# ax2.set_xticklabels(labels, fontdict=None, minor=False, **kwargs)#Set the x-tick labels with list of string labels.
# ax2.set_yticks(ticks, minor=False)#Set the y ticks with list of ticks(List of tick locations.)
# ax2.set_yticklabels(labels, fontdict=None, minor=False, **kwargs)#Set the y-tick labels with list of strings labels.

# ax2.xaxis_date(tz=None)  #Sets up x-axis ticks and labels that treat the x data as dates.
# ax2.yaxis_date(tz=None)  #Sets up y-axis ticks and labels that treat the y data as dates.
# ax2.minorticks_off()     #Remove minor ticks from the axes.
# ax2.minorticks_on()      #Remove minor ticks from the axes.

#then show 
plt.show()

input()

print("""
##Option-2 
fig = plt.figure(figsize=None, dpi=None, facecolor=None, edgecolor=None, linewidth=0. 0,
        frameon=None, subplotpars=None, tight_layout=None)
    Check https://matplotlib.org/api/_as_gen/matplotlib.pyplot.figure.html#matplotlib.pyplot.figure 
    num 
        integer or string, optional, default: none
        If not provided, a new figure will be created, and the figure number will be incremented. 
        The figure objects holds this number in a number attribute. If num is provided, 
        and a figure with this id already exists, make it active, and returns a reference to it. 
        If this figure does not exists, create it and returns it. 
        If num is a string, the window title will be set to this figure's num.
        
Using 
fig = plt.figure(figsize=(15,15), edgecolor='b', tight_layout=True)        
ax1 = fig.add_subplot(211)      # nrows, ncols, which_Axes_tomake_current ie 1    
ax1.plot(x,y,fmt, ...) 
""")
#Example  
t = np.arange(0., 5., 0.2)
#tight_layout automatically adjusts subplot params so that the subplot(s) fits in to the figure area  
fig = plt.figure(figsize=(15,15), edgecolor='b', tight_layout=True)        #create a figure 
ax1 = fig.add_subplot(211)               # nrows, ncols, which_Axes_tomake_current ie 1  
ax1.plot(t, t, 'r-')  
ax2 = fig.add_subplot(212)
ax2.plot(t, t**2, 'r-') 
#then show 
plt.show()

input()

print("""
##Option-3 
All plotting commands apply to the current axes.
figure means one window 

Using 
plt.figure(1)           # the first figure
plt.subplot(211)        # nrows,ncols, which_Axes_tomake_current ie 1  
plt.plot(x,y,fmt, ...)  # all plot/scatter/box/hist etc goes subplot 1 
""")

x = np.linspace(0, 2*np.pi, 400)
y = np.sin(x**2)

plt.figure(1)           # the first figure
plt.subplot(211)        # nrows,ncols, which_Axes_tomake_current ie 1                             
plt.plot(x,y,'r-')      # all plot/scatter/box/hist etc goes subplot 1 
plt.subplot(212)        # nrows,ncols, which_Axes_tomake_current ie 2
plt.plot(x,y**2,'b--')  # all plot/scatter/box/hist etc goes subplot 2

plt.figure(2)           # a second figure, sets to this figure, all plot commands go here
plt.plot(x,y**3,'go')   # creates a subplot(111) by default

plt.figure(1)                # figure 1 current; subplot(212) still current
plt.subplot(211)             # make subplot(211) in figure1 current
plt.title('Easy as 1, 2, 3') # subplot 211 title
#then show 
plt.show()



#The function gca() returns the current axes (a matplotlib.axes.Axes instance ),
#and gcf() returns the current figure (matplotlib.figure.Figure instance ).
#clear the current figure with clf() and the current axes with cla()
# ax = plt.gca()  #Get the current Axes instance on the current figure 
# fig = plt.gcf()  #Get a reference to the current figure.
# ax.cla() #clear 
# fig.clf() # clear 

input()

print("""
##Option-4, advanced 
#https://matplotlib.org/api/_as_gen/matplotlib.pyplot.subplot2grid.html

Using 
fig1= plt.figure(1)
ax1 = plt.subplot2grid((3,3), (0,0), colspan=3) #Total=3x3, for (0,0), 3 columns 
ax1.plot(x,y,fmt, ...) 
""")

#3x3 grid , 
fig1= plt.figure(1)
ax1 = plt.subplot2grid((3,3), (0,0), colspan=3) #for (0,0), 3 columns 
ax2 = plt.subplot2grid((3,3), (1,0), colspan=2) #for (1,0), 2 columns 
ax3 = plt.subplot2grid((3,3), (1, 2), rowspan=2) #for (1,2), 2 rows 
ax4 = plt.subplot2grid((3,3), (2, 0))  #one row and col
ax5 = plt.subplot2grid((3,3), (2, 1))   #one row and col 
#Now use ax1.plot() to direct commands to ax1, etc
x = np.linspace(-5,5,20)
y = np.sin(x)
ax1.plot(x,y,"r-")
ax2.plot(x,y,"b-")
ax3.plot(x,y,"r-")
ax4.plot(x,y,"b-")
ax5.plot(x,y,"b-")
plt.tight_layout() #tight_layout automatically adjusts subplot params so that the subplot(s) fits in to the figure area
plt.show()
