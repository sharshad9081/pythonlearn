from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
import nltk
import string
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report,confusion_matrix
from sklearn.model_selection import * 
from sklearn.metrics import *


PAUSE='Y'
def pause_d():
    if PAUSE == 'Y':
        print("pausing...")
        input()


print ("---------------------Categorization of text on 20newsgroups --------------------")
from sklearn import datasets
from sklearn.linear_model import SGDClassifier

categories = [
    'alt.atheism',
    'talk.religion.misc',
]
# Uncomment the following to do the analysis on all the categories
#categories = None


data = datasets.fetch_20newsgroups(subset='train', categories=categories)
print("%d documents" % len(data.filenames))
print("%d categories %s" % (len(data.target_names),data.target_names) )
test = datasets.fetch_20newsgroups(subset='test', categories=categories)


pipeline = Pipeline([
    ('vect', CountVectorizer()),
    ('tfidf', TfidfTransformer()),
    ('clf', SGDClassifier(tol=0.001, early_stopping=True)),
])

# uncommenting more parameters will give better exploring power but will
# increase processing time in a combinatorial way
parameters = {
    'vect__max_df': (0.5, 0.75, 1.0),
    # 'vect__max_features': (None, 5000, 10000, 50000),
    'vect__ngram_range': ((1, 1), (1, 2)),  # unigrams or bigrams
    # 'tfidf__use_idf': (True, False),
    # 'tfidf__norm': ('l1', 'l2'),    
    'clf__alpha': (0.00001, 0.000001),
    'clf__penalty': ('l2', 'elasticnet'),
    'clf__max_iter': (50, 100, 150),
}


# multiprocessing requires the fork to happen in a __main__ protected
# block

# find the best parameters for both the feature extraction and the
# classifier
grid_search = RandomizedSearchCV(pipeline, parameters, cv=5,
                           verbose=1, scoring='roc_auc') #scoring only for searching
print("Hypertuning...")
grid_search.fit(data.data, data.target)

best_parameters = grid_search.best_estimator_.get_params()
print("Best params\n", best_parameters)
print("Accuracy train, test ", grid_search.score(data.data, data.target),
grid_search.score(test.data, test.target)   ) 
