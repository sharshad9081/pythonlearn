import warnings
from sklearn.exceptions import * 
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=ConvergenceWarning)




import numpy as np

print("""
Most models have multiple hyperparameters and the best way 
to choose a combination of those parameters is with a grid search. 
However, it is sometimes useful to plot the influence 
of a single hyperparameter on the training and test data to determine 
if the estimator is underfitting or overfitting for some hyperparameter values.
""")

print("""
  
 The validation curve explores the relationship of the "C" parameter 
 to the f1_weighted score with 3 Fold cross-validation.
 whereas smaller values of C specify stronger regularization.
 """)

from sklearn.linear_model import LogisticRegressionCV, LogisticRegression
from yellowbrick.model_selection import ValidationCurve
import pandas as pd
from sklearn.model_selection import * 

# Load a regression dataset
data = pd.read_csv("data/game.csv")

# Specify the features of interest and the target
target = "outcome"
features = [col for col in data.columns if col != target]

# Encode the categorical data with one-hot encoding
X = pd.get_dummies(data[features])
y = data[target]

# Create the learning curve visualizer
cv = StratifiedKFold(3)

viz = ValidationCurve(
    LogisticRegression(multi_class='auto', solver='lbfgs', max_iter=100), param_name="C",
    param_range=[.0001, 0.01,.1, .5, 1,5,10], cv=cv, scoring="accuracy", n_jobs=-1
)

# Fit and poof the visualizer
viz.fit(X, y)
viz.poof()