



import numpy as np

print("""
A learning curve shows the relationship of the training score 
vs the cross validated test score for an estimator 
with a varying number of training samples. 

This visualization is typically used two show two things:
1.How much the estimator benefits from more data 
 (e.g. do we have 'enough data' or will the estimator get better 
 if used in an online fashion).
    
2.Is the estimator is more sensitive to error due to variance 
  vs. error due to bias.

If the training and cross validation scores converge together 
as more data is added , but both are low(high bias, high variance)
then the model will probably not benefit from more data. 

If the training score is much greater than the validation score 
(low bias and variance is decreasing with more samples ) 
then the model probably requires more training examples 
in order to generalize more effectively.

The curves are plotted with the mean scores, 
however variability during cross-validation is shown with the shaded areas 
that represent a standard deviation above and below the mean for all cross-validations. 

If the model suffers from error due to bias, 
then there will likely be more variability around the training score curve. 
that means it is underfitting 

If the model suffers from error due to variance, 
then there will be more variability around the cross validated score.
and that means it is overfitting 
""")



from sklearn.linear_model import RidgeCV
from yellowbrick.model_selection import LearningCurve
import pandas as pd

# Load a regression dataset
data = pd.read_csv("data/energy.csv")

# Specify features of interest and the target
targets = ["heating load", "cooling load"]
features = [col for col in data.columns if col not in targets]

# Extract the instances and target
X = data[features]
y = data[targets[0]]

sizes = np.linspace(0.3, 1.0, 10)

viz = LearningCurve(
    RidgeCV(),  train_sizes=sizes, cv=10, scoring="r2"
)

# Fit and poof the visualizer
viz.fit(X, y)
viz.poof()