"""
============================================================
Bias-variance decomposition
============================================================

This example illustrates and compares the bias-variance decomposition of the
expected mean squared error of a single estimator against a bagging ensemble.

In regression, the expected mean squared error of an estimator can be
decomposed in terms of bias, variance and noise. On average over datasets of
the regression problem, the bias term measures the average amount by which the
predictions of the estimator differ from the predictions of the best possible
estimator for the problem (i.e., the Bayes model). The variance term measures
the variability of the predictions of the estimator when fit over different
instances Least Square of the problem. Finally, the noise measures the irreducible part
of the error which is due the variability in the data.

"""
print(__doc__)
import warnings
from sklearn.exceptions import * 
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=DataConversionWarning)
warnings.simplefilter(action='ignore', category=ConvergenceWarning)


from sklearn.pipeline import * 
from sklearn.naive_bayes import * 
from sklearn.cluster import *  
from sklearn.covariance import *  
from sklearn.cross_decomposition import *  
from sklearn.datasets import *  
from sklearn.decomposition import *  
from sklearn.ensemble import *  
from sklearn.feature_extraction import *  
from sklearn.feature_extraction.text import *  
from sklearn.feature_selection import *  
from sklearn.gaussian_process import *  
from sklearn.linear_model import *  
from sklearn.manifold import *  
from sklearn.metrics import *  
from sklearn.mixture import *  
from sklearn.model_selection import *  
from sklearn.neighbors import *  
from sklearn.neural_network import *  
from sklearn.preprocessing import *  
from sklearn_pandas import DataFrameMapper
from sklearn.svm import *  
from sklearn.tree import *  

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt

#univariate Regression, y = np.exp(-x ** 2) + 1.5 * np.exp(-(x - 2) ** 2)
#so X = list of x , y = corresponding value 
# Generate data
def f(x):
    x = x.ravel()
    return np.exp(-x ** 2) + 1.5 * np.exp(-(x - 2) ** 2)


def generate(n_samples, noise, n_repeat=1):
    X = np.random.rand(n_samples) * 10 - 5 #-5 to +5 uniform distribution 
    X = np.sort(X)
    if n_repeat == 1:
        y = f(X) + np.random.normal(0.0, noise, n_samples) #sd = noise, mean =0 
    else:
        y = np.zeros((n_samples, n_repeat)) #n_samples x n_repeat
        for i in range(n_repeat):
            y[:, i] = f(X) + np.random.normal(0.0, noise, n_samples)
    X = X.reshape((n_samples, 1))
    return X, y

# Settings
n_repeat = 50       # Number of iterations for computing expectations
n_train = 50        # Size of the training set
n_test = 1000       # Size of the test set
noise = 0.1         # Standard deviation of the noise
np.random.seed(0)
X_train = []
y_train = []
#X_train, y_train = 50 x (50, 1), 50 x (50,)
for i in range(n_repeat):
    X, y = generate(n_samples=n_train, noise=noise)
    X_train.append(X)  
    y_train.append(y)

X_test, y_test = generate(n_samples=n_test, noise=noise, n_repeat=n_repeat)
#X_test.shape, (1000, 1)
#y_test.shape, (1000, 50)

#Calculate bias and variance of estimators 
def calculate(name, estimator):
    # Repeat 50 times so y_predict = 1000 x 50 = y_test 
    y_predict = np.zeros((n_test, n_repeat))
    for i in range(n_repeat):
        estimator.fit(X_train[i], y_train[i])
        y_predict[:, i] = estimator.predict(X_test)
    # Bias^2 + Variance + Noise decomposition of the mean squared error
    y_error = np.zeros(n_test) #(1000,)
    #calulate  total error for each sample of y 
    #total error = sqr(actual_y - predict_y)
    #y_test = 1000x50 , y_predict= 1000x50
    #for each X_test, we get one predict_y,
    #and for that , we get 50 repetations of  actual in y_test 
    for i in range(n_repeat):
        for j in range(n_repeat):
            y_error += (y_test[:, j] - y_predict[:, i]) ** 2 #(1000,) - (1000,) = (1000,)
    y_error /= (n_repeat * n_repeat) #normalize 
    y_noise = np.var(y_test, axis=1) # rowwise , (1000,)
    y_bias = (f(X_test) - np.mean(y_predict, axis=1)) ** 2 #(1000,) = (1000,) - (1000,)
    y_var = np.var(y_predict, axis=1) # rowwise , (1000,)
    print("{0}: {1:.4f} (error) = {2:.4f} (bias^2) "
          " + {3:.4f} (var) + {4:.4f} (noise)".format(name,
                                                      np.mean(y_error),
                                                      np.mean(y_bias),
                                                      np.mean(y_var),
                                                      np.mean(y_noise)))

estimators = [("Tree", DecisionTreeRegressor()),
              ("Bagging(Tree)", BaggingRegressor(DecisionTreeRegressor())),
              ('RF', RandomForestRegressor()),
              ('ET', ExtraTreesRegressor()),
              ('Ada', AdaBoostRegressor()),
              ('GBM', GradientBoostingRegressor()),
              ('StocasticGBM', GradientBoostingRegressor(learning_rate = 0.1,subsample = 0.5)),
              ('Knn', KNeighborsRegressor()),
              ('SVM', SVR()),
              ('Ridge' , RidgeCV()),
              ('Lasso', LassoCV()),
              ('elastic', ElasticNetCV()),              
              ]
print("""
Bagging/RT/ET - Ensemble methods that minimize variance
Boosting - Ensemble methods that minimize bias
Stochastic GBM - Ensemble methods that minimize variance at the expense of Bias       
""")
for n,e in estimators:
    calculate(n,e)
