print("""

    input 
x1          x2      y
0           0       0
0           1       1
1           0       1
1           1       0

Step-1: Initialization of Weights: Randomly Select weights
b: bias 
h: activation
h1 = 1/(1+exp(-(bh1+x1h1*x1+x2h1*x2)))
h2 = 1/(1+exp(-(bh2+x1h2*x1+x2h2*x2)))
y_  = 1/(1+exp(-(by+h1y*h1+h2y*h2)))
                        
                        weights and biases 
                  of 2 Dense hidden and output layers 
             -----------------------------------------
x1  x2   y   bh1    x1h1  x2h1  x1h2  x2h2    bh2 by  h1y h2y   h1 h2  y_            
1   1    0   0.5    0.5   0.5   1     -1      1   1   -1  1     
     

     
Step-2:(forward propagation) Input training values and calculation forward 

x1  x2   y   bh1    x1h1  x2h1  x1h2  x2h2    bh2 by  h1y h2y  h1    h2    y_
1   1    0   0.5    0.5   0.5   1     -1      1   1   -1  1    0.818 0.731 0.713


Step-3: (Backpropagation)Use the output Error to calulate the error fractions at each hidden layer
learning_rate = 0.1 

Err = y - y_ =  0 - 0.731 = -0.731
y_*(1-y_) = 0.204
delta at y_ = y_*(1-y_)*Err = -0.145

At y_ 
----------
new by_ = by + learning_rate*delta_at_y_ = 1 +0.1*-0.145 = 0.9854
new h1y = h1y + learning_rate*h1*delta_at_y_ = -1 +0.1*0.818*-0.145 = -1.01192
new h2y = h2y + learning_rate*h2*delta_at_y_ = 1 +0.1*0.731*-0.145 = 0.9894

h1 
--------
delta at y_ = -0.145 
h1*(1-h1)   = 0.149 
h1y = -1 
delta at h1 = h1*(1-h1)*h1y*delta_at_y_ = 0.0217
delta at x1h1 = learning_rate*x1*delta at h1 = 0.1*1*0.0217=0.00217
delta at x1h2 = learning_rate*x1*delta at h2 = 0.1*1*-0.0286=-0.00286
delta at bh1  = learning_rate*delta at h1 = 0.00217

bh1 = bh1 + delta_at_bh1 = 0.502175
x1h1 = x1h1+delta_at_x1h1 = 0.502175
x1h2 = x1h2+delta_at_x1h2 = 0.99714

h2 
--------
delta at y_ = -0.145 
h2*(1-h2)   = 0.1966
h2y = 1 
delta at h2 = h2*(1-h2)*h2y*delta_at_y_ = -0.0286
delta at x2h1 = learning_rate*x2*delta at h1=0.1*1*0.0217=0.00217
delta at x2h2 = learning_rate*x2*delta at h2=0.1*1*-0.0286=-0.00286
delta at bh2 = learning_rate*delta at h2 = -0.00286

bh2 = bh2 + delta_at_bh2 = 0.99714
x2h1 = x2h1+delta_at_x2h1 = 0.502175
x2h2 = x2h2+delta_at_x2h2 = -1.00286


Repeat Step2,3 for next data point and so on for all data points: One Epoch
""")








